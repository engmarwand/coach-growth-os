export type TemplateCategory = 
  | 'Initial Pitch — Fitness Coach'
  | 'Initial Pitch — Business Coach'
  | 'Initial Pitch — General Coach'
  | 'Follow-Up 1 — No Reply'
  | 'Follow-Up 2 — Low-Pressure Follow-Up'
  | 'Discovery Call Invitation'
  | 'Demo Invitation'
  | 'Proposal Follow-Up'
  | 'Client Onboarding'
  | 'Testimonial Request'
  | 'Low-Pressure Sign-Off'
  | 'Initial Pitch'
  | 'Follow-Up #1'
  | 'Follow-Up #2'
  | 'General';

export interface Template {
  id: string;
  name: string;
  category: TemplateCategory;
  subject: string;
  body: string;
  tags?: string[];
}

export type LeadStatus = 'New' | 'Emailed' | 'Followed Up' | 'Replied' | 'Meeting Scheduled' | 'Closed Won' | 'Closed Lost';

export type PlatformSource = 'Instagram' | 'LinkedIn' | 'YouTube' | 'TikTok' | 'Email' | 'Referral' | 'Other';
export type ContactMethod = 'Instagram DM' | 'LinkedIn DM' | 'Email';

export interface Lead {
  id: string;
  Name: string;
  BusinessName?: string;
  Niche: string;
  Country: string;
  Email: string;
  Website: string;
  Status: LeadStatus;
  'Deal Value': string;
  'Last Contact Date': string;
  Notes: string;
  'Onboarding Stage'?: string;
  Platform?: PlatformSource;
  ProfileURL?: string;
  PersonalizedObservation?: string;
  PainPoint?: string;
  DemoLink?: string;
  ContactMethod?: ContactMethod;
  TimeZone?: string;
  DoNotContact?: boolean;
  NextFollowUpDate?: string;
}

export type EmailStatus = 'Draft' | 'Scheduled' | 'Sent' | 'Failed' | 'Cancelled';

export interface ScheduledEmail {
  id: string;
  leadId: string;
  leadName: string;
  emailAddress: string;
  subject: string;
  body: string;
  scheduledAt: string; // ISO string
  status: EmailStatus;
  error?: string;
  isFollowUp?: boolean;
  followUpStep?: number;
  campaignId?: string;
}

export interface EmailLog {
  id: string;
  leadId?: string;
  leadName?: string;
  emailAddress: string;
  subject: string;
  body: string;
  type: 'sent' | 'received';
  date: string;
}

export type ActivityType = 'Lead Added' | 'Email Sent' | 'Email Scheduled' | 'Email Cancelled' | 'Status Changed';

export interface ActivityLog {
  id: string;
  type: ActivityType;
  title: string;
  details?: string;
  leadId?: string;
  leadName?: string;
  timestamp: string;
}

export interface CampaignStep {
  id: string;
  stepNumber: number;
  delayDays: number;
  subject: string;
  body: string;
}

export interface Campaign {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  steps: CampaignStep[];
  enrollmentCount: number;
  isSystemDefault?: boolean;
}

