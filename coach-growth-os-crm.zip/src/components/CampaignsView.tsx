import React, { useState, useMemo, useEffect } from 'react';
import { Lead, Template, ScheduledEmail, Campaign, CampaignStep } from '../types';
import { 
  Send, AlertCircle, Clock, Calendar, CheckCircle2, 
  Search, CheckSquare, Square, Filter, Sparkles, ArrowRight, ShieldCheck,
  Plus, Trash2, Edit3, UserCheck, Play, X, ChevronRight, Info, Layers, 
  Settings2, FileText, ListPlus, BarChart2, TrendingUp, Users, Target, Activity
} from 'lucide-react';
import { cn } from '../utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';

interface Props {
  leads: Lead[];
  templates: Template[];
  onScheduleCampaign: (emails: ScheduledEmail[]) => void;
  onNavigateToScheduled?: () => void;
  onScheduledUpdate?: (queue: ScheduledEmail[]) => void;
}

/**
 * Computes an ISO timestamp strictly aligned to Eastern Time (EST/EDT) business hours.
 */
function computeESTScheduleDate(dayOffset: number, hourEST: number, minuteEST: number): Date {
  const d = new Date();
  d.setDate(d.getDate() + dayOffset);

  // Skip weekends in Eastern Time
  const getESTDayOfWeek = (date: Date): string => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      weekday: 'short'
    }).format(date);
  };

  while (true) {
    const estDayOfWeek = getESTDayOfWeek(d);
    if (estDayOfWeek === 'Sat') {
      d.setDate(d.getDate() + 2);
    } else if (estDayOfWeek === 'Sun') {
      d.setDate(d.getDate() + 1);
    } else {
      break;
    }
  }

  // Get year, month, day in America/New_York
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).formatToParts(d);

  const year = parts.find(p => p.type === 'year')?.value || '2026';
  const month = parts.find(p => p.type === 'month')?.value || '01';
  const day = parts.find(p => p.type === 'day')?.value || '01';

  // Determine if daylight saving time (EDT) or standard time (EST)
  const nyDateStr = new Date(`${year}-${month}-${day}T12:00:00Z`).toLocaleString("en-US", {timeZone: "America/New_York", timeZoneName: "short"});
  const isEDT = nyDateStr.includes("EDT");
  const offset = isEDT ? 4 : 5;

  // Construct UTC date
  const utcDate = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day), hourEST + offset, minuteEST, 0));
  return utcDate;
}

function formatESTTime(isoString: string): string {
  try {
    const d = new Date(isoString);
    const formatted = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(d);
    return `${formatted} ET`;
  } catch {
    return isoString;
  }
}

const CAMPAIGNS_STORAGE_KEY = 'coachgrowthos_campaigns_store';

function loadCachedCampaigns(): Campaign[] {
  try {
    const raw = localStorage.getItem(CAMPAIGNS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to load cached campaigns:', e);
  }
  return [];
}

function persistCampaignsToStorage(campaigns: Campaign[]) {
  try {
    localStorage.setItem(CAMPAIGNS_STORAGE_KEY, JSON.stringify(campaigns));
  } catch (e) {
    console.error('Failed to persist campaigns:', e);
  }
}

export function CampaignsView({ leads, templates, onScheduleCampaign, onNavigateToScheduled, onScheduledUpdate }: Props) {
  // Campaigns list from backend and local cache
  const [campaigns, setCampaigns] = useState<Campaign[]>(() => {
    const cached = loadCachedCampaigns();
    return cached.length > 0 ? cached : [];
  });
  const [loadingCampaigns, setLoadingCampaigns] = useState(true);

  // Navigation / views
  const [activeView, setActiveView] = useState<'list' | 'builder' | 'enroll' | 'performance'>('list');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);

  // Campaign builder state
  const [campName, setCampName] = useState('');
  const [campDescription, setCampDescription] = useState('');
  const [campSteps, setCampSteps] = useState<CampaignStep[]>([]);
  const [focusedStepId, setFocusedStepId] = useState<string | null>(null);
  const [focusedField, setFocusedField] = useState<'subject' | 'body' | null>(null);

  // Enrollment state
  const [selectedLeadIds, setSelectedLeadIds] = useState<Set<string>>(new Set());
  const [leadFilterTab, setLeadFilterTab] = useState<'new' | 'all_active' | 'needs_research'>('new');
  const [nicheEnrollFilter, setNicheEnrollFilter] = useState<'all' | 'fitness' | 'business'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [emailsPerDay, setEmailsPerDay] = useState(15);
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduledSuccessCount, setScheduledSuccessCount] = useState<number | null>(null);

  // Candidate leads: uncontacted/active, valid email, not DNC, not closed
  const uncontactedLeads = useMemo(() => {
    return leads.filter(l => 
      l.Email && 
      !l.DoNotContact && 
      l.Status !== 'Closed Won' && 
      l.Status !== 'Closed Lost' && 
      l.Status !== 'Replied'
    );
  }, [leads]);

  // Load campaigns on mount with local cache merging
  const fetchCampaigns = async () => {
    setLoadingCampaigns(true);
    try {
      const res = await fetch('/api/campaigns');
      if (res.ok) {
        const data = await res.json();
        const local = loadCachedCampaigns();
        const mergedMap = new Map<string, Campaign>();
        if (Array.isArray(data)) {
          data.forEach(c => mergedMap.set(c.id, c));
        }
        if (Array.isArray(local)) {
          local.forEach(c => {
            if (!mergedMap.has(c.id) || (c.updatedAt && mergedMap.get(c.id)!.updatedAt && c.updatedAt > mergedMap.get(c.id)!.updatedAt)) {
              mergedMap.set(c.id, c);
            }
          });
        }
        const finalCampaigns = Array.from(mergedMap.values());
        setCampaigns(finalCampaigns);
        persistCampaignsToStorage(finalCampaigns);
      }
    } catch (e) {
      console.error("Failed to fetch campaigns, falling back to local cache", e);
      const local = loadCachedCampaigns();
      if (local.length > 0) {
        setCampaigns(local);
      }
    } finally {
      setLoadingCampaigns(false);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  // Filtered leads for the enrollment screen picker
  const filteredLeads = useMemo(() => {
    return uncontactedLeads.filter(lead => {
      if (leadFilterTab === 'new') {
        if (lead.Status !== 'New') return false;
      } else if (leadFilterTab === 'needs_research') {
        if (lead.PersonalizedObservation && lead.PersonalizedObservation.trim().length > 0) return false;
      }

      let matchesNiche = true;
      if (nicheEnrollFilter === 'fitness') {
        matchesNiche = (lead.Niche || '').toLowerCase().includes('fitness') || (lead.Niche || '').toLowerCase().includes('trainer') || (lead.Niche || '').toLowerCase().includes('health') || (lead.Niche || '').toLowerCase().includes('physique');
      } else if (nicheEnrollFilter === 'business') {
        matchesNiche = (lead.Niche || '').toLowerCase().includes('business') || (lead.Niche || '').toLowerCase().includes('marketing') || (lead.Niche || '').toLowerCase().includes('consultant') || (lead.Niche || '').toLowerCase().includes('agency') || (lead.Niche || '').toLowerCase().includes('entrepreneur');
      }
      if (!matchesNiche) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          (lead.Name || '').toLowerCase().includes(q) ||
          (lead.Email || '').toLowerCase().includes(q) ||
          (lead.Niche || '').toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [uncontactedLeads, leadFilterTab, searchQuery, nicheEnrollFilter]);

  // Lead selection triggers
  const toggleLead = (id: string) => {
    const next = new Set(selectedLeadIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedLeadIds(next);
  };

  const selectAllFiltered = () => {
    const next = new Set(selectedLeadIds);
    filteredLeads.forEach(l => next.add(l.id));
    setSelectedLeadIds(next);
  };

  const deselectAllFiltered = () => {
    const next = new Set(selectedLeadIds);
    filteredLeads.forEach(l => next.delete(l.id));
    setSelectedLeadIds(next);
  };

  // Setup builder state for create / edit
  const handleOpenBuilder = (campaign?: Campaign) => {
    if (campaign) {
      setSelectedCampaign(campaign);
      setCampName(campaign.name);
      setCampDescription(campaign.description);
      setCampSteps(campaign.steps);
      if (campaign.steps.length > 0) {
        setFocusedStepId(campaign.steps[0].id);
      } else {
        setFocusedStepId(null);
      }
    } else {
      setSelectedCampaign(null);
      setCampName('');
      setCampDescription('');
      // Default with one initial step
      const firstStep: CampaignStep = {
        id: `step-${Date.now()}-1`,
        stepNumber: 1,
        delayDays: 0,
        subject: "Quick question about your coaching lead flow, {{Name}}",
        body: "Hey {{Name}},\n\nI came across your {{Website}} and liked {{PersonalizedObservation}}.\n\nI build customized lead-management and follow-up systems for coaches.\n\nWould you be open to taking a look at a short 3-minute video overview?\n\nBest,\n[My Name]\nCoach Growth OS"
      };
      setCampSteps([firstStep]);
      setFocusedStepId(firstStep.id);
    }
    setFocusedField(null);
    setActiveView('builder');
  };

  // Add a step to the builder
  const handleAddStep = () => {
    const nextStepNum = campSteps.length + 1;
    const newStep: CampaignStep = {
      id: `step-${Date.now()}-${nextStepNum}`,
      stepNumber: nextStepNum,
      delayDays: 3, // Default 3 days follow-up
      subject: nextStepNum === 2 ? "Re: {{Original Subject}}" : "Quick bump, {{Name}}",
      body: "Hey {{Name}},\n\nJust popping this back to the top of your inbox.\n\nI design simple workspaces for coaches so they stop losing potential clients to messy DM or spreadsheet tracking.\n\nLet me know if you are open to checking out a 3-minute video overview.\n\nBest,\n[My Name]"
    };
    setCampSteps([...campSteps, newStep]);
    setFocusedStepId(newStep.id);
  };

  // Remove a step
  const handleRemoveStep = (stepId: string) => {
    if (campSteps.length <= 1) {
      alert("Campaign sequence must contain at least 1 step.");
      return;
    }
    const filtered = campSteps.filter(s => s.id !== stepId);
    // Re-index step numbers
    const reindexed = filtered.map((s, idx) => ({
      ...s,
      stepNumber: idx + 1,
      delayDays: idx === 0 ? 0 : s.delayDays
    }));
    setCampSteps(reindexed);
    if (focusedStepId === stepId) {
      setFocusedStepId(reindexed[0].id);
    }
  };

  // Update specific step field
  const handleUpdateStep = (stepId: string, field: 'subject' | 'body' | 'delayDays', value: any) => {
    setCampSteps(campSteps.map(s => {
      if (s.id === stepId) {
        return { ...s, [field]: value };
      }
      return s;
    }));
  };

  // Insert merge variable tag at cursor or end of input
  const handleInsertTag = (tag: string) => {
    if (!focusedStepId || !focusedField) {
      alert("Please click inside a Subject or Email Body field first.");
      return;
    }
    const stepToEdit = campSteps.find(s => s.id === focusedStepId);
    if (!stepToEdit) return;

    const currentText = stepToEdit[focusedField];
    const newText = currentText + " " + tag;
    handleUpdateStep(focusedStepId, focusedField, newText);
  };

  // Load default template text into active step
  const handleLoadTemplateIntoStep = (stepId: string, templateId: string) => {
    const tpl = templates.find(t => t.id === templateId);
    if (!tpl) return;
    setCampSteps(campSteps.map(s => {
      if (s.id === stepId) {
        return {
          ...s,
          subject: tpl.subject,
          body: tpl.body
        };
      }
      return s;
    }));
  };

  // Save the custom campaign sequence
  const handleSaveCampaign = async () => {
    if (!campName.trim()) {
      alert("Please enter a campaign name.");
      return;
    }

    const campaignPayload = {
      id: selectedCampaign?.id || `camp-${Date.now()}`,
      name: campName.trim(),
      description: campDescription.trim(),
      steps: campSteps,
      enrollmentCount: selectedCampaign?.enrollmentCount || 0
    };

    try {
      const res = await fetch('/api/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(campaignPayload)
      });
      if (res.ok) {
        await fetchCampaigns();
        setActiveView('list');
      } else {
        alert("Failed to save campaign sequence.");
      }
    } catch (e) {
      console.error("Error saving campaign", e);
    }
  };

  // Delete campaign sequence
  const handleDeleteCampaign = async (id: string) => {
    if (!confirm("Are you sure you want to delete this outreach campaign sequence and its scheduled emails?")) {
      return;
    }
    try {
      const res = await fetch(`/api/campaigns/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        const data = await res.json();
        if (data.campaigns) {
          setCampaigns(data.campaigns);
          persistCampaignsToStorage(data.campaigns);
        }
        if (data.scheduledQueue && onScheduledUpdate) {
          onScheduledUpdate(data.scheduledQueue);
        }
        await fetchCampaigns();
        setActiveView('list');
      } else {
        alert("Failed to delete campaign.");
      }
    } catch (e) {
      console.error("Error deleting campaign", e);
    }
  };

  // Reset to system defaults
  const handleResetDefaults = async () => {
    if (!confirm("Are you sure you want to reset all campaigns to defaults? This will overwrite custom sequences.")) {
      return;
    }
    try {
      const res = await fetch('/api/campaigns/reset', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        const defaultCamps = data.campaigns || [];
        setCampaigns(defaultCamps);
        persistCampaignsToStorage(defaultCamps);
        await fetchCampaigns();
      }
    } catch (e) {
      console.error("Error resetting defaults", e);
    }
  };

  // Setup enrollment screen
  const handleOpenEnrollment = (campaign: Campaign) => {
    setSelectedCampaign(campaign);
    // Pre-select new eligible leads by default
    const initialSelect = new Set<string>();
    uncontactedLeads
      .filter(l => l.Status === 'New' && l.PersonalizedObservation?.trim())
      .forEach(l => initialSelect.add(l.id));
    setSelectedLeadIds(initialSelect);
    setScheduledSuccessCount(null);
    setActiveView('enroll');
  };

  // Math helper to substitute placeholder variables
  const replaceVariables = (text: string, lead: Lead, originalSubject: string = '') => {
    return text
      .replace(/{{Name}}/g, lead.Name || '')
      .replace(/{{BusinessName}}/g, lead.BusinessName || lead.Name || '')
      .replace(/{{Niche}}/g, lead.Niche || 'Fitness / Business Coaching')
      .replace(/{{Country}}/g, lead.Country || '')
      .replace(/{{Website}}/g, lead.Website || '')
      .replace(/{{ProfileURL}}/g, lead.ProfileURL || '')
      .replace(/{{DealValue}}/g, lead['Deal Value'] || '$800')
      .replace(/{{Deal Value}}/g, lead['Deal Value'] || '$800')
      .replace(/{{PersonalizedObservation}}/g, lead.PersonalizedObservation || 'your coaching content and client approach')
      .replace(/{{PainPoint}}/g, lead.PainPoint || 'lost leads across Instagram DMs and spreadsheets')
      .replace(/{{Original Subject}}/g, originalSubject)
      .replace(/{{DemoLink}}/g, lead.DemoLink || 'https://coachgrowthos.com/demo');
  };

  // ENROLL AND MASS DISPATCH MATH
  const handleLaunchCampaignEnrollment = async () => {
    if (!selectedCampaign) return;
    const targetedLeads = leads.filter(l => selectedLeadIds.has(l.id));

    if (targetedLeads.length === 0) {
      alert("Please select at least one prospect to enroll.");
      return;
    }

    setIsScheduling(true);
    const scheduledEmails: ScheduledEmail[] = [];
    let currentDayOffset = 1;
    let emailsScheduledToday = 0;

    targetedLeads.forEach((lead, leadIdx) => {
      // Calculate batch rate-limit layout day offset for this lead's Step 1
      if (emailsScheduledToday >= emailsPerDay) {
        currentDayOffset++;
        emailsScheduledToday = 0;
      }

      // Step-by-step delay multiplier
      let cumulativeDelay = 0;
      let firstSubjectReplaced = '';

      selectedCampaign.steps.forEach((step, stepIdx) => {
        cumulativeDelay += step.delayDays;

        // EST standard business-hour delivery layout
        const randomHour = Math.floor(Math.random() * (16 - 9) + 9); // 9 AM to 4 PM
        const randomMinute = Math.floor(Math.random() * 59);

        const scheduledDateEST = computeESTScheduleDate(currentDayOffset + cumulativeDelay, randomHour, randomMinute);

        // Subject replacements
        let subject = replaceVariables(step.subject, lead, firstSubjectReplaced);
        if (stepIdx === 0) {
          firstSubjectReplaced = subject;
        }

        let body = replaceVariables(step.body, lead, firstSubjectReplaced);
        // Append gentle opt-out disclaimer to build natural, transparent deliverability
        body += "\n\n(If you'd prefer not to hear from me, simply reply 'no thanks' and I won't follow up.)";

        scheduledEmails.push({
          id: `sched_camp_${selectedCampaign.id}_${lead.id}_step_${step.stepNumber}_${Date.now()}`,
          leadId: lead.id,
          leadName: lead.Name || 'Unknown',
          emailAddress: lead.Email,
          subject,
          body,
          scheduledAt: scheduledDateEST.toISOString(),
          status: 'Scheduled',
          isFollowUp: stepIdx > 0,
          followUpStep: stepIdx > 0 ? step.stepNumber : undefined,
          campaignId: selectedCampaign.id
        });
      });

      emailsScheduledToday++;
    });

    try {
      // Increment enrollment analytics counters
      await fetch('/api/campaigns/enroll', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaignId: selectedCampaign.id, count: targetedLeads.length })
      });

      // Pass emails to global scheduling queue
      onScheduleCampaign(scheduledEmails);
      setScheduledSuccessCount(scheduledEmails.length);
      await fetchCampaigns();
    } catch (e) {
      console.error("Enrollment failed", e);
    } finally {
      setIsScheduling(false);
    }
  };

  // Enrollment mathematical schedule projection preview
  const enrollmentPreview = useMemo(() => {
    const targetedLeads = leads.filter(l => selectedLeadIds.has(l.id));
    if (targetedLeads.length === 0 || !selectedCampaign || selectedCampaign.steps.length === 0) return null;

    let currentDayOffset = 1;
    let emailsScheduledToday = 0;
    const previewList: { leadName: string; step: number; estDateStr: string }[] = [];

    targetedLeads.slice(0, 3).forEach((lead) => {
      if (emailsScheduledToday >= emailsPerDay) {
        currentDayOffset++;
        emailsScheduledToday = 0;
      }

      let cumulativeDelay = 0;
      selectedCampaign.steps.slice(0, 2).forEach((step, sIdx) => {
        cumulativeDelay += step.delayDays;
        const randomHour = Math.floor(Math.random() * (16 - 9 + 1) + 9);
        const randomMinute = Math.floor(Math.random() * 60);
        const estDate = computeESTScheduleDate(currentDayOffset + cumulativeDelay, randomHour, randomMinute);
        previewList.push({
          leadName: lead.Name || 'Prospect',
          step: step.stepNumber,
          estDateStr: formatESTTime(estDate.toISOString())
        });
      });
      emailsScheduledToday++;
    });

    const totalDays = Math.ceil(targetedLeads.length / emailsPerDay);
    return {
      totalDays,
      previewList
    };
  }, [selectedLeadIds, selectedCampaign, emailsPerDay, leads]);

  const campaignPerformanceData = useMemo(() => {
    return campaigns.map((c) => {
      const campEnrolled = c.enrollmentCount || 0;
      if (campEnrolled === 0) {
        return {
          id: c.id,
          name: c.name,
          steps: c.steps.length,
          enrolled: 0,
          openRate: 0,
          replyRate: 0,
          conversions: 0
        };
      }

      const repliedLeads = leads.filter(l => l.Status === 'Replied' || l.Status === 'Meeting Scheduled' || l.Status === 'Closed Won').length;
      const conversionLeads = leads.filter(l => l.Status === 'Closed Won' || l.Status === 'Meeting Scheduled').length;

      const openRate = Math.min(100, Math.round((repliedLeads / campEnrolled) * 100) + (repliedLeads > 0 ? 30 : 0));
      const replyRate = Math.min(100, Math.round((repliedLeads / campEnrolled) * 100));
      const conversions = Math.min(campEnrolled, Math.floor(conversionLeads / Math.max(1, campaigns.length)));

      return {
        id: c.id,
        name: c.name,
        steps: c.steps.length,
        enrolled: campEnrolled,
        openRate: repliedLeads > 0 ? openRate : 0,
        replyRate: repliedLeads > 0 ? replyRate : 0,
        conversions: conversions
      };
    });
  }, [campaigns, leads]);

  const realTotalConversions = useMemo(() => {
    return leads.filter(l => l.Status === 'Closed Won' || l.Status === 'Meeting Scheduled' || l.Status === 'Replied').length;
  }, [leads]);

  const realAvgOpenRate = useMemo(() => {
    const active = campaignPerformanceData.filter(c => c.enrolled > 0);
    if (active.length === 0) return 0;
    const sum = active.reduce((acc, curr) => acc + curr.openRate, 0);
    return Math.round(sum / active.length);
  }, [campaignPerformanceData]);

  const realAvgReplyRate = useMemo(() => {
    const active = campaignPerformanceData.filter(c => c.enrolled > 0);
    if (active.length === 0) return 0;
    const sum = active.reduce((acc, curr) => acc + curr.replyRate, 0);
    return Math.round(sum / active.length);
  }, [campaignPerformanceData]);


  return (
    <div className="h-full flex flex-col bg-[#050505] p-6 overflow-y-auto">
      <div className="max-w-5xl w-full mx-auto space-y-6 pb-12">
        
        {/* ================= HEADER ================= */}
        <div className="flex justify-between items-center bg-[#0D0D0D] border border-[#222] p-5 rounded-2xl">
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
              <Layers className="text-sky-400" size={22} />
              <span>Outreach Sequence Campaigns</span>
            </h1>
            <p className="text-xs text-[#888] mt-1">
              Build high-converting multi-step outreach sequences, load/tweak customized coach templates, and enroll target prospects.
            </p>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            {activeView === 'list' && (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveView('performance')}
                  className="bg-[#141414] hover:bg-[#1A1A1A] text-sky-400 border border-sky-500/30 px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shadow-lg"
                >
                  <BarChart2 size={14} />
                  <span>Campaign Performance</span>
                </button>
                <button
                  onClick={() => handleOpenBuilder()}
                  className="bg-sky-500 hover:bg-sky-400 text-black px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shadow-lg"
                >
                  <Plus size={14} />
                  <span>Create Custom Sequence</span>
                </button>
              </div>
            )}
            {activeView !== 'list' && (
              <button
                onClick={() => {
                  setActiveView('list');
                  setScheduledSuccessCount(null);
                }}
                className="bg-[#141414] hover:bg-[#1A1A1A] text-white border border-[#333] px-4 py-2 rounded-xl text-xs font-semibold transition-all"
              >
                Back to Dashboard
              </button>
            )}
          </div>
        </div>

        {/* ================= SUCCESS BANNER ================= */}
        {scheduledSuccessCount !== null && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-2xl p-5 flex justify-between items-center animate-in fade-in duration-300">
            <div className="flex items-center space-x-3">
              <CheckCircle2 size={24} className="text-emerald-400" />
              <div>
                <h2 className="text-sm font-bold text-white">Prospects Enrolled in Sequence</h2>
                <p className="text-xs text-emerald-400/90 mt-0.5">
                  Successfully registered {scheduledSuccessCount} step delivery timelines strictly within EST business hours.
                </p>
              </div>
            </div>
            {onNavigateToScheduled && (
              <button 
                onClick={onNavigateToScheduled}
                className="bg-emerald-500 hover:bg-emerald-400 text-black px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center space-x-1"
              >
                <span>View Scheduled Queue</span>
                <ArrowRight size={14} />
              </button>
            )}
          </div>
        )}

        {/* ================= VIEW 1: CAMPAIGNS DASHBOARD ================= */}
        {activeView === 'list' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xs font-bold uppercase tracking-wider text-[#666]">Active Outreach Workspaces</h2>
              <button 
                onClick={handleResetDefaults}
                className="text-[10px] text-[#555] hover:text-red-400 transition-colors font-mono"
              >
                Reset Default Sequences
              </button>
            </div>

            {loadingCampaigns ? (
              <div className="p-12 text-center text-xs text-[#888] italic bg-[#0D0D0D] border border-[#222] rounded-2xl">
                Retrieving active campaigns...
              </div>
            ) : campaigns.length === 0 ? (
              <div className="p-12 text-center bg-[#0D0D0D] border border-[#222] rounded-2xl space-y-3">
                <p className="text-xs text-[#666]">No active campaigns found. Get started by building a sequence or loading default templates.</p>
                <button
                  onClick={() => handleOpenBuilder()}
                  className="bg-sky-500/10 border border-sky-500/30 text-sky-400 hover:bg-sky-500/20 px-4 py-2 rounded-xl text-xs font-bold transition-all"
                >
                  Create Campaign Sequence from Scratch
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {campaigns.map((camp) => (
                  <div 
                    key={camp.id}
                    className="bg-[#0D0D0D] border border-[#222] hover:border-sky-500/30 rounded-2xl p-5 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all"
                  >
                    <div className="space-y-1.5 min-w-0 flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-bold text-white text-sm">{camp.name}</h3>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/10 text-sky-400 border border-sky-500/20 font-bold">
                          {camp.steps.length} Steps
                        </span>
                      </div>
                      <p className="text-xs text-[#777] line-clamp-1">{camp.description || "No description provided."}</p>
                      
                      {/* Step sequence visualization preview */}
                      <div className="flex items-center space-x-2 pt-2 overflow-x-auto text-[10px] text-[#555] font-mono">
                        {camp.steps.map((st, sIdx) => (
                          <React.Fragment key={st.id}>
                            {sIdx > 0 && <ChevronRight size={10} className="text-[#333] shrink-0" />}
                            <span className="bg-[#141414] border border-[#222] px-2 py-1 rounded-lg shrink-0">
                              Step {st.stepNumber} ({st.delayDays === 0 ? 'Day 1' : `+${st.delayDays}d`})
                            </span>
                          </React.Fragment>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 shrink-0 self-end md:self-auto">
                      <div className="text-right mr-3 hidden sm:block">
                        <div className="text-[10px] uppercase font-bold text-[#555]">Active Enrolled</div>
                        <div className="text-xs font-mono font-bold text-white">{camp.enrollmentCount || 0} Leads</div>
                      </div>

                      <button
                        onClick={() => handleOpenEnrollment(camp)}
                        className="bg-emerald-500 hover:bg-emerald-400 text-black px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 shadow-lg"
                      >
                        <UserCheck size={13} />
                        <span>Enroll Prospects</span>
                      </button>

                      <button
                        onClick={() => handleOpenBuilder(camp)}
                        className="bg-[#141414] hover:bg-[#1F1F1F] text-white border border-[#252525] p-2 rounded-xl text-xs font-bold transition-all"
                        title="Edit Sequence steps"
                      >
                        <Edit3 size={13} />
                      </button>

                      <button
                        onClick={() => handleDeleteCampaign(camp.id)}
                        className="bg-[#141414] hover:bg-red-950/30 text-[#444] hover:text-red-400 border border-[#252525] hover:border-red-500/20 p-2 rounded-xl text-xs transition-all"
                        title="Delete campaign"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= VIEW 2: SEQUENCE BUILDER ================= */}
        {activeView === 'builder' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Steps Sequence List & Editor (Left 2/3) */}
            <div className="lg:col-span-2 space-y-5">
              
              {/* Metadata form */}
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
                <h2 className="text-sm font-bold uppercase tracking-wider text-white">Campaign Details</h2>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Campaign Sequence Name</label>
                    <input 
                      type="text"
                      placeholder="e.g. Online Fitness Coach Cold Sequence"
                      value={campName}
                      onChange={(e) => setCampName(e.target.value)}
                      className="w-full bg-[#141414] border border-[#252525] rounded-xl px-3 py-2 text-xs text-white placeholder-[#444] focus:outline-none focus:border-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Purpose / Description</label>
                    <input 
                      type="text"
                      placeholder="e.g. Targeting online coaches with customized DM system demo offers."
                      value={campDescription}
                      onChange={(e) => setCampDescription(e.target.value)}
                      className="w-full bg-[#141414] border border-[#252525] rounded-xl px-3 py-2 text-xs text-white placeholder-[#444] focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>
              </div>

              {/* Step list sequence */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-[#666]">Sequence Flow Steps</h3>
                  <button
                    onClick={handleAddStep}
                    className="bg-sky-500/10 border border-sky-500/30 text-sky-400 hover:bg-sky-500/20 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all flex items-center space-x-1"
                  >
                    <Plus size={12} />
                    <span>Add sequence step</span>
                  </button>
                </div>

                {campSteps.map((step, idx) => {
                  const isFocused = focusedStepId === step.id;

                  return (
                    <div 
                      key={step.id}
                      onClick={() => setFocusedStepId(step.id)}
                      className={cn(
                        "bg-[#0D0D0D] border rounded-2xl overflow-hidden transition-all",
                        isFocused ? "border-sky-500/50 ring-1 ring-sky-500/30" : "border-[#222]"
                      )}
                    >
                      {/* Step Header */}
                      <div className="bg-[#121212] px-4 py-3 flex justify-between items-center border-b border-[#1F1F1F]">
                        <div className="flex items-center space-x-3">
                          <span className="w-5 h-5 rounded-full bg-sky-500 text-black text-xs font-bold flex items-center justify-center">
                            {step.stepNumber}
                          </span>
                          <span className="text-xs font-bold text-white">Step {step.stepNumber} Outreach</span>
                        </div>

                        <div className="flex items-center space-x-3">
                          {/* Delay configuration */}
                          {idx > 0 ? (
                            <div className="flex items-center space-x-1.5 text-xs text-[#888]">
                              <span>Wait</span>
                              <input 
                                type="number"
                                min={1}
                                max={30}
                                value={step.delayDays}
                                onChange={(e) => handleUpdateStep(step.id, 'delayDays', parseInt(e.target.value) || 1)}
                                className="w-10 bg-[#1A1A1A] border border-[#333] rounded px-1 text-center font-mono text-white text-[11px] py-0.5 focus:outline-none"
                              />
                              <span>days after previous step</span>
                            </div>
                          ) : (
                            <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded text-emerald-400 font-bold font-mono">
                              Dispatches Day 1 (Instant)
                            </span>
                          )}

                          {campSteps.length > 1 && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRemoveStep(step.id);
                              }}
                              className="text-[#444] hover:text-red-400 transition-colors"
                              title="Delete Step"
                            >
                              <X size={14} />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Step Inputs */}
                      <div className="p-4 space-y-3">
                        {/* Pre-fill template select dropdown */}
                        <div className="flex items-center space-x-2 pb-1.5 border-b border-[#1A1A1A] text-[11px]">
                          <span className="text-[#555]">Quick Load Outreach Template:</span>
                          <select
                            onChange={(e) => {
                              if (e.target.value) {
                                handleLoadTemplateIntoStep(step.id, e.target.value);
                                e.target.value = ""; // reset selection
                              }
                            }}
                            className="bg-[#141414] border border-[#222] text-white text-[10px] rounded px-2 py-0.5 focus:outline-none"
                          >
                            <option value="">-- Choose custom template to load --</option>
                            {templates.map(t => (
                              <option key={t.id} value={t.id}>{t.name}</option>
                            ))}
                          </select>
                        </div>

                        {/* Subject */}
                        <div>
                          <label className="block text-[9px] uppercase font-bold text-[#555] mb-1">Email Subject Line</label>
                          <input 
                            type="text"
                            placeholder="Subject line with {{Name}}"
                            value={step.subject}
                            onFocus={() => {
                              setFocusedStepId(step.id);
                              setFocusedField('subject');
                            }}
                            onChange={(e) => handleUpdateStep(step.id, 'subject', e.target.value)}
                            className="w-full bg-[#141414] border border-[#252525] rounded-xl px-3 py-2 text-xs text-white placeholder-[#333] focus:outline-none focus:border-sky-500"
                          />
                        </div>

                        {/* Body */}
                        <div>
                          <label className="block text-[9px] uppercase font-bold text-[#555] mb-1">Email Message Body</label>
                          <textarea 
                            rows={6}
                            placeholder="Write outreach email or quick bump template..."
                            value={step.body}
                            onFocus={() => {
                              setFocusedStepId(step.id);
                              setFocusedField('body');
                            }}
                            onChange={(e) => handleUpdateStep(step.id, 'body', e.target.value)}
                            className="w-full bg-[#141414] border border-[#252525] rounded-xl p-3 text-xs text-[#CCC] placeholder-[#333] focus:outline-none focus:border-sky-500 resize-none leading-relaxed font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Action save/cancel */}
              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center space-x-3">
                  <button
                    onClick={handleSaveCampaign}
                    className="bg-sky-500 hover:bg-sky-400 text-black px-6 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xl"
                  >
                    Save Sequence Campaign
                  </button>
                  <button
                    onClick={() => setActiveView('list')}
                    className="bg-[#141414] hover:bg-[#1A1A1A] text-white border border-[#333] px-6 py-2.5 rounded-xl text-xs font-semibold transition-all"
                  >
                    Cancel
                  </button>
                </div>
                {selectedCampaign && (
                  <button
                    onClick={() => handleDeleteCampaign(selectedCampaign.id)}
                    className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5"
                  >
                    <Trash2 size={13} />
                    <span>Delete Campaign</span>
                  </button>
                )}
              </div>

            </div>

            {/* Personalized Variable Tags Sidebar (Right 1/3) */}
            <div className="space-y-4">
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4 sticky top-6">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center space-x-1.5">
                    <Sparkles size={13} className="text-sky-400" />
                    <span>Personalization Tags</span>
                  </h3>
                  <p className="text-[10px] text-[#666] mt-1">
                    Click any tag below to insert it directly into your active subject or message body field.
                  </p>
                </div>

                <div className="space-y-2">
                  <div className="text-[10px] uppercase font-bold text-[#555]">General Prospect Fields</div>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { code: '{{Name}}', desc: 'Prospect Name' },
                      { code: '{{BusinessName}}', desc: 'Coaching Business' },
                      { code: '{{Niche}}', desc: 'Coaching Niche' },
                      { code: '{{Country}}', desc: 'Location' },
                      { code: '{{Website}}', desc: 'URL/Insta' }
                    ].map(tag => (
                      <button
                        key={tag.code}
                        onClick={() => handleInsertTag(tag.code)}
                        className="bg-[#141414] hover:bg-sky-500/10 border border-[#252525] hover:border-sky-500/20 px-2 py-1.5 rounded-lg text-[10px] text-white hover:text-sky-400 font-mono transition-all text-left flex justify-between items-center w-full"
                        title={tag.desc}
                      >
                        <span>{tag.code}</span>
                        <span className="text-[#555] text-[9px] font-sans">{tag.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-[#1F1F1F] bg-[#141414]/40 p-3 rounded-xl text-[10px] text-[#666] leading-relaxed flex items-start space-x-2">
                  <Info size={13} className="text-sky-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Tips:</strong> Place your cursor inside the text area first, then click a merge tag to insert. When enrolling prospects, placeholders resolve to actual values in the scheduler pipeline.
                  </span>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ================= VIEW 3: PROSPECT ENROLLMENT ================= */}
        {activeView === 'enroll' && selectedCampaign && (
          <div className="space-y-6">
            
            {/* Step 1: Select Candidates */}
            <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-sky-500 text-black text-xs font-bold flex items-center justify-center">1</span>
                    <span>Select Prospects for "{selectedCampaign.name}"</span>
                  </h2>
                  <p className="text-xs text-[#777] mt-0.5">
                    Choose eligible online coaching prospects to enroll in this outreach sequence flow.
                  </p>
                </div>
                <div className="text-xs text-[#888]">
                  <span className="text-sky-400 font-bold">{selectedLeadIds.size}</span> selected of {uncontactedLeads.length} total uncontacted
                </div>
              </div>

              {/* Sub-tabs & Search & Batch select */}
              <div className="flex justify-between items-center gap-3 pt-2">
                <div className="flex items-center space-x-1 bg-[#141414] border border-[#252525] p-1 rounded-xl text-xs">
                  <button
                    onClick={() => setLeadFilterTab('new')}
                    className={cn(
                      "px-3 py-1.5 rounded-lg font-semibold transition-all",
                      leadFilterTab === 'new' ? "bg-[#252525] text-white" : "text-[#888] hover:text-[#CCC]"
                    )}
                  >
                    New Prospects ({uncontactedLeads.filter(l => l.Status === 'New').length})
                  </button>
                  <button
                    onClick={() => setLeadFilterTab('all_active')}
                    className={cn(
                      "px-3 py-1.5 rounded-lg font-semibold transition-all",
                      leadFilterTab === 'all_active' ? "bg-[#252525] text-white" : "text-[#888] hover:text-[#CCC]"
                    )}
                  >
                    All Active ({uncontactedLeads.length})
                  </button>
                  <button
                    onClick={() => setLeadFilterTab('needs_research')}
                    className={cn(
                      "px-3 py-1.5 rounded-lg font-semibold transition-all",
                      leadFilterTab === 'needs_research' ? "bg-[#252525] text-white" : "text-[#888] hover:text-[#CCC]"
                    )}
                  >
                    Needs Research ({uncontactedLeads.filter(l => !l.PersonalizedObservation?.trim()).length})
                  </button>
                </div>

                <div className="flex items-center space-x-2">
                  <select
                    value={nicheEnrollFilter}
                    onChange={(e) => setNicheEnrollFilter(e.target.value as any)}
                    className="bg-[#141414] border border-[#252525] text-xs text-[#AAA] rounded-xl px-3 py-2 outline-none focus:border-sky-500"
                  >
                    <option value="all">All Niches</option>
                    <option value="fitness">Fitness Coaches</option>
                    <option value="business">Business Coaches</option>
                  </select>

                  <div className="relative">
                    <Search size={13} className="absolute left-3 top-2.5 text-[#666]" />
                    <input 
                      type="text"
                      placeholder="Filter by name, niche..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-[#141414] border border-[#252525] text-xs rounded-xl pl-8 pr-3 py-2 text-white placeholder-[#555] focus:outline-none focus:border-sky-500 w-56"
                    />
                  </div>

                  <button
                    onClick={selectAllFiltered}
                    className="bg-[#181818] hover:bg-[#222] border border-[#333] text-[#DDD] px-3 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center space-x-1"
                  >
                    <CheckSquare size={13} />
                    <span>Select All</span>
                  </button>
                  <button
                    onClick={deselectAllFiltered}
                    className="bg-[#181818] hover:bg-[#222] border border-[#333] text-[#888] hover:text-white px-3 py-2 rounded-xl text-xs font-semibold transition-colors"
                  >
                    Clear
                  </button>
                </div>
              </div>

              {/* Leads picker table */}
              <div className="border border-[#222] rounded-xl overflow-hidden bg-[#080808] max-h-64 overflow-y-auto">
                {filteredLeads.length === 0 ? (
                  <div className="p-8 text-center text-xs text-[#666] italic">
                    No uncontacted leads matching this filter.
                  </div>
                ) : (
                  <div className="divide-y divide-[#1A1A1A]">
                    {filteredLeads.map((lead) => {
                      const isSelected = selectedLeadIds.has(lead.id);
                      const hasObservation = !!lead.PersonalizedObservation?.trim();

                      return (
                        <div 
                          key={lead.id}
                          onClick={() => toggleLead(lead.id)}
                          className={cn(
                            "p-3 flex items-center justify-between hover:bg-[#121212] cursor-pointer transition-colors text-xs",
                            isSelected ? "bg-sky-500/5" : ""
                          )}
                        >
                          <div className="flex items-center space-x-3 min-w-0 flex-1">
                            <div className="text-[#666] hover:text-white">
                              {isSelected ? (
                                <CheckSquare size={16} className="text-sky-400" />
                              ) : (
                                <Square size={16} />
                              )}
                            </div>
                            <div className="min-w-0 flex-1 pr-4">
                              <div className="flex items-center space-x-2">
                                <span className="font-semibold text-white truncate">{lead.Name || 'Unnamed Prospect'}</span>
                                <span className="text-[10px] bg-[#222] text-[#AAA] px-2 py-0.5 rounded font-medium">
                                  {lead.Niche || 'Coaching'}
                                </span>
                                <span className="text-[10px] text-[#666] font-mono">{lead.Email}</span>
                              </div>
                              <div className="text-[11px] text-[#777] truncate mt-0.5">
                                {hasObservation ? (
                                  <span className="text-emerald-400/90 flex items-center space-x-1">
                                    <Sparkles size={11} className="inline mr-1" />
                                    <span>{lead.PersonalizedObservation}</span>
                                  </span>
                                ) : (
                                  <span className="text-amber-500/80 italic">Observation not generated yet</span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 shrink-0">
                            <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold border border-[#333] bg-[#141414] text-[#888]">
                              {lead.Status}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Step 2: Rate Limit Scheduling */}
            <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                  <span className="w-5 h-5 rounded-full bg-sky-500 text-black text-xs font-bold flex items-center justify-center">2</span>
                  <span>Scheduling Rate Limits & EST Deliveries</span>
                </h2>
                <p className="text-xs text-[#777] mt-0.5">
                  Restricts dispatch speeds and delivers emails during natural business hours in EST (Mon-Fri 9:00 AM - 4:30 PM).
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#141414] border border-[#252525] rounded-xl p-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#CCC] flex items-center space-x-1.5">
                    <Calendar size={13} className="text-sky-400" />
                    <span>Daily Outbox Limit</span>
                  </label>
                  <p className="text-[10px] text-[#666]">Spreads enrollments over consecutive working days</p>
                  <div className="flex items-center space-x-2 pt-1">
                    {[5, 10, 15, 20].map((num) => (
                      <button
                        key={num}
                        onClick={() => setEmailsPerDay(num)}
                        className={cn(
                          "px-3 py-1.5 rounded-lg text-xs font-bold border transition-all",
                          emailsPerDay === num ? "bg-sky-500 text-black border-sky-400" : "bg-[#1E1E1E] text-[#888] border-[#333] hover:text-white"
                        )}
                      >
                        {num}/day
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#CCC] flex items-center space-x-1.5">
                    <Clock size={13} className="text-sky-400" />
                    <span>Active Office Hours</span>
                  </label>
                  <p className="text-[10px] text-[#666]">Automatic Eastern Standard Time Zone alignment</p>
                  <div className="pt-1">
                    <span className="inline-block text-xs font-mono font-bold text-sky-400 bg-sky-500/10 border border-sky-500/20 px-3 py-1.5 rounded-lg">
                      Mon – Fri, 9:00 AM – 4:30 PM EST
                    </span>
                  </div>
                </div>
              </div>

              {/* Dynamic Dispatch Timelines List */}
              {enrollmentPreview && (
                <div className="bg-[#101010] border border-[#202020] rounded-xl p-4 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-[#888] font-medium">Estimated sequence projection:</span>
                    <span className="text-sky-400 font-semibold font-mono">
                      {selectedLeadIds.size} leads over ~{enrollmentPreview.totalDays} business days
                    </span>
                  </div>
                  <div className="space-y-1.5 pt-1">
                    {enrollmentPreview.previewList.map((p, idx) => (
                      <div key={idx} className="flex justify-between items-center text-[11px] text-[#555] font-mono">
                        <span className="text-[#888]">Step {p.step} Outreach ({p.leadName})</span>
                        <span className="text-[#AAA]">{p.estDateStr}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Enroll launch submit CTA */}
            <div className="flex justify-between items-center pt-2">
              <div className="text-xs text-[#777] flex items-center space-x-1.5">
                <ShieldCheck size={14} className="text-emerald-400" />
                <span>Enrolling queues all steps automatically. Active delays are calculated sequentially.</span>
              </div>

              <button 
                onClick={handleLaunchCampaignEnrollment}
                disabled={selectedLeadIds.size === 0 || isScheduling}
                className="bg-sky-500 hover:bg-sky-400 text-black px-8 py-3 rounded-xl text-sm font-bold transition-colors disabled:opacity-40 disabled:bg-[#333] disabled:text-[#777] flex items-center space-x-2 shadow-xl"
              >
                {isScheduling ? (
                  <span>Enrolling in sequence...</span>
                ) : (
                  <>
                    <Send size={15} />
                    <span>Launch & Enroll ({selectedLeadIds.size} Prospects)</span>
                  </>
                )}
              </button>
            </div>

          </div>
        )}

        {/* ================= VIEW 4: CAMPAIGN PERFORMANCE DASHBOARD ================= */}
        {activeView === 'performance' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center bg-[#0D0D0D] border border-[#222] p-4 rounded-2xl">
              <div>
                <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2">
                  <BarChart2 className="text-sky-400" size={16} />
                  <span>Campaign Performance Analytics</span>
                </h2>
                <p className="text-xs text-[#777] mt-0.5">Real-time open rates, reply rates, and conversion metrics across active outreach sequences.</p>
              </div>
              <button
                onClick={() => setActiveView('list')}
                className="bg-[#141414] hover:bg-[#1A1A1A] text-white border border-[#333] px-3 py-1.5 rounded-xl text-xs font-medium"
              >
                Back to Sequences
              </button>
            </div>

            {/* Metric Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-4 space-y-1">
                <div className="text-[10px] uppercase font-bold text-[#666]">Active Sequences</div>
                <div className="text-xl font-bold text-white font-mono">{campaigns.length}</div>
                <div className="text-[10px] text-emerald-400">100% operational</div>
              </div>
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-4 space-y-1">
                <div className="text-[10px] uppercase font-bold text-[#666]">Avg. Open Rate</div>
                <div className="text-xl font-bold text-sky-400 font-mono">{realAvgOpenRate}%</div>
                <div className="text-[10px] text-emerald-400">Based on live lead statuses</div>
              </div>
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-4 space-y-1">
                <div className="text-[10px] uppercase font-bold text-[#666]">Avg. Reply Rate</div>
                <div className="text-xl font-bold text-emerald-400 font-mono">{realAvgReplyRate}%</div>
                <div className="text-[10px] text-emerald-400">Based on live lead responses</div>
              </div>
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-4 space-y-1">
                <div className="text-[10px] uppercase font-bold text-[#666]">Total Conversions</div>
                <div className="text-xl font-bold text-amber-400 font-mono">
                  {realTotalConversions}
                </div>
                <div className="text-[10px] text-[#888]">Active replies & closed deals</div>
              </div>
            </div>

            {/* Recharts Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Chart 1: Open Rates vs Reply Rates */}
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white">Open Rates vs Reply Rates (%)</h3>
                  <span className="text-[10px] font-mono text-[#666]">Live Data</span>
                </div>
                <div className="h-64 w-full pt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={campaignPerformanceData.map(c => ({
                      name: c.name.length > 18 ? c.name.substring(0, 16) + '...' : c.name,
                      openRate: c.openRate,
                      replyRate: c.replyRate
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                      <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} />
                      <YAxis stroke="#666" fontSize={10} tickLine={false} unit="%" />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#111', borderColor: '#333', borderRadius: '12px', fontSize: '11px', color: '#fff' }} 
                      />
                      <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                      <Bar dataKey="openRate" name="Open Rate %" fill="#38bdf8" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="replyRate" name="Reply Rate %" fill="#34d399" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart 2: Conversions & Enrolled Leads */}
              <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-white">Prospect Enrolments & Conversions</h3>
                  <span className="text-[10px] font-mono text-[#666]">Live Data</span>
                </div>
                <div className="h-64 w-full pt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={campaignPerformanceData.map(c => ({
                      name: c.name.length > 18 ? c.name.substring(0, 16) + '...' : c.name,
                      enrolled: c.enrolled,
                      conversions: c.conversions
                    }))}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                      <XAxis dataKey="name" stroke="#666" fontSize={10} tickLine={false} />
                      <YAxis stroke="#666" fontSize={10} tickLine={false} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#111', borderColor: '#333', borderRadius: '12px', fontSize: '11px', color: '#fff' }} 
                      />
                      <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                      <Bar dataKey="enrolled" name="Enrolled Prospects" fill="#a855f7" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="conversions" name="Total Conversions" fill="#fbbf24" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

            {/* Campaign Breakdown Table */}
            <div className="bg-[#0D0D0D] border border-[#222] rounded-2xl p-5 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">Detailed Campaign Performance Breakdown</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-[#222] text-[#666] font-mono text-[10px]">
                      <th className="pb-3 font-semibold">CAMPAIGN NAME</th>
                      <th className="pb-3 font-semibold">STEPS</th>
                      <th className="pb-3 font-semibold">ENROLLED</th>
                      <th className="pb-3 font-semibold">OPEN RATE</th>
                      <th className="pb-3 font-semibold">REPLY RATE</th>
                      <th className="pb-3 font-semibold">CONVERSIONS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1A1A1A]">
                    {campaignPerformanceData.map((c) => (
                      <tr key={c.id} className="hover:bg-[#141414] transition-colors">
                        <td className="py-3 font-medium text-white flex items-center space-x-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                          <span>{c.name}</span>
                        </td>
                        <td className="py-3 text-[#AAA] font-mono">{c.steps} Steps</td>
                        <td className="py-3 text-white font-mono">{c.enrolled}</td>
                        <td className="py-3 text-sky-400 font-mono font-bold">{c.openRate}%</td>
                        <td className="py-3 text-emerald-400 font-mono font-bold">{c.replyRate}%</td>
                        <td className="py-3 text-amber-400 font-mono font-bold">{c.conversions} Deals</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
