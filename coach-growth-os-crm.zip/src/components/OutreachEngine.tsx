import React, { useState, useEffect, useRef } from 'react';
import { Lead, Template, TemplateCategory, ScheduledEmail } from '../types';
import { 
  Send, AlertCircle, RefreshCw, Wand2, ChevronDown, 
  Eye, Edit3, Sparkles, CheckCircle2, SlidersHorizontal, Tag, Clock
} from 'lucide-react';
import { cn } from '../utils';

interface Props {
  leads: Lead[];
  token: string | null;
  onRequestAuth: () => void;
  onSuccess: (leads: Lead[]) => void;
  selectedLeadIds: Set<string>;
  onEmailSent?: (info: { leadName: string; email: string; subject: string; leadId?: string }) => void;
  onEmailScheduled?: (email: ScheduledEmail) => void;
}

const CATEGORY_COLORS: Record<string, { color: string; bg: string }> = {
  'Initial Pitch — Fitness Coach': { color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  'Initial Pitch — Business Coach': { color: 'text-blue-400', bg: 'bg-blue-500/10' },
  'Initial Pitch — General Coach': { color: 'text-teal-400', bg: 'bg-teal-500/10' },
  'Follow-Up 1 — No Reply': { color: 'text-purple-400', bg: 'bg-purple-500/10' },
  'Follow-Up 2 — Low-Pressure Follow-Up': { color: 'text-amber-400', bg: 'bg-amber-500/10' },
  'Discovery Call Invitation': { color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
  'Demo Invitation': { color: 'text-indigo-400', bg: 'bg-indigo-500/10' },
  'Proposal Follow-Up': { color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
  'Client Onboarding': { color: 'text-sky-400', bg: 'bg-sky-500/10' },
  'Testimonial Request': { color: 'text-fuchsia-400', bg: 'bg-fuchsia-500/10' },
  'Low-Pressure Sign-Off': { color: 'text-rose-400', bg: 'bg-rose-500/10' },
  'General': { color: 'text-zinc-400', bg: 'bg-zinc-500/10' },
};

const VARIABLE_TAGS = [
  '{{Name}}',
  '{{BusinessName}}',
  '{{Niche}}',
  '{{Country}}',
  '{{Website}}',
  '{{ProfileURL}}'
];

export function OutreachEngine({ leads, token, onRequestAuth, onSuccess, selectedLeadIds, onEmailSent, onEmailScheduled }: Props) {
  const [selectedLeadId, setSelectedLeadId] = useState<string>('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [showTemplates, setShowTemplates] = useState(false);
  const [showAiConfig, setShowAiConfig] = useState(false);
  const [aiTone, setAiTone] = useState('Fitness Coach — Lead Flow & DM Organization');
  const [sendStatus, setSendStatus] = useState<string>('');
  const [viewMode, setViewMode] = useState<'edit' | 'preview'>('edit');
  
  // Scheduling States
  const [isScheduling, setIsScheduling] = useState(false);
  const [scheduleDate, setScheduleDate] = useState<string>('');
  const [scheduleTime, setScheduleTime] = useState<string>('09:00');
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    fetch('/api/templates')
      .then(res => res.json())
      .then(data => setTemplates(data))
      .catch(console.error);
      
    // Set default schedule date to tomorrow
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    setScheduleDate(tomorrow.toISOString().split('T')[0]);
  }, []);

  const isBulkMode = selectedLeadIds.size > 1;
  const targetLeadIds = isBulkMode ? Array.from(selectedLeadIds) : (selectedLeadId ? [selectedLeadId] : []);
  const targetLeads = leads.filter(l => targetLeadIds.includes(l.id) && l.Email);
  const currentLead = leads.find(l => l.id === selectedLeadId);

  // Auto-select single lead if only one is selected in the table
  useEffect(() => {
    if (selectedLeadIds.size === 1) {
      setSelectedLeadId(Array.from(selectedLeadIds)[0]);
    }
  }, [selectedLeadIds]);

  const applyTemplate = (t: Template) => {
    if (!isBulkMode) {
      const selectedLead = leads.find(l => l.id === selectedLeadId);
      if (selectedLead) {
        const newSubj = replaceVariables(t.subject, selectedLead);
        const newBody = replaceVariables(t.body, selectedLead);
        setSubject(newSubj);
        setBody(newBody);
      } else {
        setSubject(t.subject);
        setBody(t.body);
      }
    } else {
      setSubject(t.subject);
      setBody(t.body);
    }
    setShowTemplates(false);
  };

  const replaceVariables = (text: string, lead: Lead) => {
    return text
      .replace(/{{Name}}/g, lead.Name || '')
      .replace(/{{BusinessName}}/g, lead.BusinessName || lead.Name || '')
      .replace(/{{Niche}}/g, lead.Niche || '')
      .replace(/{{Country}}/g, lead.Country || '')
      .replace(/{{Website}}/g, lead.Website || '')
      .replace(/{{ProfileURL}}/g, lead.ProfileURL || '')
      .replace(/{{DealValue}}/g, lead['Deal Value'] || '')
      .replace(/{{Deal Value}}/g, lead['Deal Value'] || '')
      .replace(/{{PersonalizedObservation}}/g, lead.PersonalizedObservation || '')
      .replace(/{{PainPoint}}/g, lead.PainPoint || 'lost leads in DMs and spreadsheets')
      .replace(/{{DemoLink}}/g, lead.DemoLink || 'https://coachgrowthos.com/demo');
  };

  const insertVariable = (tag: string) => {
    if (!textareaRef.current) {
      setBody(prev => prev + ' ' + tag);
      return;
    }
    const input = textareaRef.current;
    const start = input.selectionStart || 0;
    const end = input.selectionEnd || 0;
    const nextVal = body.substring(0, start) + tag + body.substring(end);
    setBody(nextVal);
    setTimeout(() => {
      input.focus();
      input.setSelectionRange(start + tag.length, start + tag.length);
    }, 0);
  };

  const handleGenerateDraft = async () => {
    if (isBulkMode) {
      alert("AI drafting operates on single prospects. For bulk outreach, select an email template.");
      return;
    }
    const selectedLead = leads.find(l => l.id === selectedLeadId);
    if (!selectedLead) {
      alert("Please select a lead first.");
      return;
    }
    try {
      setGenerating(true);
      const res = await fetch('/api/generate-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          lead: selectedLead, 
          context: selectedLead.Notes,
          tone: aiTone
        })
      });
      const data = await res.json();
      if (data.success && data.draft) {
        setSubject(data.draft.subject || '');
        setBody(data.draft.body || '');
        setShowAiConfig(false);
      } else {
        alert("Failed to generate draft.");
      }
    } catch (e) {
      console.error(e);
      alert("Error generating draft.");
    } finally {
      setGenerating(false);
    }
  };

  const handleSendOrSchedule = async () => {
    if (!token) {
      onRequestAuth();
      return;
    }
    if (targetLeads.length === 0) {
      alert("Please select at least one lead with a valid email address.");
      return;
    }
    if (!subject || !body) {
      alert("Please enter a subject and body.");
      return;
    }
    
    if (isBulkMode && isScheduling) {
       alert("Please use the Bulk Campaign feature from the Lead Table to safely schedule bulk outreach.");
       return;
    }

    if (isScheduling) {
       // Single lead scheduling logic
       const lead = currentLead;
       if (!lead) return;
       if (!scheduleDate || !scheduleTime) {
         alert("Please select a date and time.");
         return;
       }
       
       // Build ISO string assuming local timezone for now
       const scheduledAt = new Date(`${scheduleDate}T${scheduleTime}:00`).toISOString();
       
       const newScheduledEmail: ScheduledEmail = {
         id: 'sched_' + Date.now().toString(),
         leadId: lead.id,
         leadName: lead.Name || 'Unknown',
         emailAddress: lead.Email,
         subject: replaceVariables(subject, lead),
         body: replaceVariables(body, lead),
         scheduledAt,
         status: 'Scheduled'
       };
       
       onEmailScheduled?.(newScheduledEmail);
       alert("Email scheduled successfully!");
       setSubject('');
       setBody('');
       setIsScheduling(false);
       return;
    }

    setSending(true);
    let successCount = 0;
    let lastError = '';
    
    for (let i = 0; i < targetLeads.length; i++) {
      const lead = targetLeads[i];
      setSendStatus(`Sending ${i + 1}/${targetLeads.length}: ${lead.Name || lead.Email}`);
      
      const personalizedSubject = replaceVariables(subject, lead);
      const personalizedBody = replaceVariables(body, lead);

      try {
        const res = await fetch('/api/gmail/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            leadId: lead.id,
            email: lead.Email,
            subject: personalizedSubject,
            body: personalizedBody
          })
        });
        const data = await res.json();
        
        if (res.ok && data.success) {
          successCount++;
          onSuccess([{ ...lead, 'Last Contact Date': new Date().toISOString().split('T')[0], 'Status': 'Emailed' }]); // optimistic local update
          onEmailSent?.({
            leadName: lead.Name || lead.Email,
            email: lead.Email,
            subject: personalizedSubject,
            leadId: lead.id
          });
        } else {
          lastError = data.error || 'Failed to dispatch email.';
          console.error("API error sending to", lead.Email, data);
        }
      } catch (e: any) {
        lastError = e.message || 'Network request failed.';
        console.error("Failed to send to", lead.Email, e);
      }
    }

    setSending(false);
    setSendStatus('');
    
    if (successCount === targetLeads.length) {
      alert(`Outreach dispatched successfully to all ${successCount} leads! ${token === 'sandbox_token' ? '(Simulated Sandbox Mode)' : ''}`);
      if (!isBulkMode) {
        setSubject('');
        setBody('');
      }
    } else if (successCount > 0) {
      alert(`Outreach partially sent! Successfully dispatched to ${successCount} of ${targetLeads.length} leads. Error: ${lastError}`);
    } else {
      alert(`Failed to send email. Error: ${lastError || 'Unknown connection error'}`);
    }
  };

  const previewSubject = currentLead ? replaceVariables(subject, currentLead) : subject;
  const previewBody = currentLead ? replaceVariables(body, currentLead) : body;

  return (
    <div className="p-5 flex flex-col h-full bg-[#0A0A0A] relative">
      {/* Header */}
      <div className="flex justify-between items-center mb-3">
        <div className="flex items-center space-x-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-white">Outreach Composer</h3>
          {isBulkMode && (
            <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-semibold">
              Bulk ({targetLeads.length})
            </span>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {token ? (
            <div className={cn(
              "text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center border",
              token === 'sandbox_token' 
                ? "text-sky-400 bg-sky-500/10 border-sky-500/20" 
                : "text-emerald-400 bg-emerald-500/10 border-emerald-500/20"
            )}>
              <span className={cn(
                "w-1.5 h-1.5 rounded-full mr-1.5 animate-pulse",
                token === 'sandbox_token' ? "bg-sky-400" : "bg-emerald-400"
              )} />
              {token === 'sandbox_token' ? "Sandbox Connected" : "Gmail Ready"}
            </div>
          ) : (
            <div className="text-[9px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full flex items-center border border-amber-500/20">
              Auth Needed
            </div>
          )}
        </div>
      </div>

      {!token && (
        <div className="mb-3 p-3 bg-amber-950/20 border border-amber-500/20 rounded-xl flex items-start space-x-3">
          <AlertCircle className="text-amber-500 mt-0.5 flex-shrink-0" size={14} />
          <div className="flex-1">
            <h3 className="font-semibold text-xs text-amber-400">Connect Gmail for Direct Delivery</h3>
            <p className="text-[10px] text-amber-400/80 mt-0.5 mb-2.5">Send high-deliverability emails from your authenticated Google Workspace account.</p>
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={onRequestAuth}
                className="text-[10px] font-bold bg-amber-500 text-black px-3 py-1.5 rounded-lg hover:bg-amber-400 transition-colors"
              >
                Connect Gmail Account
              </button>
              <button 
                onClick={() => {
                  localStorage.setItem('gmail_token', 'sandbox_token');
                  window.location.reload();
                }}
                className="text-[10px] font-bold bg-[#1A1A1A] text-[#CCC] border border-[#333] px-3 py-1.5 rounded-lg hover:bg-[#252525] hover:text-white transition-colors"
              >
                Enable Sandbox Mode
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Composer Controls */}
      <div className="space-y-2.5 flex-1 flex flex-col relative">
        
        {/* Recipient & Template Selector */}
        <div className="flex space-x-2 items-center">
          {isBulkMode ? (
            <div className="flex-1 bg-[#121212] border border-[#222] rounded-lg py-1.5 px-3 text-xs text-[#CCC] flex items-center justify-between">
              <span>Sending to <strong className="text-blue-400">{targetLeads.length} leads</strong> with valid emails</span>
              <span className="text-[9px] text-[#777] uppercase font-mono">Dynamic Merge</span>
            </div>
          ) : (
            <select 
              className="flex-1 bg-[#121212] border border-[#222] rounded-lg py-1.5 px-3 text-xs text-[#E0E0E0] focus:border-emerald-500 outline-none"
              value={selectedLeadId}
              onChange={(e) => setSelectedLeadId(e.target.value)}
            >
              <option value="" className="bg-[#111] text-[#777]">-- Select Prospect --</option>
              {leads.filter(l => l.Email).map(l => (
                <option key={l.id} value={l.id} className="bg-[#111] text-[#E0E0E0]">
                  {l.Name} ({l.Email}) {l.Status ? `• ${l.Status}` : ''}
                </option>
              ))}
            </select>
          )}

          {/* Categorized Template Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setShowTemplates(!showTemplates)}
              disabled={(!selectedLeadId && !isBulkMode) || templates.length === 0}
              className="bg-[#141414] border border-[#282828] text-[#CCC] hover:text-white hover:bg-[#1E1E1E] px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 disabled:opacity-40 transition-colors"
              title="Apply categorized agency template"
            >
              <Tag size={11} className="text-emerald-400" />
              <span>Templates</span>
              <ChevronDown size={11} />
            </button>

            {showTemplates && templates.length > 0 && (
              <div className="absolute right-0 top-9 w-64 bg-[#141414] border border-[#333] rounded-xl shadow-2xl z-30 overflow-hidden max-h-72 overflow-y-auto divide-y divide-[#222]">
                <div className="p-2 bg-[#1A1A1A] text-[10px] font-bold uppercase tracking-wider text-[#888] flex justify-between">
                  <span>Coach Growth OS Templates</span>
                  <span className="text-emerald-400">{templates.length} Ready</span>
                </div>
                {templates.map(t => {
                  const meta = CATEGORY_COLORS[t.category || 'General'] || CATEGORY_COLORS['General'];
                  return (
                    <button 
                      key={t.id}
                      onClick={() => applyTemplate(t)}
                      className="w-full text-left p-2.5 text-xs text-[#CCC] hover:bg-[#202020] hover:text-white transition-colors flex flex-col space-y-1"
                    >
                      <div className="flex justify-between items-center w-full">
                        <span className="font-semibold truncate max-w-[140px] text-white">{t.name}</span>
                        <span className={cn("text-[9px] px-1.5 py-0.5 rounded font-mono", meta.bg, meta.color)}>
                          {t.category || 'General'}
                        </span>
                      </div>
                      <span className="text-[10px] text-[#777] truncate w-full">{t.subject}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Mode Toggle & Variable Tags */}
        <div className="flex justify-between items-center bg-[#111] p-1.5 rounded-lg border border-[#222]">
          {/* Quick Variable Pills */}
          <div className="flex items-center space-x-1">
            <span className="text-[9px] uppercase font-bold text-[#555] mr-1">Insert:</span>
            {VARIABLE_TAGS.map(v => (
              <button
                key={v}
                type="button"
                onClick={() => insertVariable(v)}
                className="text-[10px] font-mono bg-[#1A1A1A] hover:bg-emerald-500/10 text-[#AAA] hover:text-emerald-400 px-1.5 py-0.5 rounded border border-[#2A2A2A] transition-colors"
                title={`Insert ${v}`}
              >
                {v}
              </button>
            ))}
          </div>

          {/* Edit / Preview Toggle */}
          {!isBulkMode && (
            <div className="flex items-center space-x-0.5 bg-[#181818] p-0.5 rounded">
              <button
                onClick={() => setViewMode('edit')}
                className={cn(
                  "text-[10px] px-2 py-0.5 rounded font-medium transition-colors",
                  viewMode === 'edit' ? "bg-[#252525] text-white" : "text-[#777] hover:text-[#BBB]"
                )}
              >
                Edit
              </button>
              <button
                onClick={() => setViewMode('preview')}
                className={cn(
                  "text-[10px] px-2 py-0.5 rounded font-medium transition-colors flex items-center space-x-1",
                  viewMode === 'preview' ? "bg-[#252525] text-emerald-400" : "text-[#777] hover:text-[#BBB]"
                )}
              >
                <Eye size={10} />
                <span>Preview</span>
              </button>
            </div>
          )}
        </div>

        {/* Subject */}
        <input 
          type="text"
          className="w-full bg-[#111] border border-[#222] rounded-lg px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none transition-colors"
          placeholder="Subject: e.g. Quick question about your coaching lead flow"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />

        {/* Body or Live Preview */}
        {viewMode === 'edit' ? (
          <textarea 
            ref={textareaRef}
            className="flex-1 bg-[#111] rounded-xl border border-[#222] p-3 text-xs text-[#CCC] resize-none outline-none focus:border-emerald-500 w-full leading-relaxed font-sans placeholder-[#444]"
            placeholder={isBulkMode 
              ? "Write email template here...\n\nUse {{Name}}, {{BusinessName}}, and {{Niche}} for dynamic per-lead personalization." 
              : "Write your email here... or click AI Draft / Templates to get started."}
            value={body}
            onChange={(e) => setBody(e.target.value)}
          />
        ) : (
          <div className="flex-1 bg-[#111] rounded-xl border border-[#222] p-4 text-xs text-[#CCC] overflow-y-auto leading-relaxed whitespace-pre-wrap">
            <div className="text-[10px] text-[#666] border-b border-[#222] pb-2 mb-3">
              <span className="font-semibold text-emerald-400">Subject Preview: </span>
              <span className="text-white">{previewSubject || '(empty subject)'}</span>
            </div>
            {previewBody || <span className="text-[#555] italic">Email body is empty...</span>}
          </div>
        )}

        {/* AI Tone Popover */}
        {showAiConfig && !isBulkMode && (
          <div className="p-3 bg-[#161616] border border-[#333] rounded-xl space-y-2 animate-in fade-in duration-150">
            <div className="flex justify-between items-center">
              <span className="text-[10px] uppercase font-bold text-white flex items-center space-x-1">
                <Sparkles size={11} className="text-indigo-400" />
                <span>AI Copywriter Tone & Angle</span>
              </span>
              <button onClick={() => setShowAiConfig(false)} className="text-[10px] text-[#777] hover:text-white">✕</button>
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-[10px]">
              {[
                'Fitness Coach — Lead Flow & DM Organization',
                'Business Coach — Pipeline & Lead Intake',
                'General Coach — Stop Losing Leads in DMs',
                'Follow-Up — Short Demo Video Bump',
                'Discovery Call — 15-Min Pipeline Walkthrough',
                'Low-Pressure Close The Loop / Sign-Off',
              ].map(tone => (
                <button
                  key={tone}
                  onClick={() => setAiTone(tone)}
                  className={cn(
                    "p-1.5 rounded-lg border text-left truncate transition-colors",
                    aiTone === tone 
                      ? "bg-indigo-500/20 text-indigo-300 border-indigo-500/40 font-medium" 
                      : "bg-[#111] text-[#888] border-[#222] hover:text-white"
                  )}
                >
                  {tone}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Scheduling UI */}
        {!isBulkMode && isScheduling && (
          <div className="p-3 bg-[#181818] border border-[#333] rounded-xl flex flex-col space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center space-x-1">
                <Clock size={11} />
                <span>Schedule Email</span>
              </span>
              <button onClick={() => setIsScheduling(false)} className="text-[10px] text-[#777] hover:text-white">✕</button>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-[#888] block mb-1">Date</label>
                <input 
                  type="date" 
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                  className="w-full bg-[#111] border border-[#333] text-white text-xs px-2 py-1.5 rounded focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#888] block mb-1">Time</label>
                <input 
                  type="time" 
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full bg-[#111] border border-[#333] text-white text-xs px-2 py-1.5 rounded focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="text-[10px] space-y-1">
              <div className="flex justify-between text-[#AAA]">
                <span>Your Time (Africa/Cairo):</span>
                <span>{scheduleDate} {scheduleTime}</span>
              </div>
              <div className="flex justify-between text-emerald-400">
                <span>Prospect Time ({currentLead?.TimeZone || 'Unknown'}):</span>
                <span>(Calculated relative to GMT)</span>
              </div>
              <p className="text-[9px] text-[#666] mt-1">Recommended: Mon-Fri, 9:00 AM - 4:30 PM prospect time.</p>
            </div>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex space-x-2 pt-1">
          {!isBulkMode && (
            <>
              <button 
                onClick={() => setIsScheduling(!isScheduling)}
                disabled={!selectedLeadId || generating}
                className={cn(
                  "flex items-center justify-center p-2 rounded-xl border font-semibold transition-colors disabled:opacity-40",
                  isScheduling ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400" : "bg-[#181818] border-[#2A2A2A] text-[#CCC] hover:bg-[#222] hover:text-white"
                )}
                title="Schedule for later"
              >
                <Clock size={16} />
              </button>
              
              <button 
                onClick={() => {
                  if (!showAiConfig) setShowAiConfig(true);
                  else handleGenerateDraft();
                }}
                disabled={!selectedLeadId || generating}
                className="flex-1 flex items-center justify-center space-x-1.5 bg-[#181818] hover:bg-[#222] text-[#CCC] hover:text-white border border-[#2A2A2A] font-semibold py-2 rounded-xl text-xs transition-colors disabled:opacity-40"
                title="Generate tailored cold email with Gemini AI"
              >
                {generating ? <RefreshCw className="animate-spin text-indigo-400" size={13} /> : <Wand2 size={13} className="text-indigo-400" />}
                <span>{generating ? 'Drafting...' : showAiConfig ? 'Generate Draft' : 'AI Draft'}</span>
              </button>
            </>
          )}

          <button 
            onClick={handleSendOrSchedule}
            disabled={!token || sending || (!selectedLeadId && !isBulkMode) || targetLeads.length === 0}
            className={cn(
              "flex-[1.5] flex items-center justify-center space-x-2 font-bold py-2 rounded-xl text-xs transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-md",
              isBulkMode 
                ? "bg-blue-600 hover:bg-blue-500 text-white" 
                : isScheduling
                ? "bg-emerald-600 hover:bg-emerald-500 text-white"
                : "bg-emerald-600 hover:bg-emerald-500 text-white"
            )}
          >
            {sending ? <RefreshCw className="animate-spin" size={13} /> : (isScheduling ? <Clock size={13} /> : <Send size={13} />)}
            <span>{sending ? (sendStatus || 'Sending...') : isBulkMode ? `Blast to ${targetLeads.length} Leads` : isScheduling ? 'Confirm Schedule' : 'Send Now'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
