import React, { useRef, useState, useMemo } from 'react';
import { Lead, LeadStatus } from '../types';
import { 
  Inbox, Upload, RefreshCw, Trash2, AlertCircle, CheckSquare, 
  Square, Search, Download, Plus, Filter, ArrowUpDown, ChevronRight, UserPlus, Send, Sparkles
} from 'lucide-react';
import { cn } from '../utils';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import { AddLeadModal } from './AddLeadModal';
import { LeadDrawer } from './LeadDrawer';

interface Props {
  leads: Lead[];
  onUpdate: (id: string, field: keyof Lead, value: string) => void;
  onBulkUpdate?: (id: string, updates: Partial<Lead>) => void;
  onScan: () => void;
  hasToken: boolean;
  onImport?: (leads: Lead[]) => void;
  onDelete: (id: string) => void;
  onClear: () => void;
  selectedIds: Set<string>;
  onSelectionChange: (ids: Set<string>) => void;
  onAddLead?: (lead: Omit<Lead, 'id'>) => void;
  onSelectForOutreach?: (leadId: string) => void;
  onBulkCampaign?: () => void;
  saveStatus?: 'saved' | 'saving' | 'error';
}

const STATUS_OPTIONS: LeadStatus[] = [
  'New', 'Emailed', 'Followed Up', 'Replied', 
  'Meeting Scheduled', 'Closed Won', 'Closed Lost'
];

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'Closed Won':
      return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'Meeting Scheduled':
      return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    case 'Replied':
      return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    case 'Emailed':
      return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
    case 'Followed Up':
      return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    case 'Closed Lost':
      return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
    default:
      return 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20';
  }
};

const isFollowUpDue = (lastContactDate?: string, status?: string) => {
  if (!lastContactDate) return false;
  if (status === 'Closed Won' || status === 'Closed Lost') return false;
  
  const contactDate = new Date(lastContactDate);
  if (isNaN(contactDate.getTime())) return false;
  
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  return contactDate < sevenDaysAgo;
};

export function LeadTable({ 
  leads, onUpdate, onBulkUpdate, onScan, hasToken, onImport, 
  onDelete, onClear, selectedIds, onSelectionChange, onAddLead, onSelectForOutreach,
  onBulkCampaign, saveStatus = 'saved'
}: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [confirmingClear, setConfirmingClear] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [infoMessage, setInfoMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [nicheFilter, setNicheFilter] = useState<string>('all');
  const [classifying, setClassifying] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [activeDrawerLead, setActiveDrawerLead] = useState<Lead | null>(null);

  // Run AI classification on leads
  const handleAIClassifyNiches = async () => {
    try {
      setClassifying(true);
      setErrorMessage('');
      setInfoMessage('');
      const res = await fetch('/api/leads/classify-niches', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await res.json();
      if (data.success && onImport) {
        onImport(data.leads);
        setInfoMessage(`Success! Run complete. AI successfully classified ${data.classifiedCount} leads.`);
        setTimeout(() => setInfoMessage(''), 6000);
      } else {
        setErrorMessage(data.error || 'Failed to classify niches with AI.');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Error executing AI classification.');
    } finally {
      setClassifying(false);
    }
  };

  // File Upload (supports CSV, XLSX, and JSON backups)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMessage('');

    // If uploading a JSON backup file
    if (file.name.endsWith('.json')) {
      try {
        setUploading(true);
        const text = await file.text();
        const parsed = JSON.parse(text);
        const list = Array.isArray(parsed) ? parsed : (parsed.leads || []);
        
        const res = await fetch('/api/leads/json-upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: list })
        });
        const apiData = await res.json();
        if (apiData.success && onImport) {
          onImport(apiData.leads);
        } else {
          setErrorMessage(apiData.error || 'Failed to parse JSON backup.');
        }
      } catch (err) {
        console.error(err);
        setErrorMessage('Invalid JSON backup file.');
      } finally {
        setUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        setUploading(true);
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: '' });

        const res = await fetch('/api/leads/json-upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: json })
        });
        const apiData = await res.json();
        
        if (apiData.success && onImport) {
          onImport(apiData.leads);
        } else {
          setErrorMessage(apiData.error || 'Failed to parse file.');
        }
      } catch (err) {
        console.error(err);
        setErrorMessage('Invalid file format. Please upload CSV, XLSX, or JSON backup.');
      } finally {
        setUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // Export to CSV
  const handleExportCSV = () => {
    const targetLeads = selectedIds.size > 0 
      ? leads.filter(l => selectedIds.has(l.id))
      : leads;
    
    if (targetLeads.length === 0) return;

    const csvData = targetLeads.map(l => ({
      Name: l.Name,
      Niche: l.Niche,
      Country: l.Country,
      Email: l.Email,
      Website: l.Website,
      Status: l.Status,
      'Deal Value': l['Deal Value'],
      'Last Contact Date': l['Last Contact Date'],
      Notes: l.Notes
    }));

    const csvString = Papa.unparse(csvData);
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `leads_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export to JSON Backup
  const handleExportJSON = () => {
    const targetLeads = selectedIds.size > 0 
      ? leads.filter(l => selectedIds.has(l.id))
      : leads;
    
    if (targetLeads.length === 0) return;

    const jsonString = JSON.stringify(targetLeads, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `leads_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Bulk status update
  const handleBulkStatus = (newStatus: LeadStatus) => {
    selectedIds.forEach(id => onUpdate(id, 'Status', newStatus));
  };

  const handleClearAll = () => {
    if (confirmingClear) {
      onClear();
      setConfirmingClear(false);
      onSelectionChange(new Set());
    } else {
      setConfirmingClear(true);
      setTimeout(() => setConfirmingClear(false), 3000);
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredLeads.length) {
      onSelectionChange(new Set());
    } else {
      onSelectionChange(new Set(filteredLeads.map(l => l.id)));
    }
  };

  const toggleSelect = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    onSelectionChange(next);
  };

  const handleBulkDelete = () => {
    Array.from(selectedIds).forEach(id => onDelete(id));
    onSelectionChange(new Set());
  };

  // Filtered Leads
  const filteredLeads = useMemo(() => {
    return leads.filter(l => {
      const matchesSearch = 
        (l.Name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.Email || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.Niche || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.Country || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (l.Notes || '').toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || l.Status === statusFilter;

      let matchesNiche = true;
      if (nicheFilter === 'fitness') {
        matchesNiche = (l.Niche || '').toLowerCase().includes('fitness') || (l.Niche || '').toLowerCase().includes('trainer') || (l.Niche || '').toLowerCase().includes('health') || (l.Niche || '').toLowerCase().includes('physique');
      } else if (nicheFilter === 'business') {
        matchesNiche = (l.Niche || '').toLowerCase().includes('business') || (l.Niche || '').toLowerCase().includes('marketing') || (l.Niche || '').toLowerCase().includes('consultant') || (l.Niche || '').toLowerCase().includes('agency') || (l.Niche || '').toLowerCase().includes('entrepreneur');
      } else if (nicheFilter === 'other') {
        const isFitness = (l.Niche || '').toLowerCase().includes('fitness') || (l.Niche || '').toLowerCase().includes('trainer') || (l.Niche || '').toLowerCase().includes('health') || (l.Niche || '').toLowerCase().includes('physique');
        const isBusiness = (l.Niche || '').toLowerCase().includes('business') || (l.Niche || '').toLowerCase().includes('marketing') || (l.Niche || '').toLowerCase().includes('consultant') || (l.Niche || '').toLowerCase().includes('agency') || (l.Niche || '').toLowerCase().includes('entrepreneur');
        matchesNiche = !isFitness && !isBusiness;
      }
      
      return matchesSearch && matchesStatus && matchesNiche;
    });
  }, [leads, searchQuery, statusFilter, nicheFilter]);

  const currentDrawerLead = useMemo(() => {
    if (!activeDrawerLead) return null;
    return leads.find(l => l.id === activeDrawerLead.id) || activeDrawerLead;
  }, [leads, activeDrawerLead]);

  return (
    <div className="flex flex-col h-full bg-[#0A0A0A]">
      {/* Top Controls Header */}
      <div className="p-3.5 border-b border-[#222] bg-[#0D0D0D] flex flex-wrap items-center justify-between gap-3">
        {/* Search & Status Filter */}
        <div className="flex items-center space-x-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-xs">
            <Search size={13} className="absolute left-3 top-2.5 text-[#555]" />
            <input 
              type="text" 
              placeholder="Search leads, emails, niches..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#141414] border border-[#222] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#555] outline-none focus:border-emerald-500/50"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-[#141414] border border-[#222] text-xs text-[#AAA] rounded-xl px-2.5 py-1.5 outline-none focus:border-emerald-500/50"
          >
            <option value="all">All Stages ({leads.length})</option>
            {STATUS_OPTIONS.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>

          <select
            value={nicheFilter}
            onChange={(e) => setNicheFilter(e.target.value)}
            className="bg-[#141414] border border-[#222] text-xs text-[#AAA] rounded-xl px-2.5 py-1.5 outline-none focus:border-emerald-500/50"
          >
            <option value="all">All Niches</option>
            <option value="fitness">Fitness Coaches</option>
            <option value="business">Business Coaches</option>
            <option value="other">Other/Unclassified</option>
          </select>

          {/* Data Protection / Save Status Pill */}
          <div className="hidden sm:flex items-center">
            {saveStatus === 'saving' ? (
              <div className="flex items-center space-x-1.5 text-[10px] font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-xl">
                <RefreshCw size={10} className="animate-spin" />
                <span>Saving to storage...</span>
              </div>
            ) : saveStatus === 'saved' ? (
              <div className="flex items-center space-x-1.5 text-[10px] font-medium text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-xl" title="Leads are automatically backed up in your browser and synced with the server">
                <CheckSquare size={10} />
                <span>Protected & Saved</span>
              </div>
            ) : (
              <div className="flex items-center space-x-1.5 text-[10px] font-medium text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2.5 py-1 rounded-xl" title="Changes are preserved in browser storage">
                <AlertCircle size={10} />
                <span>Saved Locally</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-2">
          {selectedIds.size > 0 && (
            <div className="flex items-center space-x-1.5 bg-[#141414] border border-[#2C2C2C] px-2.5 py-1 rounded-xl animate-in fade-in">
              <span className="text-[10px] text-emerald-400 font-bold uppercase">{selectedIds.size} Selected</span>
              <select
                onChange={(e) => {
                  if (e.target.value) handleBulkStatus(e.target.value as LeadStatus);
                }}
                defaultValue=""
                className="bg-[#1E1E1E] text-[10px] text-white rounded px-1.5 py-0.5 outline-none border border-[#333]"
              >
                <option value="" disabled>Set Status...</option>
                {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <button 
                onClick={handleBulkDelete}
                className="text-[10px] text-rose-400 hover:bg-rose-500/10 px-2 py-0.5 rounded transition-colors"
              >
                Delete
              </button>
            </div>
          )}

          {selectedIds.size > 0 && (
            <button 
              onClick={onBulkCampaign}
              className="flex items-center space-x-1.5 text-xs font-semibold bg-sky-500 hover:bg-sky-400 text-black px-3 py-1.5 rounded-xl transition-colors shadow-sm mr-2"
              title="Schedule a bulk campaign for selected leads"
            >
              <Send size={13} />
              <span>Bulk Campaign ({selectedIds.size})</span>
            </button>
          )}

          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="flex items-center space-x-1.5 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-black px-3 py-1.5 rounded-xl transition-colors shadow-sm"
          >
            <Plus size={13} />
            <span>Add Lead</span>
          </button>

          <input 
            type="file" 
            accept=".csv,.xlsx,.json" 
            ref={fileInputRef} 
            className="hidden" 
            onChange={handleFileUpload} 
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center space-x-1 text-xs bg-[#141414] text-[#CCC] hover:text-white px-3 py-1.5 rounded-xl border border-[#262626] hover:bg-[#1A1A1A] transition-colors disabled:opacity-50"
            title="Import CSV, XLSX, or JSON backup file"
          >
            {uploading ? <RefreshCw size={12} className="animate-spin" /> : <Upload size={12} />}
            <span>Import</span>
          </button>

          <button 
            onClick={handleExportCSV}
            disabled={leads.length === 0}
            className="flex items-center space-x-1 text-xs bg-[#141414] text-[#CCC] hover:text-white px-3 py-1.5 rounded-xl border border-[#262626] hover:bg-[#1A1A1A] transition-colors disabled:opacity-40"
            title="Export leads to CSV spreadsheet"
          >
            <Download size={12} />
            <span>Export CSV</span>
          </button>

          <button 
            onClick={handleExportJSON}
            disabled={leads.length === 0}
            className="flex items-center space-x-1 text-xs bg-[#141414] text-[#888] hover:text-white px-2.5 py-1.5 rounded-xl border border-[#222] hover:bg-[#1A1A1A] transition-colors disabled:opacity-40"
            title="Download full JSON backup snapshot"
          >
            <Download size={12} />
            <span>Backup</span>
          </button>

          <button 
            onClick={onScan}
            className="flex items-center space-x-1 text-xs font-semibold bg-emerald-500/10 text-emerald-400 px-3 py-1.5 rounded-xl border border-emerald-500/20 hover:bg-emerald-500/20 transition-colors"
            title="Scan inbox for prospect replies"
          >
            <RefreshCw size={12} />
            <span>Sync DB</span>
          </button>

          <button 
            onClick={handleAIClassifyNiches}
            disabled={classifying || leads.length === 0}
            className="flex items-center space-x-1.5 text-xs font-semibold bg-indigo-650 hover:bg-indigo-600 text-white px-3 py-1.5 rounded-xl shadow-sm transition-colors disabled:opacity-40"
            title="Analyze lead bios & notes with Gemini to automatically classify as Fitness Coach or Business Coach"
          >
            {classifying ? (
              <RefreshCw size={12} className="animate-spin" />
            ) : (
              <svg className="w-3.5 h-3.5 text-indigo-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            )}
            <span>AI Niche Classifier</span>
          </button>

          <button 
            onClick={handleClearAll}
            disabled={leads.length === 0}
            className={cn(
              "text-[10px] uppercase font-semibold px-2.5 py-1.5 rounded-xl border transition-colors",
              confirmingClear 
                ? "bg-rose-500/20 text-rose-300 border-rose-500/30 font-bold animate-pulse" 
                : "border-transparent text-[#666] hover:text-rose-400"
            )}
            title="Delete all leads from pipeline"
          >
            {confirmingClear ? "Confirm Clear?" : "Clear"}
          </button>
        </div>
      </div>

      {infoMessage && (
        <div className="p-2 bg-indigo-950/30 border-b border-indigo-500/20 text-indigo-300 text-xs flex items-center px-4 space-x-2">
          <svg className="w-4 h-4 text-indigo-400 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          <span>{infoMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-2 bg-rose-950/30 border-b border-rose-500/20 text-rose-400 text-xs flex items-center px-4 space-x-2">
          <AlertCircle size={14} />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Table Container */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-[#0C0C0C] text-[10px] uppercase text-[#666] font-bold border-b border-[#1F1F1F] sticky top-0 z-10">
            <tr>
              <th className="p-3 w-8">
                <button onClick={toggleSelectAll} className="text-[#777] hover:text-white transition-colors">
                  {selectedIds.size === filteredLeads.length && filteredLeads.length > 0 ? <CheckSquare size={14} className="text-emerald-400" /> : <Square size={14} />}
                </button>
              </th>
              <th className="p-3 font-semibold whitespace-nowrap">Prospect</th>
              <th className="p-3 font-semibold whitespace-nowrap">Niche & Country</th>
              <th className="p-3 font-semibold whitespace-nowrap">Contact</th>
              <th className="p-3 font-semibold whitespace-nowrap">Stage</th>
              <th className="p-3 font-semibold whitespace-nowrap">Deal Value</th>
              <th className="p-3 font-semibold">Notes</th>
              <th className="p-3 w-10"></th>
            </tr>
          </thead>
          <tbody className="text-xs text-[#CCC] divide-y divide-[#161616]">
            {filteredLeads.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-16 text-center text-[#555]">
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <Inbox size={36} className="text-[#333]" />
                    <p className="text-sm font-medium text-[#777]">No leads found in this view.</p>
                    <p className="text-xs text-[#555]">Upload an XLSX/CSV spreadsheet or add your first prospect manually.</p>
                    <button 
                      onClick={() => setIsAddModalOpen(true)}
                      className="mt-2 text-xs font-semibold bg-emerald-500 text-black px-4 py-2 rounded-xl hover:bg-emerald-400 transition-colors shadow-sm"
                    >
                      + Add First Lead
                    </button>
                  </div>
                </td>
              </tr>
            ) : filteredLeads.map(lead => (
              <tr 
                key={lead.id} 
                onClick={() => setActiveDrawerLead(lead)}
                className={cn(
                  "transition-colors group cursor-pointer",
                  selectedIds.has(lead.id) ? "bg-emerald-950/15" : "hover:bg-[#121212]"
                )}
              >
                <td className="p-3" onClick={(e) => toggleSelect(lead.id, e)}>
                  <button className={cn("transition-colors", selectedIds.has(lead.id) ? "text-emerald-400" : "text-[#444] group-hover:text-[#777]")}>
                    {selectedIds.has(lead.id) ? <CheckSquare size={14} /> : <Square size={14} />}
                  </button>
                </td>
                <td className="p-3">
                  <div className="font-semibold text-white group-hover:text-emerald-300 transition-colors flex items-center space-x-2">
                    <span className="truncate max-w-[120px]">{lead.Name || 'Unnamed Prospect'}</span>
                    {isFollowUpDue(lead['Last Contact Date'], lead.Status) && (
                      <span className="flex-shrink-0 flex items-center space-x-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/10 text-amber-500 border border-amber-500/20" title="Follow-up due (>7 days since last contact)">
                        <AlertCircle size={10} />
                        <span>DUE</span>
                      </span>
                    )}
                  </div>
                </td>
                <td className="p-3">
                  <div className="text-white">{lead.Niche || '—'}</div>
                  <div className="text-[10px] text-[#666]">{lead.Country || '—'}</div>
                </td>
                <td className="p-3" onClick={(e) => e.stopPropagation()}>
                  <div className="text-[#CCC] truncate max-w-[160px]">{lead.Email || 'No Email'}</div>
                  {lead.Website && (
                    <a 
                      href={lead.Website.startsWith('http') ? lead.Website : `https://${lead.Website}`} 
                      target="_blank" 
                      rel="noreferrer" 
                      className="text-[10px] text-emerald-400 hover:underline block truncate max-w-[140px]"
                    >
                      {lead.Website}
                    </a>
                  )}
                </td>
                <td className="p-3" onClick={(e) => e.stopPropagation()}>
                  <select 
                    className={cn(
                      "text-[10px] px-2 py-0.5 rounded-full border outline-none font-medium cursor-pointer transition-colors",
                      getStatusBadge(lead.Status)
                    )}
                    value={lead.Status || 'New'}
                    onChange={(e) => onUpdate(lead.id, 'Status', e.target.value)}
                  >
                    {STATUS_OPTIONS.map(s => <option key={s} value={s} className="bg-[#141414] text-white">{s}</option>)}
                  </select>
                  <div className="text-[9px] text-[#555] mt-1 font-mono">
                    {lead['Last Contact Date'] ? `Last: ${lead['Last Contact Date']}` : 'No contact'}
                  </div>
                </td>
                <td className="p-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center text-white font-mono">
                    <span className="text-[#666] mr-0.5">$</span>
                    <input 
                      className="bg-transparent w-16 focus:outline-none focus:border-b focus:border-emerald-500 px-1 py-0.5 text-xs text-white"
                      value={lead['Deal Value'] || ''}
                      onChange={(e) => onUpdate(lead.id, 'Deal Value', e.target.value)}
                    />
                  </div>
                </td>
                <td className="p-3 max-w-[180px]" onClick={(e) => e.stopPropagation()}>
                  <input 
                    className="bg-transparent w-full text-xs text-[#888] focus:text-white focus:outline-none focus:border-b focus:border-emerald-500 truncate"
                    value={lead.Notes || ''}
                    placeholder="Add quick notes..."
                    onChange={(e) => onUpdate(lead.id, 'Notes', e.target.value)}
                  />
                </td>
                <td className="p-3 text-right">
                  <ChevronRight size={14} className="text-[#444] group-hover:text-white transition-colors ml-auto" />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modals & Slide-Over Dossier */}
      <AddLeadModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
        onAdd={(newLead) => {
          if (onAddLead) onAddLead(newLead);
        }} 
      />

      <LeadDrawer 
        lead={currentDrawerLead} 
        onClose={() => setActiveDrawerLead(null)} 
        onUpdate={onUpdate}
        onBulkUpdate={onBulkUpdate}
        onSelectForOutreach={(id) => {
          if (onSelectForOutreach) onSelectForOutreach(id);
        }}
        onDelete={(id) => {
          onDelete(id);
          setActiveDrawerLead(null);
        }}
      />
    </div>
  );
}
