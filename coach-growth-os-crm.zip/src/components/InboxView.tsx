import React, { useEffect, useState } from 'react';
import { Mail, Send, Inbox as InboxIcon, Calendar, ArrowRight, User, MessageSquare, RefreshCw, AlertCircle } from 'lucide-react';
import { Lead } from '../types';

interface EmailLog {
  id: string;
  leadId?: string;
  leadName?: string;
  emailAddress: string;
  subject: string;
  body: string;
  type: 'sent' | 'received';
  date: string;
  simulated?: boolean;
}

interface Thread {
  emailAddress: string;
  leadName?: string;
  leadId?: string;
  lastMessageDate: string;
  subject: string;
  messages: EmailLog[];
}

interface Props {
  leads?: Lead[];
}

export function InboxView({ leads = [] }: Props) {
  const [emails, setEmails] = useState<EmailLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'sent' | 'received'>('all');
  const [sortBy, setSortBy] = useState<'recent_email' | 'last_contact'>('recent_email');
  const [selectedThreadEmail, setSelectedThreadEmail] = useState<string | null>(null);
  
  // Gmail Thread API states
  const [threadMessages, setThreadMessages] = useState<EmailLog[]>([]);
  const [loadingThread, setLoadingThread] = useState(false);

  // Quick reply form states
  const [replyBody, setReplyBody] = useState('');
  const [replySubject, setReplySubject] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const [replyError, setReplyError] = useState('');

  const token = localStorage.getItem('gmail_token');

  const fetchEmails = () => {
    fetch('/api/emails')
      .then(res => res.json())
      .then(data => {
        // Sort newest first
        const sorted = data.sort((a: EmailLog, b: EmailLog) => new Date(b.date).getTime() - new Date(a.date).getTime());
        setEmails(sorted);
      })
      .finally(() => setLoading(false));
  };

  const fetchThreadMessages = (email: string) => {
    setLoadingThread(true);
    fetch(`/api/gmail/thread?email=${encodeURIComponent(email)}`, {
      headers: {
        'Authorization': `Bearer ${token || 'sandbox_token'}`
      }
    })
      .then(res => res.json())
      .then(data => {
        if (data.success && data.messages) {
          setThreadMessages(data.messages);
        }
      })
      .catch(err => {
        console.error('Error fetching thread:', err);
      })
      .finally(() => setLoadingThread(false));
  };

  useEffect(() => {
    fetchEmails();
  }, []);

  // Group emails into threads by email address
  const threadsMap: { [email: string]: Thread } = {};

  emails.forEach(emailLog => {
    const emailKey = emailLog.emailAddress.toLowerCase().trim();

    // Only show the email if the recipient or sender's email is in the lead pipeline
    const isLeadInPipeline = leads.some(lead => lead.Email && lead.Email.toLowerCase().trim() === emailKey);
    if (!isLeadInPipeline) {
      return;
    }

    if (!threadsMap[emailKey]) {
      threadsMap[emailKey] = {
        emailAddress: emailLog.emailAddress,
        leadName: emailLog.leadName,
        leadId: emailLog.leadId,
        lastMessageDate: emailLog.date,
        subject: emailLog.subject,
        messages: []
      };
    }
    threadsMap[emailKey].messages.push(emailLog);
    
    // Keep track of the latest message info for sorting and display
    if (new Date(emailLog.date) > new Date(threadsMap[emailKey].lastMessageDate)) {
      threadsMap[emailKey].lastMessageDate = emailLog.date;
      threadsMap[emailKey].subject = emailLog.subject;
      if (emailLog.leadName) threadsMap[emailKey].leadName = emailLog.leadName;
      if (emailLog.leadId) threadsMap[emailKey].leadId = emailLog.leadId;
    }
  });

  // Convert map to array and sort threads by latest message date (newest first)
  const threads = Object.values(threadsMap).map(thread => {
    // Sort messages chronologically (oldest first) inside each thread
    thread.messages.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return thread;
  });
  const getLeadLastContactTime = (thread: Thread) => {
    const emailKey = thread.emailAddress.toLowerCase().trim();
    const associatedLead = leads.find(l => l.Email && l.Email.toLowerCase().trim() === emailKey);
    if (!associatedLead || !associatedLead['Last Contact Date'] || associatedLead['Last Contact Date'] === 'None') {
      return 0;
    }
    return new Date(associatedLead['Last Contact Date']).getTime();
  };

  threads.sort((a, b) => {
    if (sortBy === 'recent_email') {
      return new Date(b.lastMessageDate).getTime() - new Date(a.lastMessageDate).getTime();
    } else {
      return getLeadLastContactTime(b) - getLeadLastContactTime(a);
    }
  });

  // Filter threads based on selected tab filter
  const filteredThreads = threads.filter(thread => {
    if (filter === 'all') return true;
    return thread.messages.some(m => m.type === filter);
  });

  // Manage selection of current active thread dynamically based on filtered list
  useEffect(() => {
    if (filteredThreads.length > 0) {
      const alreadySelectedExists = filteredThreads.some(t => t.emailAddress === selectedThreadEmail);
      if (!selectedThreadEmail || !alreadySelectedExists) {
        setSelectedThreadEmail(filteredThreads[0].emailAddress);
      }
    } else {
      setSelectedThreadEmail(null);
    }
  }, [filteredThreads, selectedThreadEmail]);

  const selectedThread = threads.find(t => t.emailAddress === selectedThreadEmail);

  // Compute displayed messages using threadMessages and falling back/merging with local selectedThread messages
  const displayedMessages: EmailLog[] = [];
  if (selectedThread) {
    // Start with any messages we fetched from Gmail API
    if (threadMessages && threadMessages.length > 0) {
      displayedMessages.push(...threadMessages);
    }
    
    // Merge in any other local logs for this email address that weren't fetched from Gmail API
    selectedThread.messages.forEach(localMsg => {
      const alreadyExists = displayedMessages.some(m => 
        (m.id && m.id === localMsg.id) || 
        (m.subject === localMsg.subject && m.body === localMsg.body)
      );
      if (!alreadyExists) {
        displayedMessages.push(localMsg);
      }
    });
  }
  
  // Sort displayed messages chronologically (oldest first)
  displayedMessages.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  // Fetch thread messages when selected email changes
  useEffect(() => {
    if (selectedThreadEmail) {
      fetchThreadMessages(selectedThreadEmail);
    } else {
      setThreadMessages([]);
    }
  }, [selectedThreadEmail, token]);

  // Initialize reply subject when thread changes
  useEffect(() => {
    if (selectedThread) {
      const lastMsg = selectedThread.messages[selectedThread.messages.length - 1];
      if (lastMsg) {
        const subj = lastMsg.subject;
        if (subj.toLowerCase().startsWith('re:')) {
          setReplySubject(subj);
        } else {
          setReplySubject(`Re: ${subj}`);
        }
      }
    }
  }, [selectedThread, selectedThreadEmail]);

  // Handle Quick Reply Submit
  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedThread || !replyBody.trim()) return;

    setSendingReply(true);
    setReplyError('');

    try {
      const res = await fetch('/api/gmail/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token || 'sandbox_token'}`
        },
        body: JSON.stringify({
          leadId: selectedThread.leadId,
          email: selectedThread.emailAddress,
          subject: replySubject || `Re: Outreach`,
          body: replyBody
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setReplyBody('');
        if (selectedThreadEmail) {
          fetchThreadMessages(selectedThreadEmail);
        }
        fetchEmails(); // Reload message log
      } else {
        setReplyError(data.error || 'Failed to dispatch email reply.');
      }
    } catch (err: any) {
      setReplyError(err.message || 'Connection or network error.');
    } finally {
      setSendingReply(false);
    }
  };

  if (loading) return <div className="p-8 text-center text-[#888]">Loading messages...</div>;

  return (
    <div className="flex h-full bg-[#0A0A0A] rounded-2xl border border-[#222] overflow-hidden">
      {/* Sidebar List */}
      <div className="w-96 border-r border-[#222] bg-[#0C0C0C] flex flex-col">
        <div className="p-4 border-b border-[#222]">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#888]">Conversations</h2>
            <button 
              onClick={fetchEmails}
              className="p-1 hover:bg-[#1C1C1C] rounded text-[#666] hover:text-[#CCC] transition-colors"
              title="Refresh inbox"
            >
              <RefreshCw size={12} />
            </button>
          </div>
          <div className="flex space-x-2 bg-[#111] p-1 rounded-lg border border-[#222]">
            <button 
              onClick={() => setFilter('all')}
              className={`flex-1 text-[10px] uppercase font-bold py-1.5 rounded transition-colors ${filter === 'all' ? 'bg-[#222] text-white' : 'text-[#666] hover:text-[#AAA]'}`}
            >
              All
            </button>
            <button 
              onClick={() => setFilter('sent')}
              className={`flex-1 text-[10px] uppercase font-bold py-1.5 rounded transition-colors ${filter === 'sent' ? 'bg-[#222] text-blue-400' : 'text-[#666] hover:text-[#AAA]'}`}
            >
              Sent
            </button>
            <button 
              onClick={() => setFilter('received')}
              className={`flex-1 text-[10px] uppercase font-bold py-1.5 rounded transition-colors ${filter === 'received' ? 'bg-[#222] text-amber-400' : 'text-[#666] hover:text-[#AAA]'}`}
            >
              Replies
            </button>
          </div>

          <div className="flex items-center justify-between mt-3 px-1 text-[10px] text-[#555]">
            <span className="font-semibold uppercase tracking-wider">Sort by</span>
            <div className="flex space-x-2 bg-[#141414] border border-[#222] p-0.5 rounded-md">
              <button
                onClick={() => setSortBy('recent_email')}
                className={`px-2 py-0.5 rounded text-[9px] transition-all font-medium ${sortBy === 'recent_email' ? 'bg-[#222] text-emerald-400 font-semibold' : 'text-[#666] hover:text-[#999]'}`}
                title="Sort by latest retrieved Gmail message activity"
              >
                Recent Email
              </button>
              <button
                onClick={() => setSortBy('last_contact')}
                className={`px-2 py-0.5 rounded text-[9px] transition-all font-medium ${sortBy === 'last_contact' ? 'bg-[#222] text-emerald-400 font-semibold' : 'text-[#666] hover:text-[#999]'}`}
                title="Sort by latest manual or system contact date"
              >
                Last Contact
              </button>
            </div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {filteredThreads.length === 0 ? (
            <div className="text-center p-8 text-[#555] text-xs">No conversations found.</div>
          ) : (
            <div className="divide-y divide-[#181818]">
              {filteredThreads.map(t => {
                const latestMsg = t.messages[t.messages.length - 1];
                const isSelected = selectedThreadEmail === t.emailAddress;
                return (
                  <div 
                    key={t.emailAddress} 
                    onClick={() => setSelectedThreadEmail(t.emailAddress)}
                    className={`p-4 cursor-pointer transition-colors ${isSelected ? 'bg-[#181818] border-l-2 border-emerald-500' : 'hover:bg-[#111] border-l-2 border-transparent'}`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-[10px] text-[#555] font-mono">
                        {sortBy === 'recent_email' ? (
                          `Email: ${new Date(t.lastMessageDate).toLocaleDateString()}`
                        ) : (
                          `Contacted: ${(() => {
                            const emailKey = t.emailAddress.toLowerCase().trim();
                            const associatedLead = leads.find(l => l.Email && l.Email.toLowerCase().trim() === emailKey);
                            return associatedLead && associatedLead['Last Contact Date'] && associatedLead['Last Contact Date'] !== 'None'
                              ? new Date(associatedLead['Last Contact Date']).toLocaleDateString()
                              : 'Never';
                          })()}`
                        )}
                      </span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                        latestMsg.type === 'received' 
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                          : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                      }`}>
                        {latestMsg.type === 'received' ? 'Replied' : 'Sent'}
                      </span>
                    </div>
                    <div className="text-xs font-semibold text-white truncate">
                      {t.leadName || t.emailAddress}
                    </div>
                    {t.leadName && (
                      <div className="text-[10px] text-[#666] truncate">
                        {t.emailAddress}
                      </div>
                    )}
                    <div className="text-xs text-[#888] truncate mt-1">
                      {t.subject}
                    </div>
                    <div className="text-[10px] text-[#555] truncate mt-1 italic">
                      "{latestMsg.body}"
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Detail View */}
      <div className="flex-1 bg-[#0A0A0A] flex flex-col">
        {selectedThread ? (
          <>
            {/* Header */}
            <div className="p-6 border-b border-[#222]">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    <User size={18} />
                  </div>
                  <div>
                    <h1 className="text-base font-bold text-white">{selectedThread.leadName || selectedThread.emailAddress}</h1>
                    <div className="text-xs text-[#888] mt-0.5 flex items-center space-x-2 flex-wrap gap-y-1">
                      <span>{selectedThread.leadName ? `${selectedThread.emailAddress} • ` : ''}</span>
                      <span>{displayedMessages.length} messages in conversation</span>
                      {loadingThread && (
                        <span className="inline-flex items-center space-x-1 text-emerald-400 font-medium px-2 py-0.5 bg-emerald-500/5 rounded-md border border-emerald-500/10 ml-2 animate-pulse">
                          <RefreshCw size={10} className="animate-spin" />
                          <span className="text-[10px] uppercase tracking-wider font-semibold">Syncing Gmail...</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Message Thread List */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
              {displayedMessages.length === 0 && loadingThread ? (
                <div className="flex flex-col items-center justify-center h-full text-xs text-[#555] space-y-2">
                  <RefreshCw size={18} className="animate-spin text-emerald-500" />
                  <span>Loading full conversation thread...</span>
                </div>
              ) : displayedMessages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-xs text-[#555] italic">
                  No direct emails logged for this address. Type below to send a message.
                </div>
              ) : (
                displayedMessages.map((msg, index) => {
                  const isSent = msg.type === 'sent';
                  return (
                    <div 
                      key={msg.id || index}
                      className={`flex flex-col ${isSent ? 'items-end' : 'items-start'}`}
                    >
                      <div className="flex items-center space-x-2 text-[10px] text-[#555] mb-1 px-1">
                        <span>{isSent ? 'You' : (selectedThread.leadName || 'Prospect')}</span>
                        <span>•</span>
                        <span>{new Date(msg.date).toLocaleString()}</span>
                        {msg.simulated && (
                          <span className="text-sky-500 font-bold bg-sky-500/10 px-1 py-0.2 rounded text-[8px]">SIMULATED</span>
                        )}
                      </div>
                      
                      <div className={`max-w-2xl rounded-2xl p-4 border text-sm leading-relaxed ${
                        isSent 
                          ? 'bg-[#121212] border-blue-500/20 text-white rounded-tr-none' 
                          : 'bg-[#181818] border-amber-500/20 text-white rounded-tl-none'
                      }`}>
                        <div className={`text-xs font-semibold mb-2 ${isSent ? 'text-blue-400' : 'text-amber-400'}`}>
                          Subject: {msg.subject}
                        </div>
                        <div className="whitespace-pre-wrap font-sans text-xs text-[#CCC] selection:bg-emerald-500/35">
                          {msg.body}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Quick Reply Form */}
            <div className="p-4 bg-[#0C0C0C] border-t border-[#222]">
              <form onSubmit={handleSendReply} className="space-y-3">
                <div className="flex space-x-3 items-center">
                  <div className="text-xs font-semibold text-[#888] w-14">Subject:</div>
                  <input 
                    type="text" 
                    value={replySubject}
                    onChange={(e) => setReplySubject(e.target.value)}
                    className="flex-1 bg-[#141414] border border-[#222] text-xs text-white rounded-lg px-3 py-1.5 outline-none focus:border-emerald-500"
                    placeholder="Subject line"
                    required
                  />
                </div>
                
                <div className="flex flex-col space-y-2">
                  <textarea
                    value={replyBody}
                    onChange={(e) => setReplyBody(e.target.value)}
                    className="w-full h-24 bg-[#141414] border border-[#222] text-xs text-white rounded-xl p-3 outline-none focus:border-emerald-500 resize-none font-sans"
                    placeholder={`Type a quick response to ${selectedThread.leadName || selectedThread.emailAddress}...`}
                    required
                  />
                  
                  {replyError && (
                    <div className="text-xs text-rose-400 bg-rose-950/20 border border-rose-500/20 p-2 rounded-lg flex items-center space-x-1.5">
                      <AlertCircle size={12} />
                      <span>{replyError}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-1">
                    <span className="text-[10px] text-[#555]">
                      {token === 'sandbox_token' ? "⚡ Sandbox Mode: Responses will be simulated instantaneously" : "📧 Delivery via authenticated Gmail integration"}
                    </span>
                    <button
                      type="submit"
                      disabled={sendingReply || !replyBody.trim()}
                      className="flex items-center space-x-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl transition-all disabled:opacity-40"
                    >
                      {sendingReply ? (
                        <span>Sending...</span>
                      ) : (
                        <>
                          <span>Send Reply</span>
                          <ArrowRight size={12} />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-[#555]">
            <MessageSquare size={48} className="mb-4 opacity-20" />
            <p className="text-xs">Select a conversation thread to read</p>
          </div>
        )}
      </div>
    </div>
  );
}

