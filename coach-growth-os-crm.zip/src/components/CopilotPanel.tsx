import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, Bot, User, RefreshCw, Globe, ChevronDown, MessageSquare } from 'lucide-react';
import Markdown from 'react-markdown';
import { cn } from '../utils';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

interface Props {
  onClose?: () => void;
  className?: string;
}

export function CopilotPanel({ onClose, className }: Props) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const endOfMessagesRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initial welcome message
    if (messages.length === 0) {
      setMessages([{
        id: 'init-1',
        role: 'model',
        text: 'Hi! I am your Coach Growth OS Copilot. I can help you research online fitness & business coach prospects, analyze their coaching offers, draft personalized outreach, or organize your follow-up pipeline. How can I assist you today?'
      }]);
    }
  }, []);

  useEffect(() => {
    endOfMessagesRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input.trim()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Format history for the API
      const history = messages.filter(m => m.id !== 'init-1').map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userMessage.text,
          history
        })
      });

      const data = await res.json();
      
      if (data.success && data.text) {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'model',
          text: data.text
        }]);
      } else {
        throw new Error(data.error || 'Failed to get response');
      }
    } catch (err: any) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: `**Error:** ${err.message || 'I encountered an issue while trying to process your request.'}`
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={cn("flex flex-col h-full bg-[#0D0D0D] border border-[#222] rounded-2xl overflow-hidden shadow-xl", className)}>
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-[#222] bg-[#111]">
        <div className="flex items-center space-x-2">
          <div className="p-1.5 bg-sky-500/10 rounded-lg">
            <Sparkles size={16} className="text-sky-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white tracking-wide">AI Copilot</h3>
            <p className="text-[10px] text-emerald-400 font-medium flex items-center">
              <Globe size={10} className="mr-1" /> Grounded with Google Search
            </p>
          </div>
        </div>
        {onClose && (
          <button onClick={onClose} className="p-1.5 text-[#666] hover:text-white rounded-lg hover:bg-[#222] transition-colors">
            <ChevronDown size={18} />
          </button>
        )}
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={cn(
              "flex flex-col max-w-[85%]",
              msg.role === 'user' ? "ml-auto items-end" : "mr-auto items-start"
            )}
          >
            <div className="flex items-center space-x-1.5 mb-1 text-[10px] font-medium text-[#666]">
              {msg.role === 'user' ? (
                <>
                  <span>You</span>
                  <User size={10} />
                </>
              ) : (
                <>
                  <Bot size={10} className="text-sky-400" />
                  <span className="text-sky-400">Copilot</span>
                </>
              )}
            </div>
            <div 
              className={cn(
                "px-3 py-2.5 rounded-xl text-sm leading-relaxed",
                msg.role === 'user' 
                  ? "bg-[#222] text-white rounded-tr-sm" 
                  : "bg-sky-950/20 border border-sky-900/30 text-[#E0E0E0] rounded-tl-sm markdown-body"
              )}
            >
              <Markdown>{msg.text}</Markdown>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex flex-col mr-auto items-start max-w-[85%]">
             <div className="flex items-center space-x-1.5 mb-1 text-[10px] font-medium text-sky-400">
               <Bot size={10} />
               <span>Copilot</span>
             </div>
             <div className="px-4 py-3 bg-sky-950/20 border border-sky-900/30 rounded-xl rounded-tl-sm flex items-center space-x-2">
                <RefreshCw size={14} className="animate-spin text-sky-400" />
                <span className="text-xs text-sky-400/80">Researching & drafting...</span>
             </div>
          </div>
        )}
        <div ref={endOfMessagesRef} />
      </div>

      {/* Input Area */}
      <form 
        onSubmit={handleSend}
        className="p-3 bg-[#111] border-t border-[#222]"
      >
        <div className="relative flex items-center bg-[#1A1A1A] border border-[#333] rounded-xl overflow-hidden focus-within:border-sky-500/50 transition-colors">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything or draft an email..."
            className="flex-1 bg-transparent border-none text-sm text-white px-4 py-3 focus:outline-none placeholder:text-[#555]"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="mr-2 p-2 rounded-lg bg-sky-500 text-white disabled:opacity-50 disabled:bg-[#333] disabled:text-[#777] hover:bg-sky-400 transition-colors"
          >
            <Send size={16} />
          </button>
        </div>
        <div className="text-center mt-2">
           <span className="text-[10px] text-[#555]">
             Powered by Gemini 2.5 Flash with Real-Time Search Grounding
           </span>
        </div>
      </form>
    </div>
  );
}
