import React, { useState, useRef } from 'react';
import { Lead } from '../types';
import { Wand2, RefreshCw, Upload } from 'lucide-react';

interface Props {
  onSuccess: (leads: Lead[]) => void;
}

export function IntakeAssistant({ onSuccess }: Props) {
  const [rawText, setRawText] = useState('');
  const [processing, setProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleProcess = async () => {
    if (!rawText.trim()) return;

    try {
      setProcessing(true);
      const res = await fetch('/api/intake', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ rawText })
      });
      const data = await res.json();
      
      if (data.success) {
        onSuccess(data.leads);
        alert('Leads successfully parsed and added!');
        setRawText('');
      } else {
        alert(data.error || 'Failed to process leads.');
      }
    } catch (e) {
      console.error(e);
      alert('Failed to process leads.');
    } finally {
      setProcessing(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      const csvText = event.target?.result as string;
      try {
        setProcessing(true);
        const res = await fetch('/api/leads/csv-upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ csvText })
        });
        const data = await res.json();
        if (data.success) {
          onSuccess(data.leads);
          alert('CSV successfully imported!');
        } else {
          alert(data.error || 'Failed to parse CSV.');
        }
      } catch (err) {
        console.error(err);
        alert('Failed to upload CSV.');
      } finally {
        setProcessing(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-4 bg-[#111] rounded-xl border border-[#222]">
      <div className="flex items-center justify-between mb-2">
        <div className="text-[10px] uppercase tracking-widest text-emerald-400 font-bold flex items-center space-x-2">
          <Wand2 size={12} />
          <span>Data Intake Assistant</span>
        </div>
        <input 
          type="file" 
          accept=".csv" 
          ref={fileInputRef} 
          className="hidden" 
          onChange={handleFileUpload} 
        />
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="text-[9px] uppercase tracking-widest flex items-center space-x-1 text-[#888] hover:text-[#E0E0E0] transition-colors"
        >
          <Upload size={10} />
          <span>CSV</span>
        </button>
      </div>
      <p className="text-[10px] text-[#888] leading-relaxed italic mb-3">Drop messy lead strings here to auto-process and merge.</p>

      <textarea 
        className="w-full h-16 bg-transparent border-2 border-dashed border-[#333] rounded-lg p-2 text-[#E0E0E0] text-[10px] focus:border-emerald-500 outline-none resize-none"
        placeholder="Paste text..."
        value={rawText}
        onChange={(e) => setRawText(e.target.value)}
      />

      <div className="mt-2 flex justify-end">
        <button 
          onClick={handleProcess}
          disabled={processing || !rawText.trim()}
          className="text-[10px] bg-emerald-600/10 text-emerald-400 px-3 py-1.5 rounded-full border border-emerald-500/20 hover:bg-emerald-600/20 transition-colors disabled:opacity-50 flex items-center space-x-1"
        >
          {processing ? <RefreshCw className="animate-spin" size={12} /> : <Wand2 size={12} />}
          <span>{processing ? 'Processing...' : 'Process'}</span>
        </button>
      </div>
    </div>
  );
}
