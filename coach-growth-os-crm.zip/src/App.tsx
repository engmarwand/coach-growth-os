import React, { useState, useEffect } from 'react';
import { 
  Users, Mail, DollarSign, Target, 
  Send, RefreshCw, Check, LogOut, Briefcase, Inbox, Clock,
  Settings, User, Shield, ChevronDown, History, Wand2, Sparkles, BarChart2
} from 'lucide-react';
import { Lead, ActivityLog, ActivityType, ScheduledEmail, Template } from './types';
import { cn } from './utils';

import { LeadTable } from './components/LeadTable';
import { OutreachEngine } from './components/OutreachEngine';
import { IntakeAssistant } from './components/IntakeAssistant';
import { ClientsView } from './components/ClientsView';
import { TemplatesView } from './components/TemplatesView';
import { InboxView } from './components/InboxView';
import { RecentActivityPanel } from './components/RecentActivityPanel';
import { DashboardChart } from './components/DashboardChart';
import { CopilotPanel } from './components/CopilotPanel';
import { CampaignsView } from './components/CampaignsView';
import { ScheduledEmailsView } from './components/ScheduledEmailsView';

// Global types for Google GIS
declare global {
  interface Window {
    google: any;
  }
}

const API_BASE = '/api';
const LEADS_STORAGE_KEY = 'coachgrowthos_leads_store';
const LEGACY_LEADS_STORAGE_KEY = 'opsrelic_leads_store';
const ACTIVITIES_STORAGE_KEY = 'coachgrowthos_activities_store';
const LEGACY_ACTIVITIES_STORAGE_KEY = 'opsrelic_activities_store';

function loadCachedLeads(): Lead[] {
  try {
    const raw = localStorage.getItem(LEADS_STORAGE_KEY) || localStorage.getItem(LEGACY_LEADS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to load cached leads:', e);
  }
  return [];
}

function persistLeadsToStorage(leads: Lead[]) {
  try {
    localStorage.setItem(LEADS_STORAGE_KEY, JSON.stringify(leads));
  } catch (e) {
    console.error('Failed to persist leads to local storage:', e);
  }
}

function loadCachedActivities(): ActivityLog[] {
  try {
    const raw = localStorage.getItem(ACTIVITIES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to load cached activities:', e);
  }
  return [];
}

function persistActivitiesToStorage(activities: ActivityLog[]) {
  try {
    localStorage.setItem(ACTIVITIES_STORAGE_KEY, JSON.stringify(activities.slice(0, 200)));
  } catch (e) {
    console.error('Failed to persist activities to local storage:', e);
  }
}

const SCHEDULED_EMAILS_STORAGE_KEY = 'coachgrowthos_scheduled_emails_store';

function loadCachedScheduledEmails(): ScheduledEmail[] {
  try {
    const raw = localStorage.getItem(SCHEDULED_EMAILS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to load cached scheduled emails:', e);
  }
  return [];
}

function persistScheduledEmailsToStorage(emails: ScheduledEmail[]) {
  try {
    localStorage.setItem(SCHEDULED_EMAILS_STORAGE_KEY, JSON.stringify(emails));
  } catch (e) {
    console.error('Failed to persist scheduled emails:', e);
  }
}

function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('gmail_token'));
  // Initialize from durable local storage first so user never sees a blank flash or wiped data
  const [leads, setLeads] = useState<Lead[]>(() => loadCachedLeads());
  const [activities, setActivities] = useState<ActivityLog[]>(() => loadCachedActivities());
  const [sidebarSubTab, setSidebarSubTab] = useState<'activity' | 'intake'>('activity');
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeView, setActiveView] = useState<'dashboard' | 'pipeline' | 'campaigns' | 'clients' | 'templates' | 'inbox' | 'scheduled'>('dashboard');
  const [selectedLeadIds, setSelectedLeadIds] = useState<Set<string>>(new Set());
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'error'>('saved');
  
  // Scheduling & Campaign States
  const [scheduledEmails, setScheduledEmails] = useState<ScheduledEmail[]>(() => loadCachedScheduledEmails());
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
  const [templates, setTemplates] = useState<Template[]>([]);

  const [processedRepliedIds, setProcessedRepliedIds] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('coachgrowthos_processed_replies') || '[]');
    } catch {
      return [];
    }
  });

  const updateLeadsWithPersistence = (newLeads: Lead[]) => {
    setLeads(newLeads);
    persistLeadsToStorage(newLeads);
  };

  useEffect(() => {
    persistScheduledEmailsToStorage(scheduledEmails);
    fetch('/api/scheduled-emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ emails: scheduledEmails })
    }).catch(err => console.error('Failed to sync scheduled queue with server', err));
  }, [scheduledEmails]);

  // Auto-Pilot: If any lead replies, auto-cancel their remaining campaign follow-ups and auto-enroll a new lead
  useEffect(() => {
    const repliedLeads = leads.filter(l => l.Status === 'Replied' && !processedRepliedIds.includes(l.id));
    if (repliedLeads.length === 0) return;

    let updatedScheduled = [...scheduledEmails];
    let updatedLeads = [...leads];
    const newlyProcessed: string[] = [];

    repliedLeads.forEach(repliedLead => {
      newlyProcessed.push(repliedLead.id);

      // 1. Cancel remaining scheduled follow-ups for this lead
      let canceledCount = 0;
      let targetCampaignId = 'camp-coach-acquisition';

      updatedScheduled = updatedScheduled.map(email => {
        if (email.leadId === repliedLead.id && email.status === 'Scheduled') {
          canceledCount++;
          if (email.campaignId) {
            targetCampaignId = email.campaignId;
          }
          return { ...email, status: 'Cancelled' as const };
        }
        return email;
      });

      logActivity(
        'Status Changed',
        `Auto-Pilot: Lead ${repliedLead.Name || repliedLead.Email} replied!`,
        `Canceled ${canceledCount} remaining campaign follow-ups to prevent automated follow-up.`,
        repliedLead.Name || repliedLead.Email,
        repliedLead.id
      );

      // 2. Automatically trigger outreach to a new client (New lead status)
      const scheduledLeadIds = new Set(updatedScheduled.filter(e => e.status === 'Scheduled').map(e => e.leadId));
      const candidateLead = updatedLeads.find(l => l.Status === 'New' && l.Email && !scheduledLeadIds.has(l.id));

      if (candidateLead) {
        const step1Subject = targetCampaignId === 'camp-pipeline-revamp' 
          ? `${candidateLead.Name || 'Coach'} — stopping lead leakage`
          : `Quick question for you, ${candidateLead.Name || 'Coach'}`;

        const step1Body = `Hey ${candidateLead.Name || 'Coach'},\n\nAre you still manually managing your coaching leads, or do you have a system to keep track of who to follow up with?\n\nI build tailored lead-tracking workspaces specifically for coaches. It pulls your client inquiries into one dashboard so you always know exactly who needs a message today without digging through scattered Instagram DMs, sheets, or random notes.\n\nWould you be open to a quick look at a 2-minute walkthrough of the layout?\n\nBest,\n[My Name]\nCoach Growth OS\n\n(If you'd prefer not to hear from me, simply reply 'no thanks' and I won't follow up.)`;

        const newScheduledEmail: ScheduledEmail = {
          id: `sched_camp_auto_${targetCampaignId}_${candidateLead.id}_step_1_${Date.now()}`,
          leadId: candidateLead.id,
          leadName: candidateLead.Name || 'Prospect',
          emailAddress: candidateLead.Email,
          subject: step1Subject,
          body: step1Body,
          scheduledAt: new Date(Date.now() + 60000).toISOString(),
          status: 'Scheduled',
          isFollowUp: false,
          campaignId: targetCampaignId
        };

        updatedScheduled.push(newScheduledEmail);

        updatedLeads = updatedLeads.map(l => 
          l.id === candidateLead.id 
            ? { ...l, Status: 'Emailed', 'Last Contact Date': new Date().toISOString().split('T')[0] }
            : l
        );

        logActivity(
          'Email Scheduled',
          `Auto-Pilot: Enrolled new prospect ${candidateLead.Name || candidateLead.Email}`,
          `Triggered fresh outreach to maintain daily volume after ${repliedLead.Name || repliedLead.Email} replied.`,
          candidateLead.Name || candidateLead.Email,
          candidateLead.id
        );
      }
    });

    if (newlyProcessed.length > 0) {
      const allProcessed = [...processedRepliedIds, ...newlyProcessed];
      setProcessedRepliedIds(allProcessed);
      try {
        localStorage.setItem('coachgrowthos_processed_replies', JSON.stringify(allProcessed));
      } catch (e) {
        console.error(e);
      }
      setScheduledEmails(updatedScheduled);
      updateLeadsWithPersistence(updatedLeads);
      saveLeads(updatedLeads);
    }
  }, [leads]);

  useEffect(() => {
    fetchLeads();
    fetchActivities();
    
    fetch('/api/templates')
      .then(res => res.json())
      .then(data => setTemplates(data))
      .catch(console.error);

    fetch('/api/scheduled-emails')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.emails) && data.emails.length > 0) {
          setScheduledEmails(data.emails);
        }
      })
      .catch(console.error);
  }, []);

  // Poll backend for updates (since background loop runs natively on server now)
  useEffect(() => {
    const interval = setInterval(() => {
      fetch('/api/scheduled-emails')
        .then(res => res.json())
        .then(data => {
          if (data.success && Array.isArray(data.emails)) {
            setScheduledEmails(data.emails);
          }
        })
        .catch(console.error);

      fetch('/api/leads')
        .then(res => res.json())
        .then(data => {
          if (data.success && Array.isArray(data.leads)) {
            setLeads(data.leads);
          }
        })
        .catch(console.error);
    }, 10000); // Check every 10 seconds

    return () => clearInterval(interval);
  }, []);

  const handleSendNow = async (id: string) => {
    try {
      const res = await fetch(`/api/scheduled/${id}/send-now`, { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setScheduledEmails(prev => prev.map(e => e.id === id ? data.email : e));
      }
    } catch (e) {
      console.error('Failed to send immediately', e);
    }
  };

  const handleReschedule = async (id: string) => {
    const newDateStr = window.prompt('Enter new time in minutes from now (e.g., 5):', '5');
    if (!newDateStr) return;
    const mins = parseInt(newDateStr, 10);
    if (isNaN(mins)) return;
    
    const newDate = new Date(Date.now() + mins * 60000).toISOString();
    try {
      const res = await fetch(`/api/scheduled/${id}/reschedule`, { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scheduledAt: newDate })
      });
      const data = await res.json();
      if (data.success) {
        setScheduledEmails(prev => prev.map(e => e.id === id ? data.email : e));
      }
    } catch (e) {
      console.error('Failed to reschedule', e);
    }
  };

  // Auto-Pilot: If any lead replies, auto-cancel their remaining campaign follow-ups and auto-enroll a new lead
  useEffect(() => {
    const repliedLeads = leads.filter(l => l.Status === 'Replied' && !processedRepliedIds.includes(l.id));
    if (repliedLeads.length === 0) return;

    let updatedScheduled = [...scheduledEmails];
    let updatedLeads = [...leads];
    const newlyProcessed: string[] = [];

    repliedLeads.forEach(repliedLead => {
      newlyProcessed.push(repliedLead.id);

      // 1. Cancel remaining scheduled follow-ups for this lead
      let canceledCount = 0;
      let targetCampaignId = 'camp-coach-acquisition';

      updatedScheduled = updatedScheduled.map(email => {
        if (email.leadId === repliedLead.id && email.status === 'Scheduled') {
          canceledCount++;
          if (email.campaignId) {
            targetCampaignId = email.campaignId;
          }
          return { ...email, status: 'Cancelled' as const };
        }
        return email;
      });

      logActivity(
        'Status Changed',
        `Auto-Pilot: Lead ${repliedLead.Name || repliedLead.Email} replied!`,
        `Canceled ${canceledCount} remaining campaign follow-ups to prevent automated follow-up.`,
        repliedLead.Name || repliedLead.Email,
        repliedLead.id
      );

      // 2. Automatically trigger outreach to a new client (New lead status)
      const scheduledLeadIds = new Set(updatedScheduled.filter(e => e.status === 'Scheduled').map(e => e.leadId));
      const candidateLead = updatedLeads.find(l => l.Status === 'New' && l.Email && !scheduledLeadIds.has(l.id));

      if (candidateLead) {
        const step1Subject = targetCampaignId === 'camp-pipeline-revamp' 
          ? `${candidateLead.Name || 'Coach'} — stopping lead leakage`
          : `Quick question for you, ${candidateLead.Name || 'Coach'}`;

        const step1Body = `Hey ${candidateLead.Name || 'Coach'},\n\nAre you still manually managing your coaching leads, or do you have a system to keep track of who to follow up with?\n\nI build tailored lead-tracking workspaces specifically for coaches. It pulls your client inquiries into one dashboard so you always know exactly who needs a message today without digging through scattered Instagram DMs, sheets, or random notes.\n\nWould you be open to a quick look at a 2-minute walkthrough of the layout?\n\nBest,\n[My Name]\nCoach Growth OS\n\n(If you'd prefer not to hear from me, simply reply 'no thanks' and I won't follow up.)`;

        const newScheduledEmail: ScheduledEmail = {
          id: `sched_camp_auto_${targetCampaignId}_${candidateLead.id}_step_1_${Date.now()}`,
          leadId: candidateLead.id,
          leadName: candidateLead.Name || 'Prospect',
          emailAddress: candidateLead.Email,
          subject: step1Subject,
          body: step1Body,
          scheduledAt: new Date(Date.now() + 60000).toISOString(),
          status: 'Scheduled',
          isFollowUp: false,
          campaignId: targetCampaignId
        };

        updatedScheduled.push(newScheduledEmail);

        updatedLeads = updatedLeads.map(l => 
          l.id === candidateLead.id 
            ? { ...l, Status: 'Emailed', 'Last Contact Date': new Date().toISOString().split('T')[0] }
            : l
        );

        logActivity(
          'Email Scheduled',
          `Auto-Pilot: Enrolled new prospect ${candidateLead.Name || candidateLead.Email}`,
          `Triggered fresh outreach to maintain daily volume after ${repliedLead.Name || repliedLead.Email} replied.`,
          candidateLead.Name || candidateLead.Email,
          candidateLead.id
        );
      }
    });

    if (newlyProcessed.length > 0) {
      const allProcessed = [...processedRepliedIds, ...newlyProcessed];
      setProcessedRepliedIds(allProcessed);
      try {
        localStorage.setItem('coachgrowthos_processed_replies', JSON.stringify(allProcessed));
      } catch (e) {
        console.error(e);
      }
      setScheduledEmails(updatedScheduled);
      updateLeadsWithPersistence(updatedLeads);
      saveLeads(updatedLeads);
    }
  }, [leads]);

  useEffect(() => {
    fetchLeads();
    fetchActivities();
    
    fetch('/api/templates')
      .then(res => res.json())
      .then(data => setTemplates(data))
      .catch(console.error);

    fetch('/api/scheduled-emails')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.emails) && data.emails.length > 0) {
          setScheduledEmails(data.emails);
        }
      })
      .catch(console.error);
  }, []);

  // Background Scheduler Simulation Loop
  useEffect(() => {
    const interval = setInterval(() => {
      if (scheduledEmails.length === 0) return;
      
      const now = new Date();
      let sentCount = 0;
      
      setScheduledEmails(prev => {
        const next = [...prev];
        let hasChanges = false;
        
        next.forEach(email => {
          if (email.status === 'Scheduled' && new Date(email.scheduledAt) <= now) {
            email.status = 'Sent';
            hasChanges = true;
            sentCount++;
            
            // Mock sending by logging activity and updating last contact date
            logActivity('Email Sent', `Scheduled Email sent to ${email.leadName}`, email.subject, email.leadName, email.leadId);
            
            // Update Lead last contact date
            setLeads(currentLeads => {
              const updatedLeads = currentLeads.map(l => 
                l.id === email.leadId ? { ...l, 'Last Contact Date': new Date().toISOString().split('T')[0] } : l
              );
              persistLeadsToStorage(updatedLeads);
              return updatedLeads;
            });
          }
        });
        
        return hasChanges ? next : prev;
      });
      
    }, 10000); // check every 10 seconds
    
    return () => clearInterval(interval);
  }, [scheduledEmails]);

  const fetchActivities = async () => {
    try {
      const res = await fetch(`${API_BASE}/activities`);
      if (res.ok) {
        const serverActivities: ActivityLog[] = await res.json();
        if (Array.isArray(serverActivities) && serverActivities.length > 0) {
          setActivities(serverActivities);
          persistActivitiesToStorage(serverActivities);
        }
      }
    } catch (e) {
      console.error('Failed to fetch activities from server', e);
    }
  };

  const logActivity = (type: ActivityType, title: string, details?: string, leadName?: string, leadId?: string) => {
    const newAct: ActivityLog = {
      id: Math.random().toString(36).substring(2, 9),
      type,
      title,
      details: details || '',
      leadName: leadName || '',
      leadId: leadId || '',
      timestamp: new Date().toISOString()
    };
    setActivities(prev => {
      const updated = [newAct, ...prev];
      persistActivitiesToStorage(updated);
      return updated;
    });

    fetch(`${API_BASE}/activities`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newAct)
    }).catch(err => console.error('Failed to log activity to backend', err));
  };

  const handleClearActivities = async () => {
    setActivities([]);
    persistActivitiesToStorage([]);
    try {
      await fetch(`${API_BASE}/activities/clear`, { method: 'POST' });
    } catch (e) {
      console.error('Failed to clear activities on server', e);
    }
  };

  const handleEmailSent = (info: { leadName: string; email: string; subject: string; leadId?: string }) => {
    logActivity(
      'Email Sent',
      `Outreach sent to ${info.leadName}`,
      `Subject: ${info.subject}`,
      info.leadName,
      info.leadId
    );
  };

  const fetchLeads = async () => {
    try {
      setLoading(true);
      const res = await fetch(`${API_BASE}/leads`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const serverLeads: Lead[] = await res.json();
      
      const cached = loadCachedLeads();

      if (Array.isArray(serverLeads) && serverLeads.length > 0) {
        // Server has leads, synchronize with state and persistent cache
        updateLeadsWithPersistence(serverLeads);
        setSaveStatus('saved');
      } else if (cached.length > 0) {
        // Server returned empty array (e.g. fresh container instance), but local storage has leads!
        // Self-heal: keep cached leads in state and immediately re-hydrate the server
        updateLeadsWithPersistence(cached);
        setSaveStatus('saving');
        try {
          await fetch(`${API_BASE}/leads/sync`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ leads: cached })
          });
          setSaveStatus('saved');
        } catch (syncErr) {
          console.error('Failed to rehydrate server with cached leads', syncErr);
        }
      } else {
        updateLeadsWithPersistence([]);
        setSaveStatus('saved');
      }
    } catch (err) {
      console.error('Failed to fetch leads from server, using local cache', err);
      const cached = loadCachedLeads();
      if (cached.length > 0) {
        setLeads(cached);
      }
      setSaveStatus('saved');
    } finally {
      setLoading(false);
    }
  };

  const handleAuth = () => {
    const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || "912855402911-gtalmpkgjd5ijamrsokqvm746kg3c39l.apps.googleusercontent.com";
    if (!clientId) {
      alert("Missing Google Client ID.");
      return;
    }
    const client = window.google.accounts.oauth2.initTokenClient({
      client_id: clientId,
      scope: 'https://www.googleapis.com/auth/gmail.readonly https://www.googleapis.com/auth/gmail.send',
      callback: (response: any) => {
        if (response.error !== undefined) {
          console.error(response);
          return;
        }
        localStorage.setItem('gmail_token', response.access_token);
        setToken(response.access_token);
      }
    });
    client.requestAccessToken();
  };

  const handleDisconnect = () => {
    localStorage.removeItem('gmail_token');
    setToken(null);
  };

  const saveLeads = async (newLeads: Lead[]) => {
    updateLeadsWithPersistence(newLeads);
    setSaveStatus('saving');
    try {
      const res = await fetch(`${API_BASE}/leads`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ leads: newLeads })
      });
      if (res.ok) {
        setSaveStatus('saved');
      } else {
        setSaveStatus('error');
      }
    } catch (err) {
      console.error('Failed to save leads to backend', err);
      setSaveStatus('error');
    }
  };

  const handleAddLead = async (leadData: Omit<Lead, 'id'>) => {
    setSaveStatus('saving');
    logActivity(
      'Lead Added',
      `Added ${leadData.Name || 'New Prospect'}`,
      `Niche: ${leadData.Niche || 'General'} · Value: $${leadData['Deal Value'] || '0'}`,
      leadData.Name || 'New Prospect'
    );
    try {
      const res = await fetch('/api/leads/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lead: leadData })
      });
      const data = await res.json();
      if (data.success && data.leads) {
        updateLeadsWithPersistence(data.leads);
        setSaveStatus('saved');
        return;
      }
    } catch (e) {
      console.error('Failed to create lead on server, persisting locally', e);
    }

    // Fallback: guaranteed local save if network had an issue
    const newLead: Lead = {
      id: Math.random().toString(36).substring(2, 9),
      Name: leadData.Name || 'New Prospect',
      Niche: leadData.Niche || '',
      Country: leadData.Country || '',
      Email: leadData.Email || '',
      Website: leadData.Website || '',
      Status: leadData.Status || 'New',
      'Deal Value': leadData['Deal Value'] || '0',
      'Last Contact Date': leadData['Last Contact Date'] || '',
      Notes: leadData.Notes || '',
      'Onboarding Stage': leadData['Onboarding Stage'] || ''
    };
    const updated = [newLead, ...leads];
    updateLeadsWithPersistence(updated);
    saveLeads(updated);
  };

  const updateLead = (id: string, field: keyof Lead, value: string) => {
    const targetLead = leads.find(l => l.id === id);
    if (field === 'Status' && targetLead && targetLead.Status !== value) {
      logActivity(
        'Status Changed',
        `${targetLead.Name || 'Lead'}: ${targetLead.Status} → ${value}`,
        `Pipeline stage updated to ${value}`,
        targetLead.Name,
        id
      );
    }
    const updated = leads.map(l => l.id === id ? { ...l, [field]: value } : l);
    saveLeads(updated);
  };

  const updateLeadFields = (id: string, updates: Partial<Lead>) => {
    const updated = leads.map(l => l.id === id ? { ...l, ...updates } : l);
    saveLeads(updated);
  };

  const deleteLead = async (id: string) => {
    const updated = leads.filter(l => l.id !== id);
    updateLeadsWithPersistence(updated);
    try {
      await fetch(`/api/leads/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.error('Failed to delete on server', e);
    }
  };

  const clearLeads = async () => {
    updateLeadsWithPersistence([]);
    try {
      await fetch('/api/leads/clear', { method: 'POST' });
    } catch (e) {
      console.error('Failed to clear on server', e);
    }
  };

  const handleScanInbox = async () => {
    if (!token) return handleAuth();
    try {
      setLoading(true);
      const res = await fetch(`${API_BASE}/gmail/scan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await res.json();
      if (data.success) {
        setLeads(data.leads);
        alert('Inbox scanned successfully! Leads updated.');
      }
    } catch (e) {
      console.error(e);
      alert('Error scanning inbox');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectForOutreach = (leadId: string) => {
    setSelectedLeadIds(new Set([leadId]));
    setActiveView('pipeline');
  };

  const handleEmailScheduled = (email: ScheduledEmail) => {
    setScheduledEmails(prev => [...prev, email]);
    logActivity('Email Scheduled', `Scheduled Email to ${email.leadName}`, email.subject, email.leadName, email.leadId);
  };

  const handleBulkSchedule = (emails: ScheduledEmail[]) => {
    setScheduledEmails(prev => [...prev, ...emails]);
    logActivity('Email Scheduled', `Scheduled Campaign for ${emails.length} leads`, '', '', '');
  };

  // Metrics
  const totalLeads = leads.length;
  const outreachSent = leads.filter(l => ['Emailed', 'Followed Up', 'Replied', 'Meeting Scheduled', 'Closed Won', 'Closed Lost'].includes(l.Status)).length;
  const closedWonRevenue = leads
    .filter(l => l.Status === 'Closed Won')
    .reduce((acc, l) => acc + (parseFloat(l['Deal Value']) || 0), 0);
  const winRate = totalLeads > 0 ? (leads.filter(l => l.Status === 'Closed Won').length / totalLeads) * 100 : 0;

  return (
    <div className="h-screen w-full bg-[#050505] text-[#E0E0E0] font-sans flex overflow-hidden">
      
      {/* Sidebar */}
      <aside className="w-72 border-r border-[#222] bg-[#0A0A0A] flex flex-col p-5 space-y-6">
        
        {/* Brand */}
        <div className="flex items-center space-x-3 px-1">
          <div className="w-8 h-8 bg-emerald-500 rounded-xl flex items-center justify-center font-bold text-black shadow-md font-mono text-xs">
            CG
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-white">Coach Growth OS</h1>
            <span className="text-[10px] text-emerald-400 font-mono">Lead & Follow-Up OS</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="space-y-1.5">
          <button
            onClick={() => setActiveView('dashboard')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'dashboard' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <BarChart2 size={15} />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => setActiveView('pipeline')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'pipeline' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Users size={15} />
            <span>Lead Pipeline</span>
            <span className="ml-auto text-[10px] opacity-70 font-mono">({leads.length})</span>
          </button>

          <button
            onClick={() => setActiveView('campaigns')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'campaigns' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Send size={15} />
            <span>Campaigns</span>
          </button>

          <button
            onClick={() => setActiveView('clients')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'clients' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Briefcase size={15} />
            <span>Active Clients</span>
            <span className="ml-auto text-[10px] opacity-70 font-mono">
              ({leads.filter(l => l.Status === 'Closed Won').length})
            </span>
          </button>

          <button
            onClick={() => setActiveView('templates')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'templates' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Mail size={15} />
            <span>Email Templates</span>
          </button>

          <button
            onClick={() => setActiveView('scheduled')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'scheduled' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Clock size={15} />
            <span>Scheduled Emails</span>
            {scheduledEmails.filter(e => e.status === 'Scheduled').length > 0 && (
              <span className="ml-auto text-[9px] bg-sky-500 text-black px-1.5 py-0.5 rounded-full font-bold">
                {scheduledEmails.filter(e => e.status === 'Scheduled').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveView('inbox')}
            className={cn(
              "w-full flex items-center space-x-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all",
              activeView === 'inbox' 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : "text-[#888] hover:bg-[#121212] hover:text-white"
            )}
          >
            <Inbox size={15} />
            <span>Communications</span>
          </button>
        </nav>

        {/* Gmail Status */}
        <div className="bg-[#0F0F0F] border border-[#222] rounded-2xl p-3.5 space-y-2.5">
          <div className="flex justify-between items-center text-[10px] uppercase tracking-wider font-bold text-[#777]">
            <span>Google Delivery</span>
            {token ? (
              <span className="text-emerald-400 flex items-center space-x-1">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                <span>Connected</span>
              </span>
            ) : (
              <span className="text-amber-400">Offline</span>
            )}
          </div>

          {!token ? (
            <button 
              onClick={handleAuth}
              className="w-full bg-[#181818] hover:bg-[#202020] text-[#CCC] hover:text-white py-2 rounded-xl text-xs font-semibold border border-[#2A2A2A] transition-colors flex items-center justify-center space-x-2"
            >
              <Mail size={13} />
              <span>Connect Gmail</span>
            </button>
          ) : (
            <button 
              onClick={handleDisconnect}
              className="w-full bg-[#161616] hover:bg-[#222] text-[#888] hover:text-white py-1.5 rounded-xl text-[11px] font-medium border border-[#222] transition-colors flex items-center justify-center space-x-1.5"
            >
              <LogOut size={12} />
              <span>Disconnect Gmail</span>
            </button>
          )}
        </div>

        {/* Sidebar Sub-Navigation: Recent Activity vs AI Quick Intake */}
        <div className="flex items-center p-1 bg-[#121212] border border-[#222] rounded-xl text-xs">
          <button
            onClick={() => setSidebarSubTab('activity')}
            className={cn(
              "flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-all",
              sidebarSubTab === 'activity'
                ? "bg-[#222] text-white shadow-sm"
                : "text-[#777] hover:text-[#CCC]"
            )}
          >
            <History size={12} className={sidebarSubTab === 'activity' ? "text-emerald-400" : ""} />
            <span>Activity</span>
            {activities.length > 0 && (
              <span className="text-[9px] px-1.5 py-0.2 bg-emerald-500/20 text-emerald-400 rounded-full font-mono font-medium">
                {activities.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setSidebarSubTab('intake')}
            className={cn(
              "flex-1 flex items-center justify-center space-x-1.5 py-1.5 rounded-lg font-semibold transition-all",
              sidebarSubTab === 'intake'
                ? "bg-[#222] text-white shadow-sm"
                : "text-[#777] hover:text-[#CCC]"
            )}
          >
            <Wand2 size={12} className={sidebarSubTab === 'intake' ? "text-emerald-400" : ""} />
            <span>AI Intake</span>
          </button>
        </div>

        {/* Lower Sidebar Section: Recent Activity or AI Intake */}
        <div className="flex-1 min-h-[160px] overflow-hidden flex flex-col">
          {sidebarSubTab === 'activity' ? (
            <RecentActivityPanel 
              activities={activities}
              onClearActivities={handleClearActivities}
              onSelectLead={(id) => {
                setSelectedLeadIds(new Set([id]));
                setActiveView('pipeline');
              }}
            />
          ) : (
            <IntakeAssistant onSuccess={(data) => {
              updateLeadsWithPersistence(data);
              logActivity('Lead Added', `Imported prospects via AI Intake`, `${data.length} total prospects in pipeline`);
            }} />
          )}
        </div>

        {/* Profile Avatar & Dropdown */}
        <div className="relative pt-2 border-t border-[#1C1C1C]">
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-[#141414] transition-colors group"
          >
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-black font-bold text-xs">
                CG
              </div>
              <div className="text-left">
                <div className="text-xs font-semibold text-white">Coach Growth OS</div>
                <div className="text-[10px] text-[#666]">founder@coachgrowthos.com</div>
              </div>
            </div>
            <ChevronDown size={14} className="text-[#666] group-hover:text-white transition-colors" />
          </button>

          {showProfileMenu && (
            <div className="absolute bottom-14 left-0 right-0 bg-[#141414] border border-[#2A2A2A] rounded-2xl shadow-2xl p-1.5 space-y-1 z-50 animate-in fade-in slide-in-from-bottom-2 duration-150">
              <div className="px-3 py-2 text-[10px] uppercase font-bold text-[#666] border-b border-[#222]">
                System: <span className="text-emerald-400">Founder Edition</span>
              </div>
              <button 
                onClick={() => { setShowProfileMenu(false); setActiveView('pipeline'); }}
                className="w-full text-left px-3 py-2 text-xs text-[#CCC] hover:text-white hover:bg-[#202020] rounded-xl flex items-center space-x-2 transition-colors"
              >
                <Settings size={13} />
                <span>Workspace Settings</span>
              </button>
              <button 
                onClick={() => { setShowProfileMenu(false); alert("Plan: Agency Full Subscription (Active)"); }}
                className="w-full text-left px-3 py-2 text-xs text-[#CCC] hover:text-white hover:bg-[#202020] rounded-xl flex items-center space-x-2 transition-colors"
              >
                <Shield size={13} />
                <span>Subscription & Billing</span>
              </button>
              <button 
                onClick={() => { 
                  setShowProfileMenu(false); 
                  if (token) handleDisconnect();
                  alert("Logged out session successfully.");
                }}
                className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 rounded-xl flex items-center space-x-2 transition-colors"
              >
                <LogOut size={13} />
                <span>Log Out</span>
              </button>
            </div>
          )}
        </div>

      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col p-6 space-y-6 overflow-hidden relative">
        {loading && (
          <div className="absolute inset-0 z-30 bg-[#0A0A0A]/60 flex items-center justify-center backdrop-blur-sm">
            <RefreshCw className="animate-spin text-emerald-400" size={24} />
          </div>
        )}
        
        {activeView === 'dashboard' ? (
          <div className="h-full flex flex-col space-y-6 overflow-y-auto pr-1">
            {/* Dashboard Header */}
            <div className="flex justify-between items-center bg-[#0D0D0D] border border-[#222] p-5 rounded-2xl">
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight flex items-center space-x-2">
                  <BarChart2 className="text-emerald-400" size={22} />
                  <span>Coach Outreach & Growth Dashboard</span>
                </h1>
                <p className="text-xs text-[#888] mt-1">High-level overview of coach prospects, outreach activity, and pipeline revenue.</p>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={() => setActiveView('campaigns')}
                  className="bg-sky-500 hover:bg-sky-400 text-black px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center space-x-1.5"
                >
                  <Send size={13} />
                  <span>Launch Campaign</span>
                </button>
                <button 
                  onClick={() => setActiveView('pipeline')}
                  className="bg-[#181818] hover:bg-[#222] text-white border border-[#333] px-4 py-2 rounded-xl text-xs font-semibold transition-colors flex items-center space-x-1.5"
                >
                  <Users size={13} />
                  <span>View Pipeline</span>
                </button>
              </div>
            </div>

            {/* KPI Metrics Bar */}
            <section className="grid grid-cols-4 gap-4">
              <MetricCard title="Total Leads in System" value={totalLeads.toString()} accent="text-emerald-400" suffix="+12%" />
              <MetricCard title="Outreach Dispatched" value={outreachSent.toString()} accent="text-blue-400" suffix="Outreach" />
              <MetricCard title="Closed Won Revenue" value={closedWonRevenue.toLocaleString()} prefix="$" />
              <MetricCard title="Pipeline Win Rate" value={winRate.toFixed(1)} suffix="%" accent="text-emerald-400" />
            </section>

            {/* Visual Analytics & Reply Activity */}
            <div className="flex-1 grid grid-cols-3 gap-6 min-h-[400px]">
              <div className="col-span-2 bg-[#0A0A0A] border border-[#222] rounded-2xl flex flex-col overflow-hidden shadow-xl p-4">
                <h2 className="text-xs font-bold uppercase tracking-wider text-[#888] mb-2">Outreach & Activity Velocity</h2>
                <div className="flex-1 min-h-[320px]">
                  <DashboardChart activities={activities} />
                </div>
              </div>
              <div className="col-span-1 bg-[#0A0A0A] border border-[#222] rounded-2xl flex flex-col overflow-hidden shadow-xl">
                <RecentActivityPanel 
                  activities={activities}
                  onClearActivities={handleClearActivities}
                  onSelectLead={(id) => {
                    setSelectedLeadIds(new Set([id]));
                    setActiveView('pipeline');
                  }}
                />
              </div>
            </div>
          </div>
        ) : activeView === 'pipeline' ? (
          <div className="h-full grid grid-cols-3 gap-6">
            <div className="col-span-2 flex flex-col space-y-6 overflow-hidden">
              <div className="flex-1 bg-[#0A0A0A] border border-[#222] rounded-2xl flex flex-col overflow-hidden shadow-xl">
                 <LeadTable 
                   leads={leads} 
                   onUpdate={updateLead} 
                   onBulkUpdate={updateLeadFields}
                   onScan={handleScanInbox}
                   hasToken={!!token}
                   onImport={(data) => {
                     updateLeadsWithPersistence(data);
                     saveLeads(data);
                   }}
                   onDelete={deleteLead}
                   onClear={clearLeads}
                   selectedIds={selectedLeadIds}
                   onSelectionChange={setSelectedLeadIds}
                   onAddLead={handleAddLead}
                   onSelectForOutreach={handleSelectForOutreach}
                   onBulkCampaign={() => setActiveView('campaigns')}
                   saveStatus={saveStatus}
                 />
              </div>
            </div>
            
            <div className="flex flex-col space-y-6 overflow-hidden">
               <div className="flex-1 bg-[#0A0A0A] border border-[#222] rounded-2xl flex flex-col overflow-hidden shadow-2xl">
                  <OutreachEngine 
                    leads={leads}
                    token={token}
                    onRequestAuth={handleAuth}
                    onSuccess={(updatedLeadsList) => {
                      setLeads(prevLeads => {
                        const updated = prevLeads.map(l => {
                          const updatedVersion = updatedLeadsList.find(ul => ul.id === l.id);
                          return updatedVersion ? { ...l, ...updatedVersion } : l;
                        });
                        persistLeadsToStorage(updated);
                        // Save to server asynchronously
                        fetch('/api/leads', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ leads: updated })
                        }).catch(err => console.error('Failed to sync updated leads to server', err));
                        return updated;
                      });
                    }}
                    selectedLeadIds={selectedLeadIds}
                    onEmailSent={handleEmailSent}
                    onEmailScheduled={handleEmailScheduled}
                  />
               </div>
               
               {/* Quick Scanner Mini Widget */}
               <div className="h-36 bg-[#0A0A0A] border border-[#222] rounded-2xl p-4 flex flex-col">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#888]">Reply Scanner</h3>
                    <button 
                      onClick={handleScanInbox}
                      className="bg-emerald-500/10 text-emerald-400 p-1 rounded-lg hover:bg-emerald-500/20 transition-colors"
                      title="Scan inbox for prospect replies"
                    >
                      <RefreshCw size={12} className={loading ? 'animate-spin' : ''} />
                    </button>
                  </div>
                  <div className="flex-1 space-y-1.5 overflow-y-auto pr-1">
                    {leads.filter(l => l.Status === 'Replied').slice(0, 3).map((l, i) => (
                      <div 
                        key={i} 
                        onClick={() => handleSelectForOutreach(l.id)}
                        className="flex justify-between items-center text-xs bg-[#121212] p-2 rounded-xl border border-[#222] cursor-pointer hover:border-emerald-500/40 transition-colors"
                      >
                        <span className="text-white font-medium truncate max-w-[120px]">{l.Name}</span>
                        <span className="text-[10px] bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full font-semibold">Replied</span>
                      </div>
                    ))}
                    {leads.filter(l => l.Status === 'Replied').length === 0 && (
                       <div className="text-xs text-[#555] text-center mt-3 italic">No recent replies detected.</div>
                    )}
                  </div>
               </div>
            </div>
          </div>
        ) : activeView === 'campaigns' ? (
          <div className="h-full bg-[#0A0A0A] border border-[#222] rounded-2xl flex flex-col overflow-hidden shadow-xl">
            <CampaignsView 
              leads={leads}
              templates={templates}
              onScheduleCampaign={handleBulkSchedule}
              onNavigateToScheduled={() => setActiveView('scheduled')}
              onScheduledUpdate={(queue) => {
                setScheduledEmails(queue);
                persistScheduledEmailsToStorage(queue);
              }}
            />
          </div>
        ) : activeView === 'clients' ? (
          <div className="h-full">
            <ClientsView 
              leads={leads} 
              onUpdate={updateLead} 
              onNavigateToPipeline={() => setActiveView('pipeline')} 
            />
          </div>
        ) : activeView === 'inbox' ? (
          <div className="h-full">
            <InboxView leads={leads} />
          </div>
        ) : activeView === 'scheduled' ? (
          <div className="h-full">
            <ScheduledEmailsView 
              emails={scheduledEmails} 
              onCancelEmail={(id) => {
                setScheduledEmails(prev => prev.filter(e => e.id !== id));
                // Will automatically sync to backend via useEffect
              }}
              onSendNow={handleSendNow}
              onReschedule={handleReschedule}
            />
          </div>
        ) : (
          <div className="h-full">
            <TemplatesView />
          </div>
        )}
      </main>

      {/* Floating Copilot Chat */}
      {isCopilotOpen ? (
        <div className="absolute bottom-6 right-6 w-96 h-[500px] shadow-2xl z-50 flex flex-col animate-in slide-in-from-bottom-5 fade-in duration-200">
          <CopilotPanel onClose={() => setIsCopilotOpen(false)} />
        </div>
      ) : (
        <button
          onClick={() => setIsCopilotOpen(true)}
          className="absolute bottom-6 right-6 p-4 bg-sky-500 hover:bg-sky-400 text-white rounded-full shadow-lg shadow-sky-500/20 hover:shadow-sky-500/40 hover:-translate-y-1 transition-all z-50 flex items-center justify-center group"
          title="Open AI Copilot"
        >
          <Sparkles size={24} className="group-hover:scale-110 transition-transform" />
        </button>
      )}
    </div>
  );
}

// ----------------------------------------------------------------------
// Sub-components
// ----------------------------------------------------------------------

function MetricCard({ title, value, prefix, suffix, accent }: { title: string, value: string, prefix?: string, suffix?: string, accent?: string }) {
  return (
    <div className="bg-[#0A0A0A] border border-[#222] rounded-2xl p-4 flex flex-col justify-between shadow-sm">
      <span className="text-[10px] uppercase text-[#666] font-bold tracking-wider">{title}</span>
      <div className="flex items-baseline space-x-1.5 mt-2">
        {prefix && <span className="text-sm font-semibold text-[#888]">{prefix}</span>}
        <span className="text-2xl font-bold text-white font-mono">{value}</span>
        {suffix && <span className={cn("text-xs font-semibold ml-1", accent || "text-[#888]")}>{suffix}</span>}
      </div>
    </div>
  );
}

export default App;
