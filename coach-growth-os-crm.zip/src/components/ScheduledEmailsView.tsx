import React from 'react';
import { ScheduledEmail } from '../types';
import { Clock, Send, XCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { cn } from '../utils';

interface Props {
  emails: ScheduledEmail[];
  onCancelEmail?: (id: string) => void;
  onSendNow?: (id: string) => void;
  onReschedule?: (id: string) => void;
}

function formatEST(isoString: string): string {
  try {
    const d = new Date(isoString);
    const formatted = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(d);
    return `${formatted} ET`;
  } catch {
    return isoString;
  }
}

export function ScheduledEmailsView({ emails, onCancelEmail, onSendNow, onReschedule }: Props) {
  const upcoming = emails.filter(e => e.status === 'Scheduled').sort((a, b) => new Date(a.scheduledAt).getTime() - new Date(b.scheduledAt).getTime());
  const failed = emails.filter(e => e.status === 'Failed').sort((a, b) => new Date(b.scheduledAt).getTime() - new Date(a.scheduledAt).getTime());
  const past = emails.filter(e => e.status !== 'Scheduled' && e.status !== 'Failed').sort((a, b) => new Date(b.scheduledAt).getTime() - new Date(a.scheduledAt).getTime());

  return (
    <div className="h-full flex flex-col p-6 bg-[#050505] overflow-y-auto">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-white flex items-center space-x-2">
          <Clock className="text-sky-400" />
          <span>Scheduled Emails</span>
        </h2>
        <p className="text-xs text-[#888] mt-1">Manage your upcoming and past scheduled automated outreach.</p>
      </div>

      <div className="space-y-6">
        {failed.length > 0 && (
          <section>
            <h3 className="text-sm font-bold text-rose-500 mb-3 uppercase tracking-wider flex items-center gap-2">
              <AlertTriangle size={14} /> Failed ({failed.length})
            </h3>
            <div className="space-y-2">
              {failed.map(email => (
                <div key={email.id} className="bg-rose-950/20 border border-rose-500/20 rounded-xl p-4 flex flex-col gap-3 group">
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-semibold text-white truncate">{email.leadName}</span>
                      <span className="text-[10px] uppercase tracking-wider text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded">
                        Failed
                      </span>
                    </div>
                    <div className="text-[10px] text-[#888] truncate">{email.subject}</div>
                    {email.error && (
                      <div className="text-[10px] text-rose-400/80 mt-1 line-clamp-2">
                        Error: {email.error}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 pt-2 border-t border-rose-500/10">
                    {onSendNow && (
                      <button 
                        onClick={() => onSendNow(email.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500 text-black rounded text-[10px] font-bold hover:bg-sky-400 transition-colors"
                      >
                        <Send size={12} /> Send Now
                      </button>
                    )}
                    {onReschedule && (
                      <button 
                        onClick={() => onReschedule(email.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#222] text-white rounded text-[10px] font-bold hover:bg-[#333] transition-colors"
                      >
                        <RefreshCw size={12} /> Reschedule
                      </button>
                    )}
                    {onCancelEmail && (
                      <button 
                        onClick={() => onCancelEmail(email.id)}
                        className="ml-auto text-rose-500 hover:text-rose-400 p-1.5"
                        title="Cancel"
                      >
                        <XCircle size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        <section>
          <h3 className="text-sm font-bold text-[#AAA] mb-3 uppercase tracking-wider">Upcoming ({upcoming.length})</h3>
          {upcoming.length === 0 ? (
            <div className="bg-[#111] border border-[#222] rounded-xl p-6 text-center text-[#666] text-xs italic">
              No upcoming scheduled emails.
            </div>
          ) : (
            <div className="space-y-2">
              {upcoming.map(email => (
                <div key={email.id} className="bg-[#111] border border-[#222] rounded-xl p-4 flex justify-between items-center group hover:border-[#333] transition-colors">
                  <div className="flex-1 min-w-0 pr-4 space-y-1">
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-semibold text-white truncate">{email.leadName}</span>
                      <span className="text-[10px] font-mono text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20 whitespace-nowrap ml-3">
                        {formatEST(email.scheduledAt)}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#888] truncate">{email.subject}</div>
                    {email.isFollowUp && (
                       <span className="text-[9px] uppercase tracking-wider text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded mr-2">
                         Follow-up #{email.followUpStep}
                       </span>
                    )}
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {onSendNow && (
                      <button 
                        onClick={() => onSendNow(email.id)}
                        className="text-sky-500 hover:text-sky-400 hover:bg-sky-500/10 p-2 rounded-lg"
                        title="Send Immediately"
                      >
                        <Send size={16} />
                      </button>
                    )}
                    {onCancelEmail && (
                      <button 
                        onClick={() => onCancelEmail(email.id)}
                        className="text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 p-2 rounded-lg"
                        title="Cancel Scheduled Email"
                      >
                        <XCircle size={16} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section>
          <h3 className="text-sm font-bold text-[#AAA] mb-3 uppercase tracking-wider">Past Scheduled ({past.length})</h3>
          {past.length === 0 ? (
            <div className="bg-[#111] border border-[#222] rounded-xl p-6 text-center text-[#666] text-xs italic">
              No past scheduled emails yet.
            </div>
          ) : (
            <div className="space-y-2 opacity-60">
              {past.map(email => (
                <div key={email.id} className="bg-[#111] border border-[#222] rounded-xl p-3 flex justify-between items-center">
                  <div className="flex-1 min-w-0 pr-4 space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-semibold text-[#888] truncate">{email.leadName}</span>
                      <span className={cn(
                        "text-[9px] uppercase tracking-wider px-1.5 py-0.5 rounded",
                        email.status === 'Sent' ? "text-emerald-400 bg-emerald-500/10" : "text-[#888] bg-[#222]"
                      )}>
                        {email.status}
                      </span>
                    </div>
                    <div className="text-[10px] text-[#666] truncate">{email.subject}</div>
                  </div>
                  <div className="text-[10px] font-mono text-[#555]">
                    {formatEST(email.scheduledAt)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
