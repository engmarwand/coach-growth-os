import React, { useState, useEffect, useRef } from 'react';
import { Template, TemplateCategory } from '../types';
import { 
  Plus, Trash2, Copy, FileText, Check, Sparkles, 
  Tag, Eye, Edit3, Search, RefreshCw, AlertCircle 
} from 'lucide-react';
import { cn } from '../utils';

const CATEGORIES: { label: TemplateCategory; color: string; bg: string; border: string }[] = [
  { label: 'Initial Pitch — Fitness Coach', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  { label: 'Initial Pitch — Business Coach', color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  { label: 'Initial Pitch — General Coach', color: 'text-teal-400', bg: 'bg-teal-500/10', border: 'border-teal-500/20' },
  { label: 'Follow-Up 1 — No Reply', color: 'text-purple-400', bg: 'bg-purple-500/10', border: 'border-purple-500/20' },
  { label: 'Follow-Up 2 — Low-Pressure Follow-Up', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  { label: 'Discovery Call Invitation', color: 'text-cyan-400', bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
  { label: 'Demo Invitation', color: 'text-indigo-400', bg: 'bg-indigo-500/10', border: 'border-indigo-500/20' },
  { label: 'Proposal Follow-Up', color: 'text-yellow-400', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
  { label: 'Client Onboarding', color: 'text-sky-400', bg: 'bg-sky-500/10', border: 'border-sky-500/20' },
  { label: 'Testimonial Request', color: 'text-fuchsia-400', bg: 'bg-fuchsia-500/10', border: 'border-fuchsia-500/20' },
  { label: 'Low-Pressure Sign-Off', color: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/20' },
  { label: 'General', color: 'text-zinc-400', bg: 'bg-zinc-500/10', border: 'border-zinc-500/20' },
];

const VARIABLE_TAGS = [
  { tag: '{{Name}}', label: 'Coach Name' },
  { tag: '{{BusinessName}}', label: 'Business / Brand' },
  { tag: '{{Niche}}', label: 'Coaching Niche' },
  { tag: '{{Country}}', label: 'Country / Location' },
  { tag: '{{Website}}', label: 'Website URL' },
  { tag: '{{ProfileURL}}', label: 'Instagram / Profile URL' },
];

export function TemplatesView() {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTemplate, setActiveTemplate] = useState<Template | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [previewMode, setPreviewMode] = useState(false);
  const [savedToast, setSavedToast] = useState(false);
  const [restoringDefaults, setRestoringDefaults] = useState(false);

  const subjectRef = useRef<HTMLInputElement>(null);
  const bodyRef = useRef<HTMLTextAreaElement>(null);
  const [lastFocusedField, setLastFocusedField] = useState<'subject' | 'body'>('body');

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/templates');
      const data: Template[] = await res.json();
      setTemplates(data);
      if (data.length > 0 && !activeTemplate) {
        setActiveTemplate(data[0]);
      }
    } catch (err) {
      console.error('Failed to load templates', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRestoreDefaults = async () => {
    if (!window.confirm("Restore all 11 official Coach Growth OS templates? This will reset templates to the coach outreach library.")) {
      return;
    }
    try {
      setRestoringDefaults(true);
      const res = await fetch('/api/templates/reset', { method: 'POST' });
      const data = await res.json();
      if (data.templates) {
        setTemplates(data.templates);
        setActiveTemplate(data.templates[0] || null);
        setSavedToast(true);
        setTimeout(() => setSavedToast(false), 2000);
      }
    } catch (e) {
      console.error('Failed to reset templates', e);
      alert("Failed to restore templates.");
    } finally {
      setRestoringDefaults(false);
    }
  };

  const handleSaveAll = async (newTemplates: Template[]) => {
    setTemplates(newTemplates);
    try {
      await fetch('/api/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ templates: newTemplates })
      });
      setSavedToast(true);
      setTimeout(() => setSavedToast(false), 2000);
    } catch (e) {
      console.error('Failed to persist templates', e);
    }
  };

  const handleAdd = (defaultCategory: TemplateCategory = 'Initial Pitch') => {
    const newTemplate: Template = {
      id: 'tpl-' + Math.random().toString(36).substring(2, 9),
      name: `New ${defaultCategory} Template`,
      category: defaultCategory,
      subject: '',
      body: ''
    };
    const updated = [newTemplate, ...templates];
    setActiveTemplate(newTemplate);
    handleSaveAll(updated);
  };

  const handleDelete = (id: string) => {
    const updated = templates.filter(t => t.id !== id);
    if (activeTemplate?.id === id) {
      setActiveTemplate(updated[0] || null);
    }
    handleSaveAll(updated);
  };

  const handleDuplicate = (template: Template) => {
    const cloned: Template = {
      ...template,
      id: 'tpl-' + Math.random().toString(36).substring(2, 9),
      name: `${template.name} (Copy)`
    };
    const updated = [cloned, ...templates];
    setActiveTemplate(cloned);
    handleSaveAll(updated);
  };

  const handleUpdate = <K extends keyof Template>(field: K, value: Template[K]) => {
    if (!activeTemplate) return;
    const updatedTemplate = { ...activeTemplate, [field]: value };
    setActiveTemplate(updatedTemplate);
    const updatedList = templates.map(t => t.id === activeTemplate.id ? updatedTemplate : t);
    handleSaveAll(updatedList);
  };

  const insertVariable = (tag: string) => {
    if (!activeTemplate) return;
    if (lastFocusedField === 'subject' && subjectRef.current) {
      const input = subjectRef.current;
      const start = input.selectionStart || 0;
      const end = input.selectionEnd || 0;
      const currentVal = activeTemplate.subject || '';
      const newVal = currentVal.substring(0, start) + tag + currentVal.substring(end);
      handleUpdate('subject', newVal);
      setTimeout(() => {
        input.focus();
        input.setSelectionRange(start + tag.length, start + tag.length);
      }, 0);
    } else if (bodyRef.current) {
      const textarea = bodyRef.current;
      const start = textarea.selectionStart || 0;
      const end = textarea.selectionEnd || 0;
      const currentVal = activeTemplate.body || '';
      const newVal = currentVal.substring(0, start) + tag + currentVal.substring(end);
      handleUpdate('body', newVal);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + tag.length, start + tag.length);
      }, 0);
    }
  };

  const getCategoryMeta = (cat?: TemplateCategory) => {
    return CATEGORIES.find(c => c.label === cat) || CATEGORIES[CATEGORIES.length - 1];
  };

  const getTemplateTypeAndTarget = (category?: string) => {
    if (!category) {
      return { 
        type: 'General', 
        target: 'Any Coach', 
        typeBg: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20', 
        targetBg: 'bg-zinc-500/5 text-[#888] border-zinc-500/10' 
      };
    }
    
    let type = 'General';
    let typeBg = 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20';
    const catLower = category.toLowerCase();

    if (catLower.includes('pitch')) {
      type = 'Initial Pitch';
      typeBg = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    } else if (catLower.includes('follow-up') || catLower.includes('followup') || catLower.includes('no reply')) {
      type = 'Follow-Up';
      typeBg = 'bg-purple-500/10 text-purple-400 border-purple-500/20';
    } else if (catLower.includes('proposal')) {
      type = 'Proposal';
      typeBg = 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20';
    } else if (catLower.includes('onboarding')) {
      type = 'Onboarding';
      typeBg = 'bg-sky-500/10 text-sky-400 border-sky-500/20';
    } else if (catLower.includes('sign-off') || catLower.includes('breakup')) {
      type = 'Sign-Off';
      typeBg = 'bg-rose-500/10 text-rose-400 border-rose-500/20';
    } else if (catLower.includes('invitation') || catLower.includes('invite')) {
      type = 'Invitation';
      typeBg = 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    } else if (catLower.includes('testimonial')) {
      type = 'Testimonial';
      typeBg = 'bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/20';
    }

    let target = 'General Coach';
    let targetBg = 'bg-zinc-500/5 text-[#888] border-zinc-500/10';
    
    if (catLower.includes('fitness')) {
      target = 'Fitness Coach';
      targetBg = 'bg-emerald-500/5 text-emerald-400/80 border-emerald-500/10';
    } else if (catLower.includes('business')) {
      target = 'Business Coach';
      targetBg = 'bg-blue-500/5 text-blue-400/80 border-blue-500/10';
    } else if (catLower.includes('general')) {
      target = 'General Coach';
      targetBg = 'bg-teal-500/5 text-teal-400/80 border-teal-500/10';
    }

    return { type, target, typeBg, targetBg };
  };

  // Filter templates
  const filteredTemplates = templates.filter(t => {
    const matchesSearch = t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (t.category && t.category.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategoryFilter === 'all' || t.category === selectedCategoryFilter;
    return matchesSearch && matchesCategory;
  });

  // Sample coach lead for live preview
  const sampleLead = {
    Name: 'Sarah Jenkins',
    BusinessName: 'Elevate Fitness Coaching',
    Niche: 'Online Fitness & Nutrition',
    Country: 'United States',
    Website: 'https://sarahfitnesscoach.com',
    ProfileURL: 'https://instagram.com/sarahjenkinsfit',
    DealValue: '$800',
    PersonalizedObservation: 'your breakdown of client adherence systems and nutrition tracking',
    PainPoint: 'managing incoming DMs across Instagram and messy spreadsheets',
    DemoLink: 'https://coachgrowthos.com/demo'
  };

  const applyTemplateMergeFields = (text: string) => {
    return text
      .replace(/{{Name}}/g, sampleLead.Name)
      .replace(/{{BusinessName}}/g, sampleLead.BusinessName)
      .replace(/{{Niche}}/g, sampleLead.Niche)
      .replace(/{{Country}}/g, sampleLead.Country)
      .replace(/{{Website}}/g, sampleLead.Website)
      .replace(/{{ProfileURL}}/g, sampleLead.ProfileURL)
      .replace(/{{DealValue}}/g, sampleLead.DealValue)
      .replace(/{{Deal Value}}/g, sampleLead.DealValue)
      .replace(/{{PersonalizedObservation}}/g, sampleLead.PersonalizedObservation)
      .replace(/{{PainPoint}}/g, sampleLead.PainPoint)
      .replace(/{{DemoLink}}/g, sampleLead.DemoLink);
  };

  const renderedSubject = activeTemplate ? applyTemplateMergeFields(activeTemplate.subject) : '';
  const renderedBody = activeTemplate ? applyTemplateMergeFields(activeTemplate.body) : '';

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center bg-[#0A0A0A] rounded-2xl border border-[#222]">
        <div className="flex items-center space-x-2 text-sm text-[#888]">
          <RefreshCw size={16} className="animate-spin text-emerald-400" />
          <span>Loading templates library...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full bg-[#0A0A0A] rounded-2xl border border-[#222] overflow-hidden">
      
      {/* Sidebar List */}
      <div className="w-80 border-r border-[#222] bg-[#0C0C0C] flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-[#222] space-y-3">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-white">Outreach Templates</h2>
              <p className="text-[10px] text-[#666]">Clipping & UGC agency library</p>
            </div>
            <div className="flex items-center space-x-1.5">
              <button
                onClick={handleRestoreDefaults}
                disabled={restoringDefaults}
                className="bg-[#1C1C1C] hover:bg-[#252525] text-[#AAA] hover:text-white px-2 py-1.5 rounded-lg text-xs font-medium flex items-center space-x-1 transition-colors border border-[#2E2E2E]"
                title="Restore official agency templates"
              >
                <RefreshCw size={12} className={cn(restoringDefaults && "animate-spin text-emerald-400")} />
                <span className="text-[11px]">Defaults</span>
              </button>
              <button 
                onClick={() => handleAdd('Initial Pitch')}
                className="bg-emerald-500 hover:bg-emerald-400 text-black px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-colors shadow-sm"
                title="Create new template"
              >
                <Plus size={14} />
                <span>New</span>
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="relative">
            <Search size={12} className="absolute left-2.5 top-2.5 text-[#555]" />
            <input 
              type="text" 
              placeholder="Search templates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#141414] border border-[#222] rounded-lg pl-8 pr-3 py-1.5 text-xs text-[#CCC] placeholder-[#555] outline-none focus:border-emerald-500/50"
            />
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1 pt-1 max-h-24 overflow-y-auto pr-1">
            <button
              onClick={() => setSelectedCategoryFilter('all')}
              className={cn(
                "text-[10px] px-2 py-0.5 rounded-full border transition-colors",
                selectedCategoryFilter === 'all' 
                  ? "bg-white/10 text-white border-white/20 font-medium" 
                  : "text-[#666] border-transparent hover:text-[#AAA]"
              )}
            >
              All ({templates.length})
            </button>
            {CATEGORIES.map(cat => {
              const count = templates.filter(t => t.category === cat.label).length;
              if (count === 0 && selectedCategoryFilter !== cat.label) return null;
              return (
                <button
                  key={cat.label}
                  onClick={() => setSelectedCategoryFilter(cat.label)}
                  className={cn(
                    "text-[10px] px-2 py-0.5 rounded-full border transition-colors flex items-center space-x-1",
                    selectedCategoryFilter === cat.label
                      ? `${cat.bg} ${cat.color} ${cat.border} font-medium`
                      : "text-[#666] border-transparent hover:text-[#AAA]"
                  )}
                >
                  <span>{cat.label}</span>
                  <span className="opacity-60 text-[9px]">({count})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Template Cards List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
          {filteredTemplates.length === 0 ? (
            <div className="p-8 text-center text-[#555] text-xs space-y-2">
              <p>No templates match your filters.</p>
              <button 
                onClick={() => handleAdd('Initial Pitch')}
                className="text-emerald-400 text-xs hover:underline"
              >
                + Create one now
              </button>
            </div>
          ) : (
            filteredTemplates.map(t => {
              const meta = getCategoryMeta(t.category);
              const isActive = activeTemplate?.id === t.id;
              return (
                <div 
                  key={t.id}
                  onClick={() => setActiveTemplate(t)}
                  className={cn(
                    "p-3 rounded-xl cursor-pointer flex flex-col space-y-1.5 border transition-all group relative",
                    isActive 
                      ? "bg-[#161616] border-emerald-500/30 shadow-md" 
                      : "bg-[#0F0F0F] border-[#1F1F1F] hover:bg-[#141414] hover:border-[#2A2A2A]"
                  )}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex flex-wrap gap-1 items-center max-w-[80%]">
                      {/* Outreach Type Badge */}
                      <span className={cn(
                        "text-[9px] font-bold uppercase px-1.5 py-0.5 rounded border tracking-wider",
                        getTemplateTypeAndTarget(t.category).typeBg
                      )}>
                        {getTemplateTypeAndTarget(t.category).type}
                      </span>
                      {/* Coach Target Badge */}
                      <span className={cn(
                        "text-[8px] font-medium uppercase px-1.5 py-0.5 rounded border tracking-wide",
                        getTemplateTypeAndTarget(t.category).targetBg
                      )}>
                        {getTemplateTypeAndTarget(t.category).target}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDuplicate(t); }}
                        className="text-[#777] hover:text-white p-1 rounded hover:bg-[#222]"
                        title="Duplicate template"
                      >
                        <Copy size={11} />
                      </button>
                      <button 
                        onClick={(e) => { e.stopPropagation(); handleDelete(t.id); }}
                        className="text-red-400 hover:text-red-300 p-1 rounded hover:bg-red-500/10"
                        title="Delete template"
                      >
                        <Trash2 size={11} />
                      </button>
                    </div>
                  </div>

                  <div className="text-xs font-semibold text-[#E0E0E0] truncate">
                    {t.name || 'Untitled Template'}
                  </div>
                  <div className="text-[11px] text-[#777] truncate">
                    {t.subject || 'No subject line specified'}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Editor & Preview Area */}
      <div className="flex-1 flex flex-col bg-[#0A0A0A] overflow-hidden">
        {activeTemplate ? (
          <>
            {/* Action Bar */}
            <div className="p-4 border-b border-[#222] bg-[#0D0D0D] flex flex-wrap items-center justify-between gap-4">
              <div className="flex-1 min-w-[200px]">
                <input 
                  type="text" 
                  value={activeTemplate.name}
                  onChange={(e) => handleUpdate('name', e.target.value)}
                  className="bg-transparent text-lg font-bold text-white outline-none w-full border-b border-transparent focus:border-emerald-500/40 pb-0.5 transition-colors"
                  placeholder="Template Name (e.g. Viral Clip Cold Outreach)"
                />
              </div>

              {/* View mode toggle + save indicator */}
              <div className="flex items-center space-x-2">
                {savedToast && (
                  <span className="text-[11px] text-emerald-400 flex items-center space-x-1 animate-pulse">
                    <Check size={12} />
                    <span>Saved</span>
                  </span>
                )}
                <div className="bg-[#141414] border border-[#262626] rounded-lg p-0.5 flex space-x-0.5">
                  <button
                    onClick={() => setPreviewMode(false)}
                    className={cn(
                      "px-3 py-1 rounded-md text-xs font-medium flex items-center space-x-1.5 transition-colors",
                      !previewMode ? "bg-[#252525] text-white" : "text-[#777] hover:text-[#CCC]"
                    )}
                  >
                    <Edit3 size={12} />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => setPreviewMode(true)}
                    className={cn(
                      "px-3 py-1 rounded-md text-xs font-medium flex items-center space-x-1.5 transition-colors",
                      previewMode ? "bg-[#252525] text-emerald-400" : "text-[#777] hover:text-[#CCC]"
                    )}
                  >
                    <Eye size={12} />
                    <span>Live Preview</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Template Category Selector (The core request) */}
            <div className="px-6 py-3 border-b border-[#1C1C1C] bg-[#0E0E0E] flex flex-wrap items-center gap-2">
              <div className="flex items-center space-x-1.5 text-xs text-[#888] mr-2">
                <Tag size={13} className="text-emerald-400" />
                <span className="font-semibold uppercase text-[10px] tracking-wider">Template Type:</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map(cat => {
                  const isSelected = (activeTemplate.category || 'Initial Pitch') === cat.label;
                  return (
                    <button
                      key={cat.label}
                      onClick={() => handleUpdate('category', cat.label)}
                      className={cn(
                        "text-xs px-2.5 py-1 rounded-lg border transition-all flex items-center space-x-1.5",
                        isSelected 
                          ? `${cat.bg} ${cat.color} ${cat.border} ring-1 ring-${cat.color.replace('text-', '')} font-semibold shadow-sm` 
                          : "bg-[#141414] text-[#777] border-[#222] hover:border-[#333] hover:text-[#AAA]"
                      )}
                    >
                      <span className={cn("w-1.5 h-1.5 rounded-full", isSelected ? cat.color.replace('text-', 'bg-') : "bg-[#444]")} />
                      <span>{cat.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Content Area */}
            {!previewMode ? (
              <div className="flex-1 p-6 flex flex-col space-y-4 overflow-y-auto">
                {/* Visual Type and Target Summary */}
                <div className="bg-[#111] border border-[#222]/60 rounded-xl p-3 flex flex-wrap gap-4 items-center justify-between shadow-sm">
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-medium text-[#777]">Outreach Category:</span>
                    <span className={cn(
                      "text-[10px] font-bold uppercase px-2 py-0.5 rounded border tracking-wider",
                      getTemplateTypeAndTarget(activeTemplate.category).typeBg
                    )}>
                      {getTemplateTypeAndTarget(activeTemplate.category).type}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-medium text-[#777]">Target Audience:</span>
                    <span className={cn(
                      "text-[10px] font-bold uppercase px-2 py-0.5 rounded border tracking-wide",
                      getTemplateTypeAndTarget(activeTemplate.category).targetBg
                    )}>
                      {getTemplateTypeAndTarget(activeTemplate.category).target}
                    </span>
                  </div>
                </div>

                {/* Subject Line */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-[#888]">
                      Email Subject Line
                    </label>
                    <span className="text-[10px] text-[#555]">Supports variables</span>
                  </div>
                  <input 
                    ref={subjectRef}
                    type="text" 
                    value={activeTemplate.subject}
                    onFocus={() => setLastFocusedField('subject')}
                    onChange={(e) => handleUpdate('subject', e.target.value)}
                    className="w-full bg-[#111] border border-[#222] rounded-xl p-3 text-sm text-white outline-none focus:border-emerald-500 transition-colors placeholder-[#444]"
                    placeholder="e.g. Quick question about your coaching lead flow, {{Name}}"
                  />
                </div>

                {/* Variable Insertion Pills */}
                <div className="bg-[#111] border border-[#1E1E1E] rounded-xl p-3">
                  <div className="text-[10px] uppercase font-semibold text-[#666] tracking-wider mb-2 flex items-center justify-between">
                    <span>Click to insert dynamic variable tag into cursor:</span>
                    <span className="text-[9px] text-[#555]">Target: {lastFocusedField === 'subject' ? 'Subject' : 'Email Body'}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {VARIABLE_TAGS.map(v => (
                      <button
                        key={v.tag}
                        type="button"
                        onClick={() => insertVariable(v.tag)}
                        className="text-xs font-mono bg-[#181818] hover:bg-emerald-500/10 text-emerald-400 hover:text-emerald-300 border border-emerald-500/20 hover:border-emerald-500/40 px-2.5 py-1 rounded-lg transition-all flex items-center space-x-1"
                      >
                        <span>{v.tag}</span>
                        <span className="text-[9px] text-[#666] font-sans font-normal">({v.label})</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Email Body */}
                <div className="flex-1 flex flex-col min-h-[260px]">
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-[#888]">
                      Email Message Body
                    </label>
                    <span className="text-[10px] text-[#555]">Plain-text with natural paragraph breaks</span>
                  </div>
                  <textarea 
                    ref={bodyRef}
                    value={activeTemplate.body}
                    onFocus={() => setLastFocusedField('body')}
                    onChange={(e) => handleUpdate('body', e.target.value)}
                    className="flex-1 bg-[#111] border border-[#222] rounded-xl p-4 text-sm text-[#DDD] outline-none focus:border-emerald-500 resize-none transition-colors font-sans leading-relaxed placeholder-[#444]"
                    placeholder="Write your email template here... Use {{Name}} to address the prospect."
                  />
                </div>
              </div>
            ) : (
              /* Live Preview with Sample Data */
              <div className="flex-1 p-6 flex flex-col space-y-4 overflow-y-auto">
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between text-xs text-emerald-400">
                  <div className="flex items-center space-x-2">
                    <Sparkles size={14} />
                    <span>Showing live preview rendered for prospect: <strong>{sampleLead.Name}</strong> ({sampleLead.Niche}, {sampleLead.Country})</span>
                  </div>
                  <span className="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded uppercase font-semibold">Live Preview</span>
                </div>

                {/* Visual Type and Target Summary */}
                <div className="bg-[#111] border border-[#222]/60 rounded-xl p-3 flex flex-wrap gap-4 items-center justify-between shadow-sm">
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-medium text-[#777]">Outreach Category:</span>
                    <span className={cn(
                      "text-[10px] font-bold uppercase px-2 py-0.5 rounded border tracking-wider",
                      getTemplateTypeAndTarget(activeTemplate.category).typeBg
                    )}>
                      {getTemplateTypeAndTarget(activeTemplate.category).type}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[11px] font-medium text-[#777]">Target Audience:</span>
                    <span className={cn(
                      "text-[10px] font-bold uppercase px-2 py-0.5 rounded border tracking-wide",
                      getTemplateTypeAndTarget(activeTemplate.category).targetBg
                    )}>
                      {getTemplateTypeAndTarget(activeTemplate.category).target}
                    </span>
                  </div>
                </div>

                <div className="bg-[#111] border border-[#222] rounded-2xl p-6 shadow-xl space-y-4">
                  <div className="border-b border-[#222] pb-4 space-y-2">
                    <div className="text-xs text-[#777] flex items-center space-x-2">
                      <span className="font-semibold text-[#999]">To:</span>
                      <span className="text-[#CCC]">{sampleLead.Name} &lt;alex@thornecreative.io&gt;</span>
                    </div>
                    <div className="text-base font-bold text-white">
                      {renderedSubject || <span className="text-[#555] italic">No subject line</span>}
                    </div>
                  </div>
                  <div className="text-sm text-[#CCC] whitespace-pre-wrap leading-relaxed min-h-[180px]">
                    {renderedBody || <span className="text-[#555] italic">No body content</span>}
                  </div>
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-[#555] space-y-3">
            <FileText size={48} className="opacity-20" />
            <p className="text-sm">Select a template on the left or create a new one</p>
            <button
              onClick={() => handleAdd('Initial Pitch')}
              className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-4 py-2 rounded-xl text-xs font-semibold hover:bg-emerald-500/20 transition-colors"
            >
              + Create Template
            </button>
          </div>
        )}
      </div>

    </div>
  );
}
