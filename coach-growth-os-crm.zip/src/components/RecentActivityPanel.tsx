import React, { useState } from 'react';
import { 
  History, UserPlus, Send, ArrowRightLeft, Trash2, 
  Filter, Clock, ChevronRight 
} from 'lucide-react';
import { ActivityLog, ActivityType } from '../types';

interface Props {
  activities: ActivityLog[];
  onClearActivities: () => void;
  onSelectLead?: (leadId: string) => void;
}

function formatRelativeTime(isoString: string): string {
  try {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr = Math.floor(diffMin / 60);
    const diffDays = Math.floor(diffHr / 24);

    if (diffSec < 45) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHr < 24) return `${diffHr}h ago`;
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch {
    return 'Recently';
  }
}

export function RecentActivityPanel({ activities, onClearActivities, onSelectLead }: Props) {
  const [filter, setFilter] = useState<'All' | ActivityType>('All');
  const [isConfirmingClear, setIsConfirmingClear] = useState(false);

  const filtered = filter === 'All' 
    ? activities 
    : activities.filter(a => a.type === filter);

  const getTypeStyle = (type: ActivityType) => {
    switch (type) {
      case 'Lead Added':
        return {
          icon: <UserPlus size={11} className="text-emerald-400" />,
          badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
          dot: 'bg-emerald-400'
        };
      case 'Email Sent':
        return {
          icon: <Send size={11} className="text-sky-400" />,
          badge: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
          dot: 'bg-sky-400'
        };
      case 'Email Scheduled':
        return {
          icon: <Clock size={11} className="text-indigo-400" />,
          badge: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
          dot: 'bg-indigo-400'
        };
      case 'Email Cancelled':
        return {
          icon: <Trash2 size={11} className="text-rose-400" />,
          badge: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
          dot: 'bg-rose-400'
        };
      case 'Status Changed':
        return {
          icon: <ArrowRightLeft size={11} className="text-amber-400" />,
          badge: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
          dot: 'bg-amber-400'
        };
      default:
        return {
          icon: <Clock size={11} className="text-zinc-400" />,
          badge: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
          dot: 'bg-zinc-400'
        };
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0D0D0D] border border-[#222] rounded-2xl overflow-hidden">
      {/* Header */}
      <div className="p-3 border-b border-[#1F1F1F] bg-[#111] flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <History size={13} className="text-emerald-400" />
          <h3 className="text-xs font-bold text-white tracking-wide uppercase">Recent Activity</h3>
          <span className="text-[10px] font-mono bg-[#1E1E1E] text-[#888] px-1.5 py-0.5 rounded-full">
            {activities.length}
          </span>
        </div>

        {activities.length > 0 && (
          <div className="flex items-center space-x-1">
            {isConfirmingClear ? (
              <div className="flex items-center space-x-1">
                <button
                  onClick={() => {
                    onClearActivities();
                    setIsConfirmingClear(false);
                  }}
                  className="text-[10px] bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 px-1.5 py-0.5 rounded transition-colors"
                >
                  Clear
                </button>
                <button
                  onClick={() => setIsConfirmingClear(false)}
                  className="text-[10px] text-[#777] hover:text-white px-1 py-0.5"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsConfirmingClear(true)}
                className="text-[#666] hover:text-rose-400 p-1 rounded transition-colors"
                title="Clear activity history"
              >
                <Trash2 size={12} />
              </button>
            )}
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      {activities.length > 0 && (
        <div className="flex items-center px-2 py-1.5 bg-[#0A0A0A] border-b border-[#1C1C1C] gap-1 overflow-x-auto text-[10px]">
          {(['All', 'Lead Added', 'Email Sent', 'Status Changed'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-2 py-0.5 rounded-md font-medium whitespace-nowrap transition-colors ${
                filter === cat 
                  ? 'bg-[#222] text-white' 
                  : 'text-[#666] hover:text-[#AAA]'
              }`}
            >
              {cat === 'Lead Added' ? 'Leads' : cat === 'Email Sent' ? 'Emails' : cat === 'Status Changed' ? 'Status' : 'All'}
            </button>
          ))}
        </div>
      )}

      {/* Activity Stream */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-2">
        {filtered.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-4">
            <Clock size={24} className="text-[#333] mb-2" />
            <p className="text-xs text-[#888] font-medium">No activity recorded yet</p>
            <p className="text-[10px] text-[#555] mt-1 max-w-[180px]">
              Actions like adding leads, sending cold emails, and changing statuses will be logged here.
            </p>
          </div>
        ) : (
          filtered.map((item) => {
            const style = getTypeStyle(item.type);
            return (
              <div
                key={item.id}
                onClick={() => item.leadId && onSelectLead?.(item.leadId)}
                className={`p-2 rounded-xl bg-[#121212] border border-[#1E1E1E] hover:border-[#2E2E2E] transition-all text-left group ${
                  item.leadId ? 'cursor-pointer' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`inline-flex items-center space-x-1 text-[9px] font-semibold px-1.5 py-0.5 rounded border ${style.badge}`}>
                    {style.icon}
                    <span>{item.type}</span>
                  </span>
                  <span className="text-[9px] text-[#666] font-mono">
                    {formatRelativeTime(item.timestamp)}
                  </span>
                </div>

                <div className="text-xs text-[#DDD] font-medium leading-tight group-hover:text-white transition-colors">
                  {item.title}
                </div>

                {item.details && (
                  <div className="text-[10px] text-[#777] mt-0.5 truncate leading-tight">
                    {item.details}
                  </div>
                )}

                {item.leadName && (
                  <div className="flex items-center justify-between text-[9px] text-[#555] mt-1 pt-1 border-t border-[#181818]">
                    <span className="text-emerald-500/80 font-mono truncate max-w-[140px]">
                      {item.leadName}
                    </span>
                    {item.leadId && (
                      <ChevronRight size={10} className="opacity-0 group-hover:opacity-100 transition-opacity text-[#888]" />
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
