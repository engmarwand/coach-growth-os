import React, { useState } from 'react';
import { Lead, LeadStatus } from '../types';
import { X, Plus, UserPlus, DollarSign, Globe, Mail, MapPin, Tag } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (lead: Omit<Lead, 'id'>) => void;
}

export function AddLeadModal({ isOpen, onClose, onAdd }: Props) {
  const [name, setName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [niche, setNiche] = useState('');
  const [country, setCountry] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [dealValue, setDealValue] = useState('800');
  const [notes, setNotes] = useState('');
  const [personalizedObservation, setPersonalizedObservation] = useState('');
  const [status, setStatus] = useState<LeadStatus>('New');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    onAdd({
      Name: name.trim(),
      BusinessName: businessName.trim() || name.trim(),
      Niche: niche.trim() || 'Online Fitness Coach',
      Country: country.trim() || 'United States',
      Email: email.trim(),
      Website: website.trim(),
      Status: status,
      'Deal Value': dealValue.trim() || '800',
      'Last Contact Date': '',
      Notes: notes.trim(),
      PersonalizedObservation: personalizedObservation.trim(),
      PainPoint: 'lost leads across Instagram DMs and messy spreadsheets',
      DemoLink: 'https://coachgrowthos.com/demo'
    });

    setName('');
    setBusinessName('');
    setNiche('');
    setCountry('');
    setEmail('');
    setWebsite('');
    setDealValue('800');
    setNotes('');
    setPersonalizedObservation('');
    setStatus('New');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#111] border border-[#262626] rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-5 border-b border-[#222] flex justify-between items-center bg-[#141414]">
          <div className="flex items-center space-x-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <UserPlus size={15} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Add New Coach Prospect</h3>
              <p className="text-[10px] text-[#777]">Directly log a fitness or business coach into your pipeline</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#666] hover:text-white p-1 rounded-lg hover:bg-[#222]">
            <X size={16} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Coach Name *</label>
              <input 
                type="text" 
                required
                placeholder="e.g. Marcus Vance"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Business / Brand Name</label>
              <input 
                type="text" 
                placeholder="e.g. Vance Fitness"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Email Address</label>
              <input 
                type="email" 
                placeholder="marcus@vancefitness.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Coaching Niche</label>
              <input 
                type="text" 
                placeholder="e.g. Online Fitness Coach, Business Coach"
                value={niche}
                onChange={(e) => setNiche(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Country / Location</label>
              <input 
                type="text" 
                placeholder="e.g. USA, UK, Canada"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Website or Profile URL</label>
              <input 
                type="text" 
                placeholder="https://instagram.com/..."
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Setup / Retainer Value ($)</label>
              <input 
                type="text" 
                placeholder="800"
                value={dealValue}
                onChange={(e) => setDealValue(e.target.value)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Initial Pipeline Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as LeadStatus)}
                className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
              >
                <option value="New">New Prospect</option>
                <option value="Emailed">Already Emailed</option>
                <option value="Followed Up">Followed Up</option>
                <option value="Replied">Replied</option>
                <option value="Meeting Scheduled">Meeting Scheduled</option>
                <option value="Closed Won">Closed Won</option>
                <option value="Closed Lost">Closed Lost</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Personalized Observation (Specific & Accurate)</label>
            <input 
              type="text" 
              placeholder="e.g. saw your 12-week fat loss transformation program on Instagram"
              value={personalizedObservation}
              onChange={(e) => setPersonalizedObservation(e.target.value)}
              className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl px-3 py-2 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-[10px] uppercase font-bold text-[#888] mb-1">Internal Notes & Context</label>
            <textarea 
              rows={2}
              placeholder="e.g. Active coaching roster, runs DM triage personally, interested in a custom lead dashboard."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#181818] border border-[#2A2A2A] rounded-xl p-3 text-xs text-white placeholder-[#555] focus:border-emerald-500 outline-none resize-none leading-relaxed"
            />
          </div>

          <div className="pt-2 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs text-[#888] hover:text-white rounded-xl hover:bg-[#1C1C1C] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl transition-colors flex items-center space-x-1.5 shadow-md"
            >
              <Plus size={14} />
              <span>Add to Pipeline</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
}
