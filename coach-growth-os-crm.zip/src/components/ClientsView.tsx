import React, { useState } from 'react';
import { Lead } from '../types';
import { Briefcase, DollarSign, CheckCircle2, Globe, Mail, Search, ChevronRight, UserCheck } from 'lucide-react';
import { cn } from '../utils';

interface Props {
  leads: Lead[];
  onUpdate: (id: string, field: keyof Lead, value: string) => void;
  onNavigateToPipeline?: () => void;
}

const ONBOARDING_STAGES = [
  'Contract Sent',
  'Invoice Paid',
  'Strategy Call Booked',
  'Onboarding Complete'
];

export function ClientsView({ leads, onUpdate, onNavigateToPipeline }: Props) {
  const [search, setSearch] = useState('');
  const clients = leads.filter(l => l.Status === 'Closed Won');

  const filteredClients = clients.filter(c => 
    (c.Name || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.Niche || '').toLowerCase().includes(search.toLowerCase()) ||
    (c.Email || '').toLowerCase().includes(search.toLowerCase())
  );

  const totalRetainedValue = clients.reduce((sum, c) => sum + (parseFloat(c['Deal Value']) || 0), 0);

  return (
    <div className="flex flex-col h-full bg-[#0A0A0A] rounded-2xl border border-[#222] overflow-hidden">
      {/* Header Bar */}
      <div className="p-4 border-b border-[#222] bg-[#0C0C0C] flex flex-wrap justify-between items-center gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Briefcase size={16} />
          </div>
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-white">Active Clients & Retainers</h2>
            <p className="text-[10px] text-[#777]">Post-acquisition client fulfillment and onboarding tracker</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-[#141414] border border-[#222] rounded-xl px-3 py-1.5 flex items-center space-x-2">
            <span className="text-[10px] text-[#777] uppercase font-bold">Total Retained Value:</span>
            <span className="text-sm font-bold text-emerald-400 font-mono">${totalRetainedValue.toLocaleString()}</span>
          </div>

          <div className="relative">
            <Search size={12} className="absolute left-2.5 top-2.5 text-[#555]" />
            <input 
              type="text" 
              placeholder="Search clients..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-[#141414] border border-[#222] rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-[#555] outline-none focus:border-emerald-500/50"
            />
          </div>
        </div>
      </div>

      {/* Grid of Client Cards */}
      <div className="flex-1 overflow-auto p-5 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {clients.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center p-16 text-center space-y-3">
            <div className="w-14 h-14 rounded-2xl bg-[#141414] border border-[#222] flex items-center justify-center text-[#444]">
              <UserCheck size={28} />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-[#AAA]">No closed clients yet</h3>
              <p className="text-xs text-[#666] max-w-sm">
                When you win a deal in your outreach pipeline, mark their status as <strong>"Closed Won"</strong>. They will automatically graduate into this client roster.
              </p>
            </div>
            {onNavigateToPipeline && (
              <button 
                onClick={onNavigateToPipeline}
                className="mt-2 text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-4 py-2 rounded-xl hover:bg-emerald-500/20 transition-colors"
              >
                Go to Pipeline
              </button>
            )}
          </div>
        ) : (
          filteredClients.map(client => {
            const currentStage = client['Onboarding Stage'] || 'Contract Sent';
            const stageIndex = ONBOARDING_STAGES.indexOf(currentStage);

            return (
              <div key={client.id} className="bg-[#111] border border-[#222] rounded-2xl p-5 flex flex-col justify-between hover:border-[#333] transition-all space-y-4">
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="text-white font-bold text-sm">{client.Name}</h3>
                      <p className="text-[#777] text-xs mt-0.5">{client.Niche} • {client.Country}</p>
                    </div>
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs px-2.5 py-1 rounded-lg font-mono font-bold">
                      ${client['Deal Value']}
                    </div>
                  </div>

                  {/* Contact Info */}
                  <div className="space-y-1.5 text-xs text-[#AAA] bg-[#161616] p-3 rounded-xl border border-[#202020] mt-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[#666] flex items-center space-x-1.5">
                        <Mail size={12} />
                        <span>Email</span>
                      </span>
                      <span className="text-white truncate max-w-[160px]">{client.Email || 'No email'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#666] flex items-center space-x-1.5">
                        <Globe size={12} />
                        <span>Website</span>
                      </span>
                      <span className="text-emerald-400 truncate max-w-[160px]">{client.Website || 'N/A'}</span>
                    </div>
                  </div>
                </div>

                {/* Onboarding Stage & Stepper */}
                <div className="space-y-2 pt-2 border-t border-[#1C1C1C]">
                  <div className="flex justify-between items-center text-[10px] uppercase font-bold text-[#777]">
                    <span>Fulfillment Milestone</span>
                    <span className="text-emerald-400 font-semibold">{currentStage}</span>
                  </div>

                  {/* Visual Step Bar */}
                  <div className="grid grid-cols-4 gap-1">
                    {ONBOARDING_STAGES.map((s, idx) => (
                      <div 
                        key={s} 
                        className={cn(
                          "h-1.5 rounded-full transition-colors",
                          idx <= stageIndex ? "bg-emerald-500" : "bg-[#222]"
                        )} 
                        title={s}
                      />
                    ))}
                  </div>

                  <select 
                    className="w-full bg-[#161616] border border-[#262626] text-xs text-white rounded-xl p-2 outline-none focus:border-emerald-500 mt-2"
                    value={currentStage}
                    onChange={(e) => onUpdate(client.id, 'Onboarding Stage', e.target.value)}
                  >
                    {ONBOARDING_STAGES.map(stage => (
                      <option key={stage} value={stage}>{stage}</option>
                    ))}
                  </select>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
