import React, { useState } from 'react';
import { Lead, LeadStatus } from '../types';
import { X, Mail, Globe, MapPin, DollarSign, Calendar, Send, ExternalLink, Trash2, Sparkles, RefreshCw, AlertCircle } from 'lucide-react';
import { cn } from '../utils';

interface Props {
  lead: Lead | null;
  onClose: () => void;
  onUpdate: (id: string, field: keyof Lead, value: string) => void;
  onBulkUpdate?: (id: string, updates: Partial<Lead>) => void;
  onSelectForOutreach: (leadId: string) => void;
  onDelete: (id: string) => void;
}

const STATUS_OPTIONS: LeadStatus[] = [
  'New', 'Emailed', 'Followed Up', 'Replied', 
  'Meeting Scheduled', 'Closed Won', 'Closed Lost'
];

export function LeadDrawer({ lead, onClose, onUpdate, onBulkUpdate, onSelectForOutreach, onDelete }: Props) {
  if (!lead) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-96 bg-[#0E0E0E] border-l border-[#222] shadow-2xl z-40 flex flex-col animate-in slide-in-from-right duration-200">
      
      {/* Header */}
      <div className="p-5 border-b border-[#1F1F1F] flex justify-between items-start bg-[#121212]">
        <div className="space-y-1">
          <span className="text-[9px] font-mono uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            Lead Dossier
          </span>
          <h2 className="text-base font-bold text-white truncate max-w-[240px]">{lead.Name || 'Unnamed Lead'}</h2>
          <p className="text-xs text-[#777]">{lead.Niche} • {lead.Country}</p>
        </div>
        <button onClick={onClose} className="text-[#666] hover:text-white p-1 rounded-lg hover:bg-[#222]">
          <X size={16} />
        </button>
      </div>

      {/* Body Details */}
      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        
        {/* Quick Outreach CTA */}
        <div className="space-y-2">
          <button
            onClick={() => {
              onSelectForOutreach(lead.id);
              onClose();
            }}
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-colors shadow-md"
          >
            <Send size={13} />
            <span>Launch Outreach Composer</span>
          </button>
        </div>

        {/* Pipeline Status */}
        <div className="bg-[#141414] border border-[#222] rounded-xl p-3.5 space-y-2">
          <label className="text-[10px] uppercase font-bold text-[#777] tracking-wider block">
            Pipeline Stage
          </label>
          <select 
            className="w-full bg-[#1C1C1C] border border-[#2E2E2E] text-xs text-white rounded-lg p-2 outline-none focus:border-emerald-500"
            value={lead.Status || 'New'}
            onChange={(e) => onUpdate(lead.id, 'Status', e.target.value)}
          >
            {STATUS_OPTIONS.map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>

        {/* Core Attributes */}
        <div className="bg-[#141414] border border-[#222] rounded-xl p-4 space-y-3 text-xs">
          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Mail size={12} />
              <span>Email</span>
            </span>
            <input 
              type="email"
              value={lead.Email || ''}
              onChange={(e) => onUpdate(lead.id, 'Email', e.target.value)}
              className="bg-transparent text-right text-white focus:outline-none focus:border-b focus:border-emerald-500 max-w-[180px] truncate"
              placeholder="Add email..."
            />
          </div>

          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Sparkles size={11} className="text-[#777]" />
              <span>Brand / Business</span>
            </span>
            <input 
              type="text"
              value={lead.BusinessName || ''}
              onChange={(e) => onUpdate(lead.id, 'BusinessName', e.target.value)}
              className="bg-transparent text-right text-white focus:outline-none focus:border-b focus:border-emerald-500 max-w-[180px] truncate"
              placeholder="Add company name..."
            />
          </div>
          
          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Globe size={12} />
              <span>Platform / Source</span>
            </span>
            <select
              value={lead.Platform || ''}
              onChange={(e) => onUpdate(lead.id, 'Platform', e.target.value)}
              className="bg-transparent text-right text-white focus:outline-none focus:border-b focus:border-emerald-500 w-28 appearance-none"
            >
              <option value="">Select...</option>
              {['Instagram', 'LinkedIn', 'YouTube', 'TikTok', 'Email', 'Referral', 'Other'].map(p => (
                <option key={p} value={p} className="bg-[#1C1C1C] text-white">{p}</option>
              ))}
            </select>
          </div>

          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Globe size={12} />
              <span>Profile URL</span>
            </span>
            <input 
              type="text"
              value={lead.ProfileURL || ''}
              onChange={(e) => onUpdate(lead.id, 'ProfileURL', e.target.value)}
              className="bg-transparent text-right text-emerald-400 focus:outline-none focus:border-b focus:border-emerald-500 max-w-[150px] truncate"
              placeholder="https://instagram.com/..."
            />
          </div>

          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Globe size={12} />
              <span>Website</span>
            </span>
            <div className="flex items-center space-x-1.5">
              <input 
                type="text"
                value={lead.Website || ''}
                onChange={(e) => onUpdate(lead.id, 'Website', e.target.value)}
                className="bg-transparent text-right text-emerald-400 focus:outline-none focus:border-b focus:border-emerald-500 max-w-[120px] truncate"
                placeholder="https://..."
              />
              {lead.Website && (
                <a href={lead.Website.startsWith('http') ? lead.Website : `https://${lead.Website}`} target="_blank" rel="noreferrer" className="text-[#777] hover:text-white">
                  <ExternalLink size={12} />
                </a>
              )}
            </div>
          </div>

          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <MapPin size={12} />
              <span>Time Zone</span>
            </span>
            <input 
              type="text"
              value={lead.TimeZone || ''}
              onChange={(e) => onUpdate(lead.id, 'TimeZone', e.target.value)}
              className="bg-transparent text-right text-white focus:outline-none focus:border-b focus:border-emerald-500 max-w-[150px] truncate"
              placeholder="e.g. America/New_York"
            />
          </div>

          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <DollarSign size={12} />
              <span>Deal Value</span>
            </span>
            <div className="flex items-center space-x-1">
              <span className="text-[#666]">$</span>
              <input 
                type="text"
                value={lead['Deal Value'] || ''}
                onChange={(e) => onUpdate(lead.id, 'Deal Value', e.target.value)}
                className="bg-transparent text-right text-white font-mono font-semibold focus:outline-none focus:border-b focus:border-emerald-500 w-20"
                placeholder="800"
              />
            </div>
          </div>
          
          <div className="flex justify-between items-center border-b border-[#202020] pb-2">
            <span className="text-[#777] flex items-center space-x-1.5">
              <Calendar size={12} />
              <span>Last Contact</span>
            </span>
            <span className="text-white font-mono text-[11px]">
              {lead['Last Contact Date'] || 'None'}
            </span>
          </div>

          <div className="flex justify-between items-center text-rose-400">
             <label className="flex items-center space-x-2 cursor-pointer w-full justify-between">
                <span className="flex items-center space-x-1.5 text-[#777]">
                  <X size={12} className="text-rose-500" />
                  <span>Do Not Contact</span>
                </span>
                <input 
                  type="checkbox"
                  checked={!!lead.DoNotContact}
                  onChange={(e) => onUpdate(lead.id, 'DoNotContact', e.target.checked.toString())}
                  className="accent-rose-500 rounded border-[#333]"
                />
             </label>
          </div>
        </div>

        {/* Notes Editor */}
        <div className="space-y-1.5">
          <label className="text-[10px] uppercase font-bold text-[#777] tracking-wider block">
            Prospect Intelligence & Notes
          </label>
          <textarea 
            rows={5}
            value={lead.Notes || ''}
            onChange={(e) => onUpdate(lead.id, 'Notes', e.target.value)}
            placeholder="Log conversation notes, coaching niches, or follow-up details..."
            className="w-full bg-[#141414] border border-[#222] rounded-xl p-3 text-xs text-[#CCC] outline-none focus:border-emerald-500 resize-none leading-relaxed placeholder-[#444]"
          />
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-[#1F1F1F] bg-[#121212] flex justify-between items-center">
        <button 
          onClick={() => {
            onDelete(lead.id);
            onClose();
          }}
          className="text-xs text-red-400 hover:text-red-300 flex items-center space-x-1.5 p-1.5 rounded-lg hover:bg-red-500/10 transition-colors"
        >
          <Trash2 size={13} />
          <span>Remove Prospect</span>
        </button>
        <button 
          onClick={onClose}
          className="text-xs text-[#888] hover:text-white px-3 py-1.5 rounded-lg hover:bg-[#1C1C1C] transition-colors"
        >
          Done
        </button>
      </div>

    </div>
  );
}
